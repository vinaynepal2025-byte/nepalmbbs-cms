/* ═══════════════════════════════════════════════════
   sw.js — Service worker: caches the app shell so it
   loads instantly and works fully offline after first visit.
   IndexedDB data (students, tasks, etc.) is NOT touched here —
   that's handled separately by js/db.js.
═══════════════════════════════════════════════════ */

const CACHE_NAME = 'nepalmbbs-cms-v7';
const ASSETS = [
  './',
  './index.html',
  './manifest.json',
  './css/styles.css',
  './js/db.js',
  './js/state.js',
  './js/ui-core.js',
  './js/auth.js',
  './js/seed.js',
  './js/dashboard.js',
  './js/students.js',
  './js/tasks.js',
  './js/admissions.js',
  './js/visitors.js',
  './js/attendance.js',
  './js/calendar.js',
  './js/marketing.js',
  './js/mentor-coordinator.js',
  './js/hostel.js',
  './js/comms.js',
  './js/reports.js',
  './js/admin.js',
  './js/ai.js',
  './js/expenses.js',
  './js/device.js',
  './js/app.js',
  './assets/icons/icon-192.svg',
  './assets/icons/icon-512.svg',
];

self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(ASSETS))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (e) => {
  // Only handle same-origin GET requests; let cross-origin (e.g. Gemini API,
  // Google Fonts) pass straight through to the network.
  if (e.request.method !== 'GET' || new URL(e.request.url).origin !== location.origin) {
    return;
  }

  e.respondWith(
    caches.match(e.request).then((cached) => {
      if (cached) return cached;
      return fetch(e.request)
        .then((resp) => {
          if (resp && resp.status === 200) {
            const clone = resp.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(e.request, clone));
          }
          return resp;
        })
        .catch(() => caches.match('./index.html'));
    })
  );
});
