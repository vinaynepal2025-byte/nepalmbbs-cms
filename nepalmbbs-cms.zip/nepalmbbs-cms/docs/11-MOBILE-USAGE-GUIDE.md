# 11 — Mobile Usage Guide (For Sub-Admins / Real Staff)

This is the exact, step-by-step guide for a real sub-admin (Marketing,
Coordinator, Mentor, Admission Manager) to use this app on **their own
mobile phone** — Android or iPhone. Forward this whole file to them, or
walk them through it once.

## Prerequisite: the app must already be live on the internet

This guide assumes you've already deployed the app to a real URL (e.g.
`https://cms.nepalmbbs.in`) following `04-DEPLOYMENT-GITHUB.md`. A sub-admin
cannot use your `localhost:8080` — that only works on the exact desktop
where you ran the Python server. Once deployed to GitHub Pages /
`cms.nepalmbbs.in`, anyone with the URL and an internet connection can
reach it from anywhere.

## Step 1 — Admin creates the sub-admin's account first

Before the staff member touches their phone, you (Super Admin) do this
once, from your own device:

1. Open the app → **Profile → Admin Control Panel → Users → + Add Staff**
2. Fill in their real name, their real email, their real phone, pick their
   role, set a temporary password
3. Tell them the email + temporary password **out of band** — phone call,
   in-person, or a messaging app — not written down somewhere public

## Step 2 — Sub-admin opens the link on their phone

1. On their Android or iPhone, open **Chrome** (Android) or **Safari**
   (iPhone) — these matter, since "Add to Home Screen" works most reliably
   in the default browser on each platform
2. Type in the URL you give them: `https://cms.nepalmbbs.in` (or whatever
   subdomain you chose)
3. The same liquid-glass login screen you've seen will load

## Step 3 — Sign in with their own credentials

1. Tap **Sign In** (this tab, not First Setup — First Setup is only ever
   used once, by you, to create the Super Admin)
2. Enter the email and temporary password you gave them
3. Select the same **Organization** from the dropdown that you used when
   creating their account
4. Tap **🚀 Enter CMS**

They'll land on a dashboard that looks different from yours — only their
role's Quick Actions, bottom navigation items, and relevant sections
appear (see `03-ROLE-PERMISSIONS.md` for exactly what each role sees).

## Step 4 — Install it as an app icon (recommended)

This makes it feel like a real app instead of a website tab, and is what
lets it work offline:

### On Android (Chrome)
1. Tap the **⋮** (three dots) menu, top-right of Chrome
2. Tap **"Add to Home Screen"** or **"Install app"**
3. Confirm — an icon appears on their home screen
4. From now on, they tap that icon, not a browser bookmark

### On iPhone (Safari)
1. Tap the **Share** icon (square with an arrow pointing up), bottom of
   the screen
2. Scroll down and tap **"Add to Home Screen"**
3. Tap **Add** in the top-right
4. An icon appears on their home screen, same as any other app

## Step 5 — Grant permissions when asked

The first time they tap things like **📷 Camera** (Documents section) or
**📍 Location**-dependent features, their phone will show a native
permission popup ("Allow NepalMBBS CMS to access your Camera?"). They
should tap **Allow** for features they intend to use. Nothing is accessed
without this explicit prompt — standard browser/PWA behavior, not
something this app can bypass even if it wanted to.

## Step 6 — Day-to-day use

Once installed and logged in, the sub-admin simply:
- Taps the home screen icon to open it any time, including with **no
  internet connection** — their previously-loaded data and the app shell
  are cached locally on their phone
- Any changes they make (adding a lead, marking attendance, logging a
  mentor report) save instantly to **their phone's local storage**
- When they're back online, nothing needs to be manually "synced" in this
  version of the app — see the important note below

## ⚠️ Important: what "centralized" means today vs. with real multi-device sync

Be very clear with your sub-admins about this so nobody is surprised:

**Right now**, each person's phone has its **own local copy** of the
database. If the Marketing person adds a lead on their phone, you (Admin)
will **not** automatically see it appear on your own phone/desktop unless
you're sharing the exact same browser profile on the exact same device.
This is the nature of the offline-first, no-backend-server architecture
described in `01-ARCHITECTURE.md` and `09-FUTURE-UPGRADES.md`.

**What this means practically for your team today:**
- This app works perfectly as **each person's personal daily tool** —
  their own tasks, their own attendance marking, their own notes — fully
  offline, fully private to their device.
- For data that genuinely needs to be seen by everyone in real time
  (e.g. Admin needs to see every lead Marketing adds, immediately), you
  currently need the **same physical device** logged into different
  accounts, OR you need the Supabase backend upgrade described in
  `09-FUTURE-UPGRADES.md` section 1, which turns "local IndexedDB" into
  "shared cloud database" with a moderate, well-scoped amount of
  additional work — not a rewrite.
- A practical bridge until then: **Admin → System → Export Full Backup**
  lets anyone export their device's data as a JSON file to send to you
  (WhatsApp, email) for manual merging, and **Import Backup** lets you load
  it. This is manual, not real-time, but it works today with zero new
  infrastructure.

If true real-time multi-device sync across your whole team is a
must-have rather than a nice-to-have, say so directly and prioritize the
Supabase upgrade in `09-FUTURE-UPGRADES.md` — it's the single highest-impact
next step and unlocks this cleanly.

## Troubleshooting for sub-admins

**"No account found. Please run First Setup."**
→ They tapped First Setup by mistake, or typed their email wrong. They
  should use **Sign In** with the exact email/password the Admin gave
  them.

**App looks different from what the Admin described**
→ Confirm they're logged in with the correct role-specific account, not
  accidentally using the Admin's credentials.

**Camera/upload doesn't work**
→ Check phone Settings → [Browser name] → Permissions → Camera is allowed
  for that browser/PWA.

**Changes disappeared after clearing browser data / reinstalling**
→ As explained above, data lives in that browser's local storage. Clearing
  site data or uninstalling the PWA removes it. Encourage regular use of
  Admin → System → Export Full Backup as a safety net (see
  `08-MAINTENANCE.md`).
