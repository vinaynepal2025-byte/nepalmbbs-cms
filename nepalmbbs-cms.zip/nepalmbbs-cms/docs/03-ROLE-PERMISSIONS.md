# 03 — Role Permissions

## Roles

| Role | Who | Bottom nav |
|---|---|---|
| `superadmin` | The one account created at First Setup. Full access. | Home, Students, Tasks, Reports, Profile |
| `admin` | Staff promoted to full access by the Super Admin. | Home, Students, Tasks, Reports, Profile |
| `admission_manager` | Runs the admission pipeline. | Home, Students, Admissions, Tasks, Profile |
| `marketing` | Runs lead generation & campaigns. | Home, Marketing, Students, Tasks, Profile |
| `coordinator` | On-the-ground student support (hostel, health, travel). | Home, Coordinator, Students, Attendance, Profile |
| `mentor` | Academic guidance & risk monitoring. | Home, Mentor, Students, Attendance, Profile |
| `counsellor` | Pre-admission counselling. | Home, Students, Admissions, Tasks, Profile |

Bottom nav is capped at 5 items per role (thumb-reach UX principle) — every
role also reaches Notifications, Calendar, Comms and the AI Assistant via
the header icons / Quick Actions grid on their dashboard, they're just not
in the fixed bottom bar for every role.

## What "Admin can do everything" means in this codebase

The master prompt requires the Main Admin to have unrestricted access to
every module. Concretely:

- `ROLES.superadmin` and `ROLES.admin` are the only roles whose bottom nav
  includes **Admin Control Panel** (`sec-admin`), gated in `admin.js →
  loadAdmin()`:
  ```js
  if (!['superadmin', 'admin'].includes(CU?.role)) {
    // show "Access restricted" instead of the panel
  }
  ```
- Both roles see the full Quick Actions set on the dashboard
  (`dashboard.js → renderQuickActions()` → `actionSets.superadmin`).
- Both can reach every section by URL-equivalent (`showSection('students')`,
  `showSection('marketing')`, etc.) even though their bottom nav only shows
  5 icons — nothing is hard-blocked for them outside the Admin panel itself.

## What's enforced vs. what's a UI convention

Be honest with yourself about this distinction before you deploy to real
staff:

- **UI-level filtering** (what this app does today): each role's dashboard
  and bottom nav only *shows* the sections relevant to their job. A
  Marketing user's app simply never renders an "Admin" button.
- **Hard access control** (what this app does NOT do): there is no server
  checking permissions on every data read/write. Since all data lives in
  the same browser-local IndexedDB that every logged-in user on that
  *specific device* shares, a Marketing staff member who knows how to open
  browser DevTools could theoretically call `showSection('admin')` from the
  console and view the Admin panel's restricted message — but `loadAdmin()`
  would still block them from seeing real data, since the check happens
  before render.

For a single-device, trusted-staff deployment (the common case for one
college's front-desk computer or a manager's personal phone), this is a
reasonable level of protection. If you're deploying to dozens of staff
across personal phones and need real, server-enforced permissions (e.g. a
Marketing user literally cannot fetch student fee data even via the
network tab), you need the server-backed upgrade in
`09-FUTURE-UPGRADES.md`.

## Permission matrix (UI visibility)

| Section | superadmin | admin | admission_manager | marketing | coordinator | mentor | counsellor |
|---|---|---|---|---|---|---|---|
| Dashboard | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Students | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Admissions | ✅ | ✅ | ✅ | — | — | — | ✅ |
| Tasks | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Attendance | ✅ | ✅ | — | — | ✅ | ✅ | — |
| Marketing | ✅ | ✅ | — | ✅ | — | — | — |
| Mentor Center | ✅ | ✅ | — | — | — | ✅ | — |
| Coordinator Hub | ✅ | ✅ | — | — | ✅ | — | — |
| Comms | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Calendar | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Reports | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Admin Control Panel | ✅ | ✅ | — | — | — | — | — |
| AI Assistant | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |

Every role reaches **Reports**, **Comms**, **Calendar** and **AI** even
though they're not all in the bottom nav — they're one tap away from Quick
Actions or the section itself is shared.

## Changing a user's role

Admin → Users currently supports creating new staff with a chosen role
(`admin.js → openAddStaff()`). There is no "edit existing user's role" UI
yet — to change one, open Admin → Audit to find the user, then use
`Admin → System → Export Full Backup`, edit the `role` field for that user
in the downloaded JSON, and re-import. A proper edit-role UI is a 30-minute
addition if you want it — ask and I'll add it as a follow-up.
