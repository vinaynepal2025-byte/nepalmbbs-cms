# 00 — Start Here

Read this first. It tells you the exact order to upload files to GitHub and
get a working, installable app live on a `nepalmbbs.in` subdomain.

## 1. What you're getting

A folder called `nepalmbbs-cms/` containing a complete, working, offline-first
web app. There is nothing to "build" or "compile" — it runs directly as
static files. That's deliberate: it means GitHub Pages (free), Netlify
(free) or Vercel (free) can all host it with zero server cost, matching your
"free technology" requirement.

## 2. Upload sequence (GitHub Desktop or web upload)

Order doesn't actually matter to Git — it snapshots the whole folder in one
commit — but if you're dragging files into the GitHub web UI in batches,
upload in this order so partial uploads still leave a working app at each
step:

1. `README.md`, `manifest.json`, `sw.js`
2. `index.html`
3. `css/styles.css`
4. Everything in `js/` (any order — they're all needed together)
5. `assets/icons/icon-192.svg`, `assets/icons/icon-512.svg`
6. `docs/` folder (documentation only, not required for the app to run)

## 3. Fastest path: GitHub Desktop / git CLI

```bash
cd nepalmbbs-cms
git init
git add .
git commit -m "Initial commit — NepalMBBS CMS v3.0"
git branch -M main
git remote add origin https://github.com/<your-username>/nepalmbbs-cms.git
git push -u origin main
```

## 4. Turn the repo into a live site (GitHub Pages, free)

1. On GitHub → your repo → **Settings → Pages**
2. Source: "Deploy from a branch" → branch `main`, folder `/ (root)`
3. Save. GitHub gives you a URL like
   `https://<username>.github.io/nepalmbbs-cms/` within ~1 minute.

## 5. Point your subdomain at it (`cms.nepalmbbs.in`)

See `docs/04-DEPLOYMENT-GITHUB.md` for the exact DNS record and the
`CNAME` file GitHub needs.

## 6. First run

Open the live URL → tap **First Setup** → create your Super Admin account →
sign in. From there, use **Profile → Admin Control Panel → Users** to add
your Admission Manager, Marketing, Coordinator and Mentor staff accounts.

## 7. Read next

- `01-ARCHITECTURE.md` — how the pieces fit together
- `02-DATABASE-SCHEMA.md` — every data table and field
- `03-ROLE-PERMISSIONS.md` — what each role can see/do
- `04-DEPLOYMENT-GITHUB.md` — DNS + subdomain steps
- `05-GEMINI-SETUP.md` — get your free AI key
- `06-SECURITY.md` — honest limitations + how to harden
- `07-TESTING-CHECKLIST.md` — what to click-test before go-live
- `08-MAINTENANCE.md` — backups, updates, common fixes
- `09-FUTURE-UPGRADES.md` — the Phase 2 roadmap (multi-college cloud sync, payments, push notifications)
