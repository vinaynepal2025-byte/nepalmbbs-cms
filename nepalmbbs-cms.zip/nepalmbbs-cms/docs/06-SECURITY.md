# 06 — Security

Honesty up front: this is a **client-only, offline-first app**. That gives
you real strengths and real limitations. Both are listed here without
spin, per the audit standard the original brief asked for.

## What's genuinely secure

- **Password hashing**: passwords are never stored in plain text. Before
  saving, they're hashed with SHA-256 via the browser's native
  `crypto.subtle` API (`js/auth.js → hashPassword()`), salted with a fixed
  app-specific string. Only the hash sits in IndexedDB.
- **No plaintext secrets in the repo**: the Gemini API key is never
  hardcoded anywhere in the codebase — it's entered by each user at runtime
  and stored only in their own browser's `localStorage`.
- **HTTPS by default**: GitHub Pages (and Netlify/Vercel) serve over HTTPS
  automatically, so traffic between the browser and Google's Gemini API is
  encrypted in transit.
- **Local-only data**: because there's no server, there's no server to
  breach. Student data never leaves the device unless a staff member
  explicitly exports a backup file or shares something via WhatsApp/native
  share.
- **Audit log**: every sensitive action (login, logout, student/task/staff
  CRUD, broadcasts, exports, resets) is timestamped in the `audit_log`
  store, viewable at Admin → Audit.
- **Session expiry**: sessions auto-expire after 30 days
  (`js/auth.js → checkExistingSession()`), so a lost/stolen phone doesn't
  grant indefinite access.

## What this app does NOT protect against

Be clear-eyed about these before deciding this is "enough" for your real
deployment:

1. **Physical device access.** Anyone who can unlock the phone/computer
   running this app can open browser DevTools and read IndexedDB directly,
   bypassing the UI's role checks entirely. There is no encryption at rest
   for the local database — this is a browser-platform limitation, not
   something any client-only app can fully solve.
2. **No server-side authorization.** As explained in
   `03-ROLE-PERMISSIONS.md`, role restrictions are enforced in the UI layer
   only. A user who knows JavaScript could call restricted functions from
   the console.
3. **Multi-device sync isn't real-time secure messaging.** Backups are
   plain JSON files — if you email or upload an export somewhere insecure,
   that file contains everything: every student's contact info, guardian
   phone numbers, fee status. Treat exported backups like you'd treat a
   spreadsheet of the same data — encrypt or password-protect the file
   before sending it anywhere.
4. **No brute-force lockout.** The login form doesn't rate-limit failed
   password attempts. For a public-internet-facing deployment with many
   accounts, this matters; for a single trusted-staff device, less so.
5. **No two-factor authentication / OTP / biometric lock** is implemented
   in this version, despite being requested in the original brief. Web
   biometric APIs (WebAuthn) exist and are free, but require more setup
   than fits a first release — flagged honestly in
   `09-FUTURE-UPGRADES.md` rather than faked here.

## Practical hardening you can do today, for free

- **Use a strong, unique password** for the Super Admin account — it's the
  only account with full access, so it's the highest-value target.
- **Lock the device itself** with a PIN/biometric (this is the device OS's
  job, not the app's, but it's the single highest-leverage thing you can
  do).
- **Don't deploy this as a public, unauthenticated website** if you're
  storing real student PII — even though login is required, the static
  files themselves (HTML/CSS/JS) are publicly downloadable from anyone who
  visits the URL, same as any client-side app. That's fine; the *data* is
  still safe because it lives in each individual's own browser, not on a
  shared server — but understand that "the app" and "the data" are
  separately secured here.
- **Export backups regularly** (Admin → System) and store the JSON files
  somewhere encrypted (a password-protected zip, an encrypted USB drive,
  etc.) — this is your disaster-recovery plan since there's no cloud
  backup by default.

## If you need real server-enforced security

This means: per-request permission checks, encrypted-at-rest cloud storage,
rate limiting, audit logs that a compromised client can't tamper with, and
proper 2FA. All of that requires a backend. The good news: you don't need
to throw away any of this front-end code to get there — see
`09-FUTURE-UPGRADES.md` for the recommended free-tier path (Supabase),
which lets this exact UI talk to a real authenticated database instead of
IndexedDB, with a moderate (not full-rewrite) amount of work.
