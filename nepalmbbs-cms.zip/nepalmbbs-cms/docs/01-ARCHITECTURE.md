# 01 — Architecture

## High-level shape

```
┌─────────────────────────────────────────────────────────┐
│                      Browser / PWA                        │
│  ┌───────────────┐   ┌───────────────┐   ┌─────────────┐  │
│  │  index.html    │──▶│  css/styles.css│   │   sw.js     │  │
│  │  (app shell)   │   │ (liquid glass) │   │ (offline    │  │
│  └───────┬───────┘   └───────────────┘   │  cache)     │  │
│          │                                └─────────────┘  │
│          ▼                                                 │
│  ┌─────────────────────── js/ modules ──────────────────┐  │
│  │ db.js → state.js → ui-core.js → auth.js → seed.js     │  │
│  │ → dashboard.js → students.js → tasks.js               │  │
│  │ → admissions.js → attendance.js → calendar.js         │  │
│  │ → marketing.js → mentor-coordinator.js → comms.js     │  │
│  │ → reports.js → admin.js → ai.js → device.js → app.js  │  │
│  └─────────────────────────┬─────────────────────────────┘  │
│                             ▼                                │
│                  ┌─────────────────────┐                     │
│                  │     IndexedDB        │ ← all your data     │
│                  │  (on-device only)    │   lives here        │
│                  └─────────────────────┘                     │
└─────────────────────────────────────────────────────────────┘
          │                                    │
          ▼ (only if you add a key)            ▼ (optional)
   Google Gemini API                    Google Drive / native
   (your own free key,                  share/camera/call via
   called directly from                  standard Web APIs
   the browser)
```

## Why this shape

You asked for a free-technology, offline-capable, installable app. The
simplest architecture that satisfies all three constraints simultaneously is
a **static PWA with a local database**:

- **No backend server** → nothing to host, patch, or pay for. Static files
  work on GitHub Pages for free forever.
- **IndexedDB** is the browser's built-in structured database. It survives
  app restarts, works fully offline, and has no size limit comparable to
  localStorage (hundreds of MB is normal).
- **Service worker** (`sw.js`) caches the app shell (HTML/CSS/JS) so the app
  loads instantly and works with zero network connection after first visit.
- **Gemini AI** is called directly from the browser using a key you paste in
  — no proxy server needed, and Google's free tier covers normal day-to-day
  usage for one organization.

## Module responsibilities

| File | Responsibility |
|---|---|
| `db.js` | Thin wrapper around IndexedDB: `dbGetAll`, `dbGet`, `dbPut`, `dbDelete`, `dbGetByIndex`, plus full export/import for backups. |
| `state.js` | Pure constants: role labels/colors, nav config, lifecycle stage list, organization list. No logic. |
| `ui-core.js` | Cross-cutting UI helpers: toasts, modals, date/currency formatting, the shared `renderStatsGrid`, audit logging. |
| `auth.js` | Login, first-time setup, session persistence (30-day expiry), password hashing (SHA-256 via Web Crypto). |
| `seed.js` | Demo data inserted once at first setup so the app isn't empty. Safe to wipe from Admin → System → Reset. |
| `dashboard.js` | Role-aware stat cards, quick actions, pipeline strip, AI insight bubbles, today's tasks. |
| `students.js` | The core lifecycle entity: CRUD, detail bottom-sheet, stage progression. |
| `tasks.js` | Task manager: create, filter, complete, priority. |
| `admissions.js` | A filtered view over the same `students` store, grouped by pipeline stage — **no duplicate data**, just a different lens. |
| `attendance.js` | Per-session attendance sheets + rolled-up history view. |
| `calendar.js` | Month grid + event CRUD. |
| `marketing.js` | Leads, campaigns, social/Canva shortcuts. Adding a lead also inserts it into `students` at the "Lead" stage — single source of truth, per your requirement. |
| `mentor-coordinator.js` | Two role-specific modules sharing one file since they're tightly related (both operate on the same student records, different lenses). |
| `comms.js` | Notices (push into `notifications`), broadcast, team-chat placeholder. |
| `reports.js` | Aggregates across `students` for stage distribution + geography; notification list rendering. |
| `admin.js` | Staff management, audit log viewer, backup export/import, destructive reset (guarded by confirmation). |
| `ai.js` | Gemini API wrapper with **graceful offline fallback** — every AI feature degrades to a clearly-labeled template if no key is set or the network is down, rather than breaking. |
| `device.js` | `tel:` links, WhatsApp deep links, native `navigator.share`, camera/gallery file input, document storage. |
| `app.js` | Boots everything: DB init → session check → router (`showSection`) → theme → service worker registration. Always loaded last. |

## Single source of truth

Per your "no duplicate data" requirement: **students are the one entity**
that the Lead → Graduation journey is tracked against. Admissions, Marketing
leads, Mentor assignments, Coordinator hostel views and Attendance all
**read from and write to the same `students` IndexedDB store** — they don't
keep their own separate copies. A lead becomes a student record at the
`Lead` stage the moment it's created; updating its `stage` field is what
moves it through Inquiry → Counselling → ... → Graduated.

## Data flow example: a lead becomes a graduate

1. Marketing adds a lead (`marketing.js → saveNewLead()`) → inserts into
   `leads` (for marketing-specific fields like `source`) **and** into
   `students` at stage `Lead` (the canonical record).
2. Admission Manager opens **Students**, finds them, clicks
   **Update Stage** repeatedly as counselling/documents/payment progress —
   each change is timestamped into `student.lifecycle{}`.
3. Coordinator marks hostel allocation once `stage = Arrived`.
4. Mentor logs reports once `stage = Studying`/`Academic`.
5. Attendance module reads the same `students` store filtered by `batch` and
   `stage`, so attendance percentage feeds back into the same record's
   `attendance_pct` field, which Mentor and Admin dashboards both read.

Every role sees a different *view* of the same underlying record — never a
separate, divergent copy.
