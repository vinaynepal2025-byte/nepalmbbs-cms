# 08 — Maintenance

## Routine backups

There is no automatic cloud backup in this version (that requires the
server upgrade in `09-FUTURE-UPGRADES.md`). Make exporting a habit:

- **Weekly**, or before any major data entry session: Profile → Admin
  Control Panel → System → **Export Full Backup**.
- Store the downloaded `.json` file somewhere safe (a password-protected
  zip, a private cloud folder, an encrypted USB drive). See
  `06-SECURITY.md` for why this file needs careful handling.

## Updating the app after you change code

```bash
git add .
git commit -m "Describe the change"
git push
```

GitHub Pages redeploys automatically within about a minute. Because the
service worker (`sw.js`) caches the app shell aggressively for offline use,
staff may need to either:
- Wait — the service worker checks for updates on each load and swaps in
  the new version after the *next* full reload, or
- Manually force it: in the browser, open DevTools → Application →
  Service Workers → "Unregister", then hard-refresh.

If you change the **list of cached files** (e.g. you add a new `.js`
module), bump the cache name in `sw.js`:

```js
const CACHE_NAME = 'nepalmbbs-cms-v2'; // was v1
```

This forces the old cache to be discarded on the next activate event — see
the `activate` listener in `sw.js`, which deletes any cache whose name
doesn't match `CACHE_NAME`.

## Adding a new staff member

Admin → Users → **+ Add Staff** → fill name/email/role/temporary password
→ tell them their temporary password out-of-band (don't email it in plain
text if you can avoid it) → they sign in and you can later add a
"change password" flow if you want one (not built yet — see note below).

## Common issues & fixes

**"No account found. Please run First Setup."** on login
→ The browser's IndexedDB was cleared (e.g. user cleared site data, or
  it's a fresh device/browser profile). If you have a backup JSON, the fix
  is: run First Setup again to get back into the app, then immediately use
  Admin → System → Import Backup to restore everyone's data. If you don't
  have a backup, the data is genuinely gone — this is exactly why regular
  exports matter.

**AI features show the offline fallback even with a key saved**
→ Check Profile → Gemini AI Assistant — the key input shows masked dots if
  one is already saved; re-enter it if you're unsure it saved correctly.
  Also check the browser console for a `Gemini API error` — usually means
  the key is invalid/expired or the free-tier quota was hit for the day.

**App doesn't update after I pushed new code**
→ See the service worker cache-busting note above.

**A student's attendance percentage looks wrong**
→ `attendance_pct` on the student record is currently a **manually-set
  field**, not automatically recalculated from the `attendance` store's
  individual session records. If you want it auto-computed (e.g. "average
  of last 30 days' sessions"), that's a small, well-contained addition to
  `attendance.js → saveAttendance()` — ask and it can be added without
  touching anything else.

**I need to change a user's role after creating them**
→ See the workaround in `03-ROLE-PERMISSIONS.md` (export, edit JSON,
  re-import) until a dedicated edit-role UI is added.

## Known gaps to be aware of (not bugs — by design, for v1)

- No password-reset flow (forgot password). For now: Super Admin can
  export the backup, manually generate a new SHA-256 hash for the user
  (or simpler: delete and recreate their account).
- Team Chat (Comms → Team Chat tab) is a visual placeholder — see
  `09-FUTURE-UPGRADES.md` for the real-time chat upgrade path.
- Google Drive picker (Documents → Drive button) shows an explanatory
  toast instead of a real picker, since that requires a Google Cloud
  OAuth client you'd need to register yourself — instructions are in
  `09-FUTURE-UPGRADES.md`.
