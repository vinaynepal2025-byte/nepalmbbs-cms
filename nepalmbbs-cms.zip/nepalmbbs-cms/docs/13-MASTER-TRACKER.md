# 13 — Master Feature Tracker (Your Working System)

This file is the answer to "how do I make sure nothing gets missed going
forward." Use it exactly like this, every time:

## The 3-step process for every new request

### Step 1 — You ask, I log it here FIRST

Before I write any code for a new feature, I add a row to the table below
with status **🔵 Requested**. This means: even if a session ends or the
chat limit hits mid-build, there is a permanent written record in your
project files (not just in chat history, which can be hard to scroll back
through) of exactly what you asked for and that it isn't done yet.

### Step 2 — I build it, then update the row to 🟡 In Progress → ✅ Done

When a feature is genuinely complete (real data, not a placeholder), I:
1. Update its row here to ✅ Done, with the date and which files changed
2. Run the same verification suite every time (syntax check, div balance,
   function cross-reference, store consistency) — shown in the chat so you
   can see the proof, not just take my word for it
3. Bump `sw.js`'s cache version and add new files to its asset list (a
   mistake I made twice before catching it — now it's a standing checklist
   item every time, see Step 4)

### Step 3 — You verify on your end before we move to the next item

Quick checklist for you, every time you get a new zip:
1. Replace the folder, restart the server, hard-refresh the browser
   (Ctrl+Shift+R) so the new service worker takes over
2. Open the specific section that was just built
3. Try the "happy path" (add one real entry) AND one "edge case" (leave a
   required field empty, see if it's rejected properly)
4. Check `docs/12-REQUIREMENTS-AUDIT.md` — does the row for that feature
   now say ✅ instead of 🟡 or ❌?

If something doesn't work as expected, tell me specifically what you did
and what happened — that's more useful to me than "it's not working,"
because I can't see your screen.

---

## Live Feature Tracker

Legend: 🔵 Requested · 🟡 In Progress · ✅ Done · ❌ Won't build (with reason)

| # | Feature | Status | Files | Notes |
|---|---|---|---|---|
| 1 | Core app shell, auth, dashboard, students lifecycle | ✅ | `index.html`, `js/db.js`, `js/auth.js`, `js/students.js`, etc. | Initial build |
| 2 | Tasks, Admissions, Attendance, Calendar, Marketing, Mentor, Coordinator, Comms, Reports, Admin panel, AI, Device hooks | ✅ | 19 original JS modules | Initial build |
| 3 | Expenses (centralized, Admin+Marketing+Coordinator) | ⚠️ Superseded by #17 | `js/expenses.js` | Original version misunderstood the use case — see row 17 |
| 4 | View As mode (single admin operates all roles) | ❌ Removed (row 19) | — | Created more confusion than clarity — replaced by a simpler model, see row 19 |
| 5 | Mobile usage guide for real sub-admins | ✅ | `docs/11-MOBILE-USAGE-GUIDE.md` | Documentation, not code |
| 6 | Genuine requirements audit vs. original master prompt | ✅ | `docs/12-REQUIREMENTS-AUDIT.md` | Living document, updated every session |
| 7 | Hostel management (real rooms, allocation, check-out) | ✅ | `js/hostel.js`, `db.js` (+2 stores) | Replaced fake hardcoded numbers |
| 8 | Visitor/lead intake (from original reference file) | ✅ | `js/visitors.js`, `db.js` (+1 store) | Full intake form, CSV export |
| 9 | This tracker file itself | ✅ | `docs/13-MASTER-TRACKER.md` | You're reading it |
| 10 | Library (real book issue/return tracking) | 🔵 Requested | — | Next in your stated priority list |
| 11 | Complaints (real submit + resolve workflow) | 🔵 Requested | — | Next in your stated priority list |
| 12 | Fee Ledger (distinct from Expenses) | 🔵 Requested | — | Next in your stated priority list |
| 13 | Real-time multi-device sync (Supabase) | 🔵 Requested | — | Biggest architecture change — needs a dedicated planning session before coding starts |
| 14 | Team Chat (real, not placeholder) | 🔵 Requested | — | Depends on #13 for true real-time, or can be built device-local-only first |
| 15 | Excel upload/import (from your handwritten notes — coordinator/mentor batch attendance via Excel) | 🔵 Requested | — | Seen in your handwritten notes photo, not yet formally requested in chat — confirm if you want this |
| 16 | Marksheet/result generation (from your handwritten notes + screenshot) | 🔵 Requested | — | Seen in your reference screenshot — confirm if you want this built |
| 17 | Expenses rebuilt as **personal claim sheet** (corrected understanding) | ✅ | `js/expenses.js` (rewritten), `index.html`, `js/dashboard.js`, `js/reports.js` | Custom free-text categories, private per-user data (no org-wide visibility), no approval workflow, "Submit to Boss" via WhatsApp/Email/Share/CSV. See note below. |
| 18 | "Full proof" audit of Visitors + Expenses + Attendance | ✅ | `js/db.js`, `js/attendance.js`, `js/reports.js`, `js/expenses.js` | Found and fixed 3 real bugs — see details below |
| 19 | Simplified to strict one-login-one-role model (View As removed) | ✅ | `js/app.js`, `js/dashboard.js`, `index.html`, `sw.js` | Each account's role is fixed at creation; dashboard is 100% automatic based on who's logged in. No preview/switch mode. See note below. |

---

## How to add a new request yourself

Just tell me in plain language what you want. I'll:
1. Ask clarifying questions if the scope is ambiguous (like I did for
   Expenses and Hostel) — this prevents building the wrong thing
2. Add a row here with 🔵 Requested before writing code
3. Build it as a complete, real module — not a UI shell with fake data
4. Run the full verification suite and show you the results
5. Update this tracker to ✅ Done

## How to do a full audit yourself, any time

Open `docs/12-REQUIREMENTS-AUDIT.md` — it's organized by your exact
original master prompt sections (Primary Admin, User Roles, Interconnected
System, Student Lifecycle, AI Integration, Design, Security, Free
Technology Policy). Every single line item from what you originally asked
for is marked ✅/🟡/❌ with the honest reason. Cross-reference that against
this tracker's "Live Feature Tracker" table to see what's been
specifically built since.

## Final clarification: how login and roles actually work (row 4 → row 19)

This needed to be made completely unambiguous, so "View As" mode (rows 4,
10) was **removed entirely** rather than kept alongside a separate
explanation. The system is now as simple as it can possibly be:

**One person = one account = one email/password = one fixed role.**

When that account logs in, the correct dashboard, bottom navigation, and
permissions appear **automatically** — there is no menu, button, or mode
to switch between roles. A Marketing account always sees the Marketing
dashboard. A Coordinator account always sees the Coordinator dashboard.
The Super Admin account always sees full access to everything, including
the Admin Control Panel that no other role can reach.

If you personally need to operate multiple roles' worth of work (you're
doing Marketing tasks AND Coordinator tasks yourself), the honest answer
is: **every section is reachable from the Super Admin dashboard already**
— Admissions, Marketing, Coordinator Hub, Mentor Center, Attendance are
all real navigable sections, not hidden behind a role check, for
Super Admin and Admin accounts. You don't need a "pretend to be Marketing"
mode to use the Marketing section — you already have full access to it
as yourself. The dashboard's Quick Actions and bottom nav are just a
*shortcut layout* tuned per role for convenience; they were never an
access restriction for Admin accounts in the first place.

When you eventually bring on real staff for a specific role, create
their own account (Admin → Users → Add Staff) with their own
email/password, and their dashboard will automatically be scoped to just
their role — simple, predictable, and exactly matching how real
accountability and audit logging are supposed to work.

## A correction worth understanding: Expenses (row 3 → row 17)

The first version of Expenses (built early in this project) assumed it was
a **college-wide operational ledger** — every Admin/Marketing/Coordinator
adding entries, all visible to everyone in the organization, with
categories like "Hostel" and "Marketing" that match organizational
spending.

You clarified the REAL use case: **one person plays multiple roles at the
same college and needs their own personal expense claim sheet** — money
they spent out of pocket (auto fare, food, printing, phone bills) that
they need to report to their employer for reimbursement alongside salary.
This is fundamentally different: private to each person, free-text
categories (not a fixed organizational list), no approval workflow, and
the actual goal is a polished "send this to my boss" action.

The module has been rebuilt to match this correctly. If you ever DO want a
separate college-wide operational expense ledger (tracking institutional
spending, not personal reimbursement) alongside this personal one, that
would be a new, differently-named feature — tell me and I'll scope it
properly as its own row here rather than conflating the two again.

## "Full proof" audit findings (row 18) — what was actually wrong

You asked me to verify Visitors, Expenses, and Attendance were genuinely
complete before moving on. I traced every function call rather than just
re-reading code, and found 3 real bugs — all now fixed:

1. **Critical: existing IndexedDB stores never received new indexes.**
   `js/db.js`'s upgrade logic skipped any store that already existed,
   meaning every previous `DB_VERSION` bump (for Hostel, Visitors) may have
   silently failed to add their indexes on a browser that already had data
   from an earlier version. Fixed: the upgrade logic now adds missing
   indexes to existing stores too, not just brand-new ones.
2. **Privacy bug in Expenses + Reports:** `dbGetByIndex('expenses',
   'user_id', CU?.id)` — if `CU?.id` were ever `undefined`, IndexedDB's
   `index.getAll(undefined)` returns **every** record with no filter,
   which would have leaked every user's private expenses. Fixed with an
   explicit guard in both `expenses.js` and `reports.js`.
3. **Attendance percentage was never auto-calculated.** Students had an
   `attendance_pct` field shown throughout the app (Student detail,
   Mentor view, Dashboard risk flags), but nothing ever recalculated it
   after saving attendance — it stayed at whatever value the demo seed
   data set it to. Fixed: `saveAttendance()` now recalculates each
   affected student's real percentage from their full attendance history
   every time.

Also closed a smaller integration gap: **Visitors data didn't appear
anywhere in Reports** (Expenses and Students did, Visitors didn't) —
added a Visitors summary card to the Reports overview so all three
modules you asked about are now equally visible from one place.

## What I noticed in your handwritten notes photo

Your photo (uploaded earlier) has additional detail not yet formally
discussed in this chat — worth confirming explicitly so it's tracked
properly rather than silently lost:

- "Reports could be downloaded on WhatsApp/mail" — partially covered by
  the native Share button in Reports, but not a dedicated WhatsApp-specific
  report export
- "Reports generation should be individual" — per-person report filtering;
  not yet built, currently reports are org-wide only
- ".docx format reports" — current export is JSON/CSV only, not Word
  documents
- "Indian Coordinator & Mentor: all date wise upload, attendance via excel
  upload" — Excel import for attendance is not built (current attendance
  is manual entry only)
- "Marksheet/result generation with college logo, format given" — matches
  your uploaded result screenshot exactly; not yet built
- "Centralized with all roles" / "All roles are interconnected" — addressed
  architecturally (single source of truth for students), but real-time
  cross-device sync is the explicit gap documented in #13 above

Tell me which of these (15, 16, or the notes items above) you want
prioritized next, and I'll add proper rows and start building the same
careful way.
