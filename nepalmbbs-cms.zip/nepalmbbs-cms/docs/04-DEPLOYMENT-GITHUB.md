# 04 — Deployment (GitHub Pages → cms.nepalmbbs.in)

This gets you from "files on my computer" to "live at a subdomain of
nepalmbbs.in" using only free tools, with **no conflict with your main
domain** as you specified.

## Step 1 — Create the GitHub repository

1. Go to github.com → New repository → name it `nepalmbbs-cms` (or
   anything) → Public or Private, your choice → **do not** initialize with a
   README (you already have one).
2. Push your local folder:

```bash
cd nepalmbbs-cms
git init
git add .
git commit -m "Initial commit — NepalMBBS CMS v3.0"
git branch -M main
git remote add origin https://github.com/<your-username>/nepalmbbs-cms.git
git push -u origin main
```

## Step 2 — Enable GitHub Pages

1. Repo → **Settings → Pages**
2. Under "Build and deployment", Source = **Deploy from a branch**
3. Branch = `main`, folder = `/ (root)` → **Save**
4. Wait ~60 seconds, then refresh — GitHub shows
   `https://<your-username>.github.io/nepalmbbs-cms/`. Open it and confirm
   the app loads.

## Step 3 — Add the custom subdomain

You want `cms.nepalmbbs.in` (or any subdomain you prefer — `app.`,
`portal.`, etc.) to point at this Pages site **without touching your main
domain's existing records**.

1. In the repo root, create a file named exactly `CNAME` (no extension)
   containing one line:
   ```
   cms.nepalmbbs.in
   ```
   Commit and push it.
2. In **Settings → Pages**, under "Custom domain", enter `cms.nepalmbbs.in`
   and save. GitHub will show a DNS check (pending) until step 3 below is
   done.
3. In your domain's DNS provider (wherever `nepalmbbs.in` is registered —
   Cloudflare, GoDaddy, Namecheap, etc.), add **one new record** — this is
   the "no conflict with the main domain" part, since it's a new
   subdomain, not a change to `nepalmbbs.in`'s existing A/MX/etc. records:

   | Type | Name | Value |
   |---|---|---|
   | CNAME | `cms` | `<your-username>.github.io` |

   (If your DNS provider doesn't allow CNAME at a subdomain for some
   reason, use 4 A records pointing `cms` at GitHub Pages' IPs:
   `185.199.108.153`, `185.199.109.153`, `185.199.110.153`,
   `185.199.111.153` — but CNAME is simpler and is supported almost
   everywhere.)

4. Wait for DNS propagation (5 minutes to a few hours, rarely longer).
   Back in **Settings → Pages**, tick **Enforce HTTPS** once the green
   checkmark appears — GitHub provisions a free SSL certificate
   automatically.

## Step 4 — Verify the PWA installs correctly on the real domain

Service workers are scoped to the origin they're served from, so test
*after* the subdomain is live, not just on the `github.io` URL:

1. Open `https://cms.nepalmbbs.in` on a phone.
2. Browser menu → **Add to Home Screen** / **Install App**.
3. Open the installed icon — it should launch full-screen with no browser
   chrome, confirming `manifest.json` and `sw.js` are both being served
   correctly.

## Step 5 — Updating the live site later

Every `git push` to `main` redeploys automatically within about a minute.
No manual "publish" step.

```bash
git add .
git commit -m "Describe what changed"
git push
```

## Alternative free hosts (if you ever want to switch)

- **Netlify**: drag-and-drop the folder at app.netlify.com/drop, or connect
  the GitHub repo for auto-deploys. Free tier is generous; custom domain
  support is just as easy as GitHub Pages.
- **Vercel**: same idea, `vercel.com/new`, import the GitHub repo.

Both work identically for a static app like this one — pick whichever
dashboard you find more comfortable. GitHub Pages is recommended here
because you specifically asked for a GitHub-based sequence.
