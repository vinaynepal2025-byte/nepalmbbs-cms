# 07 — Testing Checklist

Before you hand this to real staff, click through this list once. Each item
takes a few seconds; the whole pass takes about 20 minutes.

## First run
- [ ] Open the deployed URL. The liquid-glass login card appears with
      animated background orbs.
- [ ] Tap **First Setup**, fill the form with a deliberately weak password
      (e.g. "abc") → confirm it's rejected with "minimum 8 characters".
- [ ] Fill it correctly and submit → toast confirms account creation → tab
      switches back to Sign In with your email pre-filled.
- [ ] Sign in with the wrong password → toast shows "Invalid credentials".
- [ ] Sign in with the correct password → app loads, dashboard greets you
      by name with the correct time-of-day greeting.

## Offline behavior
- [ ] With the app open, turn on Airplane Mode (or disconnect Wi-Fi).
- [ ] Navigate between sections (Students, Tasks, Calendar) — everything
      should still work since data is local.
- [ ] Add a new student while offline → should save without error.
- [ ] Turn network back on → a "Back online" toast should appear.

## Install as PWA
- [ ] On a phone browser, use "Add to Home Screen" / the Install button in
      Profile → Install App.
- [ ] Launch from the home screen icon → app opens full-screen, no browser
      address bar.

## Students / lifecycle
- [ ] Add a new student via the ➕ floating button — fill only the required
      Name field, leave everything else blank → should save successfully
      (no required fields beyond name).
- [ ] Open the new student → check all 4 tabs (Info, Journey, Academic,
      Contact) render without errors, even with empty fields showing "N/A".
- [ ] Tap **Update Stage** → pick a later stage → confirm the badge on the
      student card updates immediately.
- [ ] Search for the student by partial name in the Students search bar.
- [ ] Use the stage filter chips (Lead, Inquiry, etc.) → list should filter
      correctly with the demo data seeded at setup.

## Tasks
- [ ] Add a task with High priority and a due date in the past → it should
      show "Overdue" in red on the task list.
- [ ] Tap the round checkbox to mark it done → strike-through applies, stat
      counts update.
- [ ] Filter by "High Priority" chip → only unfinished high-priority tasks
      show.

## Attendance
- [ ] Go to Attendance → pick the batch matching your demo data
      (MBBS 2024) → today's date → type any subject name → Load Students.
- [ ] Mark a mix of P/A/L → Save → confirm a success toast and that History
      below updates with the new session's percentage.

## Calendar
- [ ] The month view shows today highlighted.
- [ ] Tap a future date → Add Event modal opens with that date pre-filled.
- [ ] Save it → confirm it appears in Upcoming Events.
- [ ] Navigate to next/previous month with the ‹ › arrows.

## Marketing (switch to a marketing-role test account, or use admin)
- [ ] Add a lead → confirm a success toast.
- [ ] Confirm that same person now also appears in Students at the "Lead"
      stage (this is the single-source-of-truth behavior).

## Notifications
- [ ] Bell icon shows a red dot when unread notifications exist.
- [ ] Open Notifications → tap one → dot disappears after reading, list
      re-renders without the unread highlight.
- [ ] "Mark all read" clears the bell dot entirely.

## AI Assistant (with and without a Gemini key)
- [ ] Without any key configured: tap any AI quick-action (e.g. "Summary")
      → should show a clearly-labeled offline fallback message, not an
      error or a crash.
- [ ] Add a real key via Profile → Gemini AI Assistant → repeat the same
      action → should show a real generated response within a few seconds.

## Admin panel (Super Admin account only)
- [ ] Confirm a non-admin test account does NOT see "Admin Control Panel"
      in their Profile settings list.
- [ ] As Super Admin, go to Admin → Users → Add Staff → create one of each
      role → confirm each appears in the list with the correct badge color.
- [ ] Admin → Audit → confirm your recent actions (logins, student adds,
      task creation) appear with correct relative timestamps.
- [ ] Admin → System → Export Full Backup → confirm a `.json` file
      downloads.
- [ ] Reload the page fresh (or test on a second browser profile), Admin →
      System → Import Backup → select that file → confirm data restores
      after the automatic reload.

## Theme & accessibility
- [ ] Profile → toggle Dark/Light mode → entire app re-themes without
      reload.
- [ ] Tab through the login form using only the keyboard → focus rings
      should be visible on every interactive element.
- [ ] Enable "Reduce Motion" in your OS accessibility settings → reload the
      app → background orb animation and transitions should stop/shorten
      (this is handled by the `prefers-reduced-motion` CSS query in
      `styles.css`).

## Multi-role spot check
- [ ] Create one account per role (Admission Manager, Marketing,
      Coordinator, Mentor, Counsellor) via Admin → Users.
- [ ] Log in as each one in turn (use a private/incognito window so
      sessions don't clash) → confirm the bottom nav and dashboard Quick
      Actions match the table in `03-ROLE-PERMISSIONS.md`.

If everything above passes, you're ready to hand this to real staff.
