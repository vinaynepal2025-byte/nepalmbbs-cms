# 05 — Gemini AI Setup (free tier)

The app's AI features (report drafting, parent emails, translation,
risk-flag suggestions, per-student summaries) call Google's Gemini API
**directly from your browser**. There is no middleman server, which means:

- Your data goes straight from your device to Google — never through any
  server we control.
- You need your own API key, and you pay Google directly if you ever
  exceed the free tier (unlikely for normal day-to-day use by one
  organization).

## Get a free API key

1. Go to **aistudio.google.com** (Google AI Studio).
2. Sign in with any Google account.
3. Click **"Get API key"** → **"Create API key"**.
4. Copy the key (starts with `AIza...`).

Google's free tier (as of writing) allows a generous number of requests per
minute/day on the `gemini-1.5-flash` model — the model this app uses by
default specifically because it's the free-tier-friendly option, not the
more expensive Pro model.

## Add it to the app

1. Open the app → **Profile → Gemini AI Assistant**.
2. Paste the key → **Save Key**.
3. The key is stored in `localStorage` **on this device only** — it is
   never synced anywhere, never included in backups exported via Admin →
   System (check `js/db.js` — `STORE_DEFS` doesn't include API keys), and
   never sent to anyone except Google's API endpoint when you actually use
   an AI feature.

## What happens without a key

Every AI feature in this app checks for a key first
(`js/ai.js → callGemini()`). If none is set, or the network request fails,
the feature falls back to a clearly-labeled offline message rather than
pretending to be live AI or crashing:

```
[Offline mode — no Gemini key configured] I can't reach Gemini right
now. Add a free API key in Profile → Gemini AI Assistant...
```

This was a deliberate choice from the master prompt's "only integrate AI
where it genuinely improves workflow" instruction — the app should be
fully usable by colleges who don't want to set up AI at all.

## Per-device keys in a multi-staff deployment

Since the key lives in each device's `localStorage`, every staff member who
wants AI features needs to add their own key (or you give everyone the same
key — Google allows that, it's just one account's quota shared across
people). There's no central "organization API key" setting in this version;
that would require a small server to broker the key safely, which is exactly
the kind of backend described in `09-FUTURE-UPGRADES.md`.

## Which model and why

`js/ai.js` hardcodes `gemini-1.5-flash`:

```js
const GEMINI_MODEL = 'gemini-1.5-flash';
```

Flash is fast, free-tier-friendly, and more than capable for the
summarization/drafting/translation tasks this app asks of it. If Google
changes free-tier model names in the future, update this one constant —
nothing else in the codebase needs to change.
