# 09 — Future Upgrades (Phase 2 Roadmap)

The original brief asked for several capabilities that genuinely require a
backend server or paid infrastructure to do properly and safely: real-time
multi-device sync, push notifications, payment-adjacent fee tracking,
multi-college tenancy, and bank-grade security. Rather than fake these with
client-only workarounds that would mislead you about what's actually
protecting your data, they're documented here as a clear, buildable
roadmap — each with a free-tier-first option.

## 1. Multi-device real-time sync (replace/augment IndexedDB)

**Problem today**: each device has its own isolated IndexedDB. Two
coordinators on two phones don't see each other's edits in real time.

**Free-tier path**: [Supabase](https://supabase.com) — open-source
Firebase alternative, generous free tier (500MB database, 50K monthly
active users at time of writing), Postgres-backed, has a JS client library
nearly as simple as our current `db.js` wrapper.

**What changes**: swap `js/db.js`'s IndexedDB calls for Supabase client
calls. Because every other module only ever calls `dbGetAll()`, `dbPut()`,
etc. — never touches IndexedDB directly — **this is a one-file change**,
not a rewrite. Budget: a few days of focused work, mostly around mapping
IndexedDB's flexible schema to Postgres tables with proper foreign keys.

## 2. Real push notifications

**Problem today**: "Notifications" only show up when someone opens the
app — there's no background push to a phone that's closed.

**Free-tier path**: Firebase Cloud Messaging (FCM) is free at any scale for
this kind of use case. Requires: a Firebase project (free), a small service
worker addition (`firebase-messaging-sw.js`), and — because actually
*sending* a push requires a trusted server holding your FCM server key —
a minimal serverless function (Supabase Edge Functions or Cloudflare
Workers, both free-tier).

## 3. Fee tracking with real payment status (NOT a payment gateway)

Per your explicit instruction, this app never touches bank/UPI credentials.
**Expense tracking (Travel/Food/Hotel/Media/Hostel/Marketing) is already
built** — see Expenses in the app, accessible to Admin, Marketing and
Coordinator roles, centralized across the same `expenses` IndexedDB store
your reports pull from. What's still future work: a proper **student fee
ledger** ("fee paid: yes/no, amount, date, method") using the already
reserved `fees` store — a ledger, not a payment processor. If you eventually
want students to pay *through* the app, that requires a licensed payment
gateway (Razorpay, Stripe) and is explicitly out of scope per your
instructions.

## 4. Multi-college tenancy

**Problem today**: one deployment = one organization (`CU.org` is set once
at First Setup and never really separates data beyond a string filter).

**Two options**:
- **Simple (free, available today)**: deploy a second copy of this exact
  repo to a second subdomain (`cms2.nepalmbbs.in`) for a second college.
  Zero code change, zero extra cost on GitHub Pages.
- **Proper multi-tenant (needs the Supabase backend)**: add an
  `organization_id` foreign key to every table, add row-level security
  policies in Postgres so college A's queries can never return college B's
  rows even if someone tries, and add an org-switcher to the Super Admin's
  UI if one person manages multiple colleges.

## 5. Real-time Team Chat

**Problem today**: Comms → Team Chat is a static placeholder.

**Free-tier path**: Supabase Realtime (part of the same free Supabase
project from #1) gives you WebSocket-based live chat with very little
code — subscribe to a `messages` table, append rows, done.

## 6. Biometric login / WebAuthn

**Free, no backend required** — this one you could add today without any
server. The Web Authentication API (WebAuthn) is supported in all modern
mobile browsers and lets a user register their device fingerprint/face
unlock as a credential. It's a moderate amount of focused crypto-adjacent
code; flagged as future work here rather than rushed into v1 given the
security-sensitivity of getting it wrong.

## 7. Google Drive picker (real OAuth, not a placeholder)

Requires registering a free Google Cloud project, enabling the Drive API,
and creating an OAuth 2.0 Client ID (all free). Once you have a client ID,
`js/device.js → uploadDoc('drive')` is the one function that needs the real
`google.picker` integration instead of today's explanatory toast.

## 8. Auto-calculated attendance percentage

Small, contained: instead of `attendance_pct` being a manually-set field on
the student record, compute it on the fly from the `attendance` store's
individual `P`/`A`/`L` rows for that student over a rolling window (e.g.
last 30 days or current semester). This doesn't need any new
infrastructure — happy to add it as a direct follow-up if you want it now
rather than later.

## 9. Edit-role / edit-user UI

Currently you can create staff but not edit an existing one's role or
deactivate them from the UI (only via the backup-export-edit-reimport
workaround in `08-MAINTENANCE.md`). A proper edit screen in `admin.js` is
a small, self-contained addition.

## Suggested order if you decide to invest further

1. Auto-calculated attendance (#8) and edit-user UI (#9) — quick wins, no
   new infrastructure, improve daily usability immediately.
2. Supabase backend swap (#1) — unlocks everything else (#2, #3, #4, #5)
   without re-architecting the front end you already have.
3. Push notifications (#2) and real chat (#5) — biggest "feels like a real
   product" upgrade once the backend exists.
4. Multi-tenancy (#4) and biometric login (#6) — once you're running this
   for real, for multiple colleges, with real staff depending on it daily.
