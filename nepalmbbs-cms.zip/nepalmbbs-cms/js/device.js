/* ═══════════════════════════════════════════════════
   device.js — Device feature hooks
   Camera/gallery upload, native Share, click-to-call,
   WhatsApp deep links, external app links.
   These use standard Web APIs available in any modern mobile
   browser / installed PWA — no native binary required.
═══════════════════════════════════════════════════ */
'use strict';

function callNumber(phone) {
  if (!phone) { toast('No phone number on file', 'warning'); return; }
  window.location.href = `tel:${phone}`;
}

function whatsappNumber(phone, name = '') {
  if (!phone) { toast('No phone number on file', 'warning'); return; }
  const clean = phone.replace(/[^\d+]/g, '');
  const text = encodeURIComponent(`Hello ${name}, this is regarding your application at ${CU?.org || 'our college'}.`);
  window.open(`https://wa.me/${clean.replace('+', '')}?text=${text}`, '_blank');
}

function shareText(title, text) {
  if (navigator.share) {
    navigator.share({ title, text }).catch(() => {});
  } else if (navigator.clipboard) {
    navigator.clipboard.writeText(text);
    toast('Copied to clipboard', 'success');
  } else {
    toast('Sharing not supported on this device', 'warning');
  }
}

function openExternalLink(url) {
  window.open(url, '_blank', 'noopener,noreferrer');
}

/** Opens the device camera or gallery picker and stores the photo
 *  as a base64 document record linked to nothing in particular —
 *  caller can extend this to attach it to a student record. */
function uploadDoc(source) {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = source === 'camera' ? 'image/*' : (source === 'gallery' ? 'image/*' : '*/*');
  if (source === 'camera') input.setAttribute('capture', 'environment');
  input.onchange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async (ev) => {
      await dbPut('documents', {
        id: genId(), name: file.name, type: file.type, size: file.size,
        data: ev.target.result, org: CU?.org, uploaded_by: CU?.id,
        uploaded_at: new Date().toISOString(),
      });
      toast(`${file.name} uploaded`, 'success');
      auditLog('document_uploaded', { name: file.name });
    };
    reader.readAsDataURL(file);
  };
  if (source === 'drive') {
    toast('Google Drive picker requires a Google Cloud project + OAuth client. See docs/09-FUTURE-UPGRADES.md for the free setup guide.', 'info');
    return;
  }
  input.click();
}

async function loadDocuments() {
  const el = document.getElementById('doc-list');
  if (!el) return;
  const docs = await dbGetAll('documents');
  const myDocs = CU?.org ? docs.filter(d => d.org === CU.org) : docs;
  if (!myDocs.length) {
    el.innerHTML = '<div class="empty-state"><div class="empty-icon">📁</div><div class="empty-title">No documents yet</div></div>';
    return;
  }
  el.innerHTML = myDocs.map(d => `
    <div class="list-item">
      <div class="list-avatar" style="background:var(--grad-blue)">📄</div>
      <div class="list-info"><div class="list-name">${escapeHtml(d.name)}</div><div class="list-meta">${(d.size / 1024).toFixed(0)} KB · ${timeAgo(d.uploaded_at)}</div></div>
    </div>`).join('');
}
