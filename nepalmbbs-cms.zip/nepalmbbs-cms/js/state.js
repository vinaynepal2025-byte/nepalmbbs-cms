/* ═══════════════════════════════════════════════════
   state.js — Global app state, role config, constants
═══════════════════════════════════════════════════ */
'use strict';

let CU = null; // Current logged-in user (session object)

const APP_STATE = {
  activeSection: 'dashboard',
  theme: localStorage.getItem('cms_theme') || 'dark',
  aiEnabled: localStorage.getItem('cms_ai') !== 'false',
  notifications: [],
  students: [],
  tasks: [],
  calendarDate: new Date(),
};

// ── Roles ──
const ROLES = {
  superadmin:        { label: 'Super Admin',       color: 'violet', emoji: '👑' },
  admin:             { label: 'Admin',             color: 'violet', emoji: '⚙️' },
  admission_manager: { label: 'Admission Manager', color: 'blue',   emoji: '📋' },
  marketing:         { label: 'Marketing Team',    color: 'green',  emoji: '📣' },
  coordinator:       { label: 'Coordinator',       color: 'amber',  emoji: '🤝' },
  mentor:            { label: 'Mentor',            color: 'teal',   emoji: '🎓' },
  counsellor:        { label: 'Counsellor',        color: 'rose',  emoji: '🎯' },
};

// ── Nav icon/label config ──
const NAV_CONFIG = {
  dashboard:    { icon: '🏠', label: 'Home' },
  students:     { icon: '👨‍🎓', label: 'Students' },
  admissions:   { icon: '📋', label: 'Admissions' },
  visitors:     { icon: '👥', label: 'Visitors' },
  tasks:        { icon: '✅', label: 'Tasks' },
  reports:      { icon: '📊', label: 'Reports' },
  notifications:{ icon: '🔔', label: 'Alerts' },
  profile:      { icon: '👤', label: 'Profile' },
  marketing:    { icon: '📣', label: 'Marketing' },
  attendance:   { icon: '📅', label: 'Attend' },
  mentor:       { icon: '🎓', label: 'Mentor' },
  coordinator:  { icon: '🤝', label: 'Coord' },
  comms:        { icon: '💬', label: 'Comms' },
  expenses:     { icon: '🧾', label: 'Expenses' },
  calendar:     { icon: '📆', label: 'Calendar' },
  admin:        { icon: '⚙️', label: 'Admin' },
  ai:           { icon: '✨', label: 'AI' },
};

// ── Bottom nav items per role (max 5 for thumb reach) ──
const ROLE_NAV = {
  superadmin:        ['dashboard', 'students', 'visitors', 'tasks', 'profile'],
  admin:             ['dashboard', 'students', 'visitors', 'tasks', 'profile'],
  admission_manager: ['dashboard', 'visitors', 'admissions', 'tasks', 'profile'],
  marketing:         ['dashboard', 'marketing', 'visitors', 'tasks', 'profile'],
  coordinator:       ['dashboard', 'coordinator', 'students', 'attendance', 'profile'],
  mentor:            ['dashboard', 'mentor', 'students', 'attendance', 'profile'],
  counsellor:        ['dashboard', 'visitors', 'admissions', 'tasks', 'profile'],
};

// ── Student lifecycle stages (per the master prompt's journey) ──
const LIFECYCLE_STAGES = [
  'Lead', 'Inquiry', 'Counselling', 'Document', 'Admission', 'Payment',
  'Visa', 'Travel', 'Arrived', 'Hostel', 'Studying', 'Academic', 'Graduated',
];

const STAGE_COLORS = {
  Lead: 'violet', Inquiry: 'blue', Counselling: 'teal', Document: 'amber',
  Admission: 'green', Payment: 'green', Visa: 'amber', Travel: 'blue',
  Arrived: 'teal', Hostel: 'violet', Studying: 'green', Academic: 'green',
  Graduated: 'rose',
};

// ── Organization list (Nepal medical colleges + custom) ──
const ORG_LIST = [
  'CMC Nepal', 'Chitwan Medical College', 'Kathmandu Medical College',
  'KIST Medical College', 'Nobel Medical College', 'Lumbini Medical College',
  'Nepalgunj Medical College', 'Universal College Nepal', 'Gandaki Medical College',
  'Manipal Nepal', 'AIIMS Delhi', 'Other India',
];
