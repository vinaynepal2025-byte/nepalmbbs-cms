/* ═══════════════════════════════════════════════════
   ui-core.js — Toasts, modals, formatting, router helpers
═══════════════════════════════════════════════════ */
'use strict';

function initials(name) {
  if (!name) return '?';
  return name.split(' ').filter(Boolean).map(w => w[0]).join('').toUpperCase().slice(0, 2);
}

function timeAgo(ts) {
  if (!ts) return '';
  const diff = Date.now() - new Date(ts).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return 'just now';
  if (m < 60) return m + 'm ago';
  const h = Math.floor(m / 60);
  if (h < 24) return h + 'h ago';
  const d = Math.floor(h / 24);
  if (d < 7) return d + 'd ago';
  return new Date(ts).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
}

function formatDate(dt) {
  if (!dt) return '—';
  const d = new Date(dt);
  if (isNaN(d.getTime())) return dt;
  return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}

function formatCurrency(n) {
  return '₹' + Number(n || 0).toLocaleString('en-IN');
}

function escapeHtml(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

// ── Toasts ──
function toast(msg, type = 'info', duration = 2800) {
  const icons = { success: '✅', error: '❌', info: 'ℹ️', warning: '⚠️' };
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = (icons[type] || '') + ' ' + msg;
  const c = document.getElementById('toast-container');
  c.appendChild(el);
  setTimeout(() => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(10px)';
    el.style.transition = 'all 0.3s';
    setTimeout(() => el.remove(), 350);
  }, duration);
}

// ── Modals ──
function showModal(html) {
  document.getElementById('modal-container').innerHTML =
    `<div class="modal-overlay" onclick="if(event.target===this)closeModal()">${html}</div>`;
}

function showCenterModal(html) {
  document.getElementById('modal-container').innerHTML =
    `<div class="modal-overlay center" onclick="if(event.target===this)closeModal()">${html}</div>`;
}

function closeModal() {
  document.getElementById('modal-container').innerHTML = '';
}

// ── Audit log ──
function auditLog(action, data = {}) {
  if (!CU) return;
  dbPut('audit_log', {
    id: genId(),
    user_id: CU.id,
    user_name: CU.name,
    action,
    data,
    ts: new Date().toISOString(),
    org: CU.org,
  }).catch(() => {});
}

// ── Stats grid renderer (shared across dashboard/tasks/admissions/etc) ──
function renderStatsGrid(containerId, stats) {
  const el = document.getElementById(containerId);
  if (!el) return;
  el.innerHTML = stats.map(s => `
    <div class="stat-card ${s.color}">
      <div class="stat-icon ${s.color}">${s.icon}</div>
      <div class="stat-value">${s.value}</div>
      <div class="stat-label">${s.label}</div>
      ${s.change ? `<div class="stat-change ${s.up ? 'up' : 'down'}">${s.up ? '↑' : '↓'} ${s.change}</div>` : ''}
    </div>
  `).join('');
}
