/* ═══════════════════════════════════════════════════
   hostel.js — Real hostel room management
   Add/manage access: Admin, Coordinator (hostel is core to their role).
   Two linked concepts:
     - `hostel_rooms` store: the physical room inventory (block, room
       number, capacity, status)
     - `students.hostel` field: still the canonical "where is this
       student living" pointer (single source of truth, unchanged) —
       this module just gives Coordinators a proper UI to manage it
       instead of a free-text field with no real allocation tracking.
═══════════════════════════════════════════════════ */
'use strict';

const HOSTEL_ALLOWED_ROLES = ['superadmin', 'admin', 'coordinator'];
const ROOM_STATUS_COLORS = { available: 'green', full: 'red', maintenance: 'amber' };

function canManageHostel() {
  return HOSTEL_ALLOWED_ROLES.includes(CU?.role);
}

let allHostelRooms = [];
let allHostelStudents = [];

async function loadHostelModule() {
  const el = document.getElementById('coordinator-content');
  if (!el) return;
  el.innerHTML = '<div class="loading-state"><div class="spinner"></div></div>';

  allHostelRooms = await dbGetAll('hostel_rooms');
  if (CU?.org) allHostelRooms = allHostelRooms.filter(r => r.org === CU.org);

  const students = await dbGetAll('students');
  allHostelStudents = CU?.org ? students.filter(s => s.org === CU.org) : students;

  renderHostelView();
}

function renderHostelView() {
  const el = document.getElementById('coordinator-content');
  if (!el) return;

  const totalRooms = allHostelRooms.length;
  const totalCapacity = allHostelRooms.reduce((sum, r) => sum + (Number(r.capacity) || 0), 0);
  const occupiedBeds = allHostelStudents.filter(s => s.hostel).length;
  const availableBeds = Math.max(0, totalCapacity - occupiedBeds);
  const maintenanceRooms = allHostelRooms.filter(r => r.status === 'maintenance').length;

  const blocks = [...new Set(allHostelRooms.map(r => r.block))].sort();

  el.innerHTML = `
    <div class="section-header">
      <div class="section-title">🏠 Hostel Management</div>
      ${canManageHostel() ? `<button class="btn btn-violet btn-sm" onclick="openAddRoom()">+ Room</button>` : ''}
    </div>

    <div class="stats-grid mb-3">
      <div class="stat-card violet"><div class="stat-icon violet">🏠</div><div class="stat-value">${totalRooms}</div><div class="stat-label">Total Rooms</div></div>
      <div class="stat-card green"><div class="stat-icon green">✅</div><div class="stat-value">${occupiedBeds}</div><div class="stat-label">Occupied Beds</div></div>
      <div class="stat-card blue"><div class="stat-icon blue">🔓</div><div class="stat-value">${availableBeds}</div><div class="stat-label">Available Beds</div></div>
      <div class="stat-card amber"><div class="stat-icon amber">🔧</div><div class="stat-value">${maintenanceRooms}</div><div class="stat-label">Maintenance</div></div>
    </div>

    ${canManageHostel() ? `
      <div class="glass-card mb-3">
        <div class="form-group-title">🛏️ Allocate a Student</div>
        <div class="text-xs text-muted mb-2">Assign an unallocated student to an available room</div>
        <button class="btn btn-blue btn-sm" onclick="openAllocateStudent()">+ Allocate Student</button>
      </div>
    ` : ''}

    <div class="section-header"><div class="section-title">Rooms by Block</div></div>
    ${blocks.length ? blocks.map(block => renderBlockCard(block)).join('') : '<div class="empty-state"><div class="empty-icon">🏠</div><div class="empty-title">No rooms set up yet</div><div class="empty-sub">' + (canManageHostel() ? 'Tap + Room to add your first hostel room' : 'Ask your Coordinator or Admin to add rooms') + '</div></div>'}

    <div class="section-header mt-4"><div class="section-title">Currently Allocated Students</div></div>
    <div id="hostel-allocated-list"></div>
  `;

  renderAllocatedList();
}

function renderBlockCard(block) {
  const rooms = allHostelRooms.filter(r => r.block === block);
  const blockCapacity = rooms.reduce((sum, r) => sum + (Number(r.capacity) || 0), 0);
  const blockOccupied = rooms.reduce((sum, r) => sum + getRoomOccupancy(r.id), 0);

  return `
    <div class="glass-card mb-3">
      <div class="flex justify-between items-center mb-2">
        <div class="form-group-title" style="margin-bottom:0;">${escapeHtml(block)}</div>
        <span class="text-xs text-muted">${blockOccupied}/${blockCapacity} beds</span>
      </div>
      ${rooms.map(r => {
        const occ = getRoomOccupancy(r.id);
        const isFull = occ >= r.capacity;
        const statusColor = r.status === 'maintenance' ? 'amber' : (isFull ? 'red' : 'green');
        return `
          <div class="settings-item" onclick="openRoomDetail('${r.id}')">
            <div class="settings-icon" style="background:rgba(139,92,246,0.15);">🚪</div>
            <div class="settings-info">
              <div class="settings-title">Room ${escapeHtml(r.room_number)}</div>
              <div class="settings-sub">${occ}/${r.capacity} occupied${r.status === 'maintenance' ? ' · Under maintenance' : ''}</div>
            </div>
            <span class="badge badge-${statusColor}">${r.status === 'maintenance' ? 'Maintenance' : (isFull ? 'Full' : 'Open')}</span>
          </div>`;
      }).join('')}
    </div>`;
}

function getRoomOccupancy(roomId) {
  const room = allHostelRooms.find(r => r.id === roomId);
  if (!room) return 0;
  const label = `${room.block} Room ${room.room_number}`;
  return allHostelStudents.filter(s => s.hostel === label).length;
}

function renderAllocatedList() {
  const el = document.getElementById('hostel-allocated-list');
  if (!el) return;
  const allocated = allHostelStudents.filter(s => s.hostel);
  if (!allocated.length) {
    el.innerHTML = '<div class="empty-state"><div class="empty-icon">🛏️</div><div class="empty-title">No students allocated yet</div></div>';
    return;
  }
  el.innerHTML = allocated.map(s => `
    <div class="list-item" onclick="openStudentDetail('${s.id}')">
      <div class="list-avatar" style="background:var(--grad-teal)">${initials(s.name)}</div>
      <div class="list-info"><div class="list-name">${escapeHtml(s.name)}</div><div class="list-meta">${escapeHtml(s.hostel)}</div></div>
      ${canManageHostel() ? `<button class="btn btn-glass btn-xs" onclick="event.stopPropagation();checkOutStudent('${s.id}')">Check-out</button>` : ''}
    </div>`).join('');
}

// ── Add Room ──
function openAddRoom() {
  if (!canManageHostel()) { toast('Your role cannot manage hostel rooms', 'warning'); return; }
  showModal(`
    <div class="bottom-sheet">
      <div class="sheet-handle"></div>
      <div class="modal-title">🚪 Add Hostel Room</div>
      <div class="divider"></div>
      <div class="form-row">
        <div class="form-field"><label class="form-label">Block *</label><input type="text" class="form-input" id="nr-block" placeholder="e.g. Block A"></div>
        <div class="form-field"><label class="form-label">Room Number *</label><input type="text" class="form-input" id="nr-number" placeholder="e.g. 102"></div>
      </div>
      <div class="form-row">
        <div class="form-field"><label class="form-label">Capacity (beds) *</label><input type="number" class="form-input" id="nr-capacity" placeholder="e.g. 2" value="2"></div>
        <div class="form-field"><label class="form-label">Status</label>
          <select class="form-select" id="nr-status"><option value="available">🟢 Available</option><option value="maintenance">🟡 Maintenance</option></select>
        </div>
      </div>
      <div style="display:flex;gap:10px;margin-top:8px;">
        <button class="btn btn-violet btn-full" onclick="saveNewRoom()">✅ Add Room</button>
        <button class="btn btn-glass" onclick="closeModal()">Cancel</button>
      </div>
    </div>
  `);
}

async function saveNewRoom() {
  const block = document.getElementById('nr-block').value.trim();
  const number = document.getElementById('nr-number').value.trim();
  const capacity = parseInt(document.getElementById('nr-capacity').value, 10);

  if (!block || !number) { toast('Block and room number are required', 'error'); return; }
  if (!capacity || capacity < 1) { toast('Capacity must be at least 1', 'error'); return; }

  const room = {
    id: genId(), block, room_number: number, capacity,
    status: document.getElementById('nr-status').value,
    org: CU?.org, created_by: CU?.id, created_at: new Date().toISOString(),
  };
  await dbPut('hostel_rooms', room);
  closeModal();
  toast('Room added', 'success');
  auditLog('hostel_room_added', { block, number });
  loadHostelModule();
}

function openRoomDetail(roomId) {
  const r = allHostelRooms.find(x => x.id === roomId);
  if (!r) return;
  const label = `${r.block} Room ${r.room_number}`;
  const occupants = allHostelStudents.filter(s => s.hostel === label);

  showCenterModal(`
    <div class="modal-box">
      <div class="modal-title">🚪 ${escapeHtml(label)}</div>
      <div class="divider"></div>
      <div class="flex justify-between mb-2"><span class="text-sm text-muted">Capacity</span><span class="font-bold">${r.capacity} beds</span></div>
      <div class="flex justify-between mb-2"><span class="text-sm text-muted">Occupied</span><span class="font-bold">${occupants.length}</span></div>
      <div class="flex justify-between mb-3"><span class="text-sm text-muted">Status</span><span class="badge badge-${ROOM_STATUS_COLORS[r.status] || 'green'}">${r.status}</span></div>
      ${occupants.length ? `
        <div class="form-group-title">Occupants</div>
        ${occupants.map(s => `<div class="text-sm" style="padding:4px 0;">👤 ${escapeHtml(s.name)}</div>`).join('')}
      ` : '<div class="text-sm text-muted">No students currently in this room</div>'}
      <div style="display:flex;gap:8px;margin-top:16px;flex-wrap:wrap;">
        ${canManageHostel() ? `
          <button class="btn btn-amber btn-sm" onclick="toggleRoomMaintenance('${r.id}')">${r.status === 'maintenance' ? '✅ Mark Available' : '🔧 Mark Maintenance'}</button>
          <button class="btn btn-red btn-sm" onclick="deleteRoom('${r.id}')">🗑️ Delete Room</button>
        ` : ''}
        <button class="btn btn-glass btn-sm" onclick="closeModal()">Close</button>
      </div>
    </div>
  `);
}

async function toggleRoomMaintenance(roomId) {
  const r = allHostelRooms.find(x => x.id === roomId);
  if (!r) return;
  r.status = r.status === 'maintenance' ? 'available' : 'maintenance';
  await dbPut('hostel_rooms', r);
  closeModal();
  toast(`Room marked ${r.status}`, 'success');
  auditLog('hostel_room_status_changed', { room: `${r.block} ${r.room_number}`, status: r.status });
  loadHostelModule();
}

async function deleteRoom(roomId) {
  const r = allHostelRooms.find(x => x.id === roomId);
  if (!r) return;
  const occ = getRoomOccupancy(roomId);
  if (occ > 0) { toast('Cannot delete a room with students still allocated — check them out first', 'error'); return; }
  if (!confirm(`Delete ${r.block} Room ${r.room_number}?`)) return;
  await dbDelete('hostel_rooms', roomId);
  closeModal();
  toast('Room deleted', 'success');
  auditLog('hostel_room_deleted', { room: `${r.block} ${r.room_number}` });
  loadHostelModule();
}

// ── Allocate / Check-out ──
function openAllocateStudent() {
  if (!canManageHostel()) { toast('Your role cannot allocate hostel rooms', 'warning'); return; }

  const unallocated = allHostelStudents.filter(s => !s.hostel && !['Lead', 'Inquiry', 'Counselling', 'Document', 'Graduated'].includes(s.stage));
  const availableRooms = allHostelRooms.filter(r => r.status !== 'maintenance' && getRoomOccupancy(r.id) < r.capacity);

  if (!unallocated.length) { toast('No unallocated students found (already housed, or not yet at Admission+ stage)', 'info'); return; }
  if (!availableRooms.length) { toast('No available rooms — add a room or free up space first', 'warning'); return; }

  showModal(`
    <div class="bottom-sheet">
      <div class="sheet-handle"></div>
      <div class="modal-title">🛏️ Allocate Student to Room</div>
      <div class="divider"></div>
      <div class="form-field"><label class="form-label">Student *</label>
        <select class="form-select" id="al-student">${unallocated.map(s => `<option value="${s.id}">${escapeHtml(s.name)} (${escapeHtml(s.roll || s.stage)})</option>`).join('')}</select>
      </div>
      <div class="form-field"><label class="form-label">Room *</label>
        <select class="form-select" id="al-room">${availableRooms.map(r => `<option value="${r.id}">${escapeHtml(r.block)} Room ${escapeHtml(r.room_number)} (${getRoomOccupancy(r.id)}/${r.capacity})</option>`).join('')}</select>
      </div>
      <div style="display:flex;gap:10px;margin-top:8px;">
        <button class="btn btn-violet btn-full" onclick="saveAllocation()">✅ Allocate</button>
        <button class="btn btn-glass" onclick="closeModal()">Cancel</button>
      </div>
    </div>
  `);
}

async function saveAllocation() {
  const studentId = document.getElementById('al-student').value;
  const roomId = document.getElementById('al-room').value;
  const student = allHostelStudents.find(s => s.id === studentId);
  const room = allHostelRooms.find(r => r.id === roomId);
  if (!student || !room) { toast('Selection error', 'error'); return; }

  if (getRoomOccupancy(roomId) >= room.capacity) { toast('That room just became full — pick another', 'error'); return; }

  const label = `${room.block} Room ${room.room_number}`;
  student.hostel = label;
  student.lifecycle = student.lifecycle || {};
  if (!student.lifecycle.Hostel) student.lifecycle.Hostel = new Date().toISOString().split('T')[0];
  await dbPut('students', student);

  await dbPut('hostel_allocations', {
    id: genId(), student_id: studentId, student_name: student.name, room_id: roomId,
    room_label: label, org: CU?.org, allocated_by: CU?.name,
    checkin_date: new Date().toISOString().split('T')[0], checkout_date: null,
    created_at: new Date().toISOString(),
  });

  closeModal();
  toast(`${student.name} allocated to ${label}`, 'success');
  auditLog('hostel_allocated', { student: student.name, room: label });
  loadHostelModule();
}

async function checkOutStudent(studentId) {
  const student = allHostelStudents.find(s => s.id === studentId);
  if (!student || !student.hostel) return;
  if (!confirm(`Check out ${student.name} from ${student.hostel}?`)) return;

  const oldRoom = student.hostel;
  student.hostel = '';
  await dbPut('students', student);

  // Close out the most recent open allocation record for this student.
  const allocations = await dbGetByIndex('hostel_allocations', 'student_id', studentId);
  const open = allocations.filter(a => !a.checkout_date).sort((a, b) => new Date(b.checkin_date) - new Date(a.checkin_date))[0];
  if (open) {
    open.checkout_date = new Date().toISOString().split('T')[0];
    await dbPut('hostel_allocations', open);
  }

  toast(`${student.name} checked out of ${oldRoom}`, 'success');
  auditLog('hostel_checkout', { student: student.name, room: oldRoom });
  loadHostelModule();
}
