/* ═══════════════════════════════════════════════════
   db.js — IndexedDB wrapper ("the database")
   All data lives on the user's device. Offline-first.
═══════════════════════════════════════════════════ */
'use strict';

const DB_NAME = 'nepalmbbs_cms';
const DB_VERSION = 4;
let DB = null;

const STORE_DEFS = [
  { name: 'users',        idx: ['email', 'phone', 'role', 'org'] },
  { name: 'students',     idx: ['stage', 'org', 'batch'] },
  { name: 'tasks',        idx: ['status', 'assigned_to', 'priority', 'org'] },
  { name: 'notifications',idx: ['read', 'type', 'user_id'] },
  { name: 'attendance',   idx: ['batch', 'date', 'org', 'student_id'] },
  { name: 'events',       idx: ['date', 'org'] },
  { name: 'notices',      idx: ['org', 'ts'] },
  { name: 'expenses',     idx: ['user_id', 'date', 'org'] },
  { name: 'fees',         idx: ['student_id', 'status'] },
  { name: 'documents',    idx: ['student_id', 'type'] },
  { name: 'mentor_reports', idx: ['student_id', 'mentor_id'] },
  { name: 'leads',        idx: ['status', 'source', 'org'] },
  { name: 'visitors',     idx: ['status', 'org', 'visit_date'] },
  { name: 'campaigns',    idx: ['status', 'platform', 'org'] },
  { name: 'hostel_rooms',       idx: ['block', 'status', 'org'] },
  { name: 'hostel_allocations', idx: ['student_id', 'room_id', 'org'] },
  { name: 'audit_log',    idx: ['user_id', 'ts', 'action'] },
  { name: 'settings' },   // keyPath: key, no extra index
];

function initDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onerror = () => reject(req.error);
    req.onsuccess = () => { DB = req.result; resolve(DB); };
    req.onupgradeneeded = e => {
      const db = e.target.result;
      const tx = e.target.transaction;
      STORE_DEFS.forEach(({ name, idx = [] }) => {
        let store;
        if (!db.objectStoreNames.contains(name)) {
          // Brand new store — create it with all its indexes.
          const keyPath = name === 'settings' ? 'key' : 'id';
          store = db.createObjectStore(name, { keyPath, autoIncrement: false });
        } else {
          // Store already exists (from an earlier DB_VERSION) — add any
          // indexes that are missing, without touching existing data.
          // This is the fix for a real bug: previously, existing stores
          // were skipped entirely on upgrade, so newly-added indexes
          // (like attendance.student_id) silently never got created on
          // devices that had already used an older version of the app.
          store = tx.objectStore(name);
        }
        idx.forEach(field => {
          if (!store.indexNames.contains(field)) {
            store.createIndex(field, field, { unique: false });
          }
        });
      });
    };
  });
}

function genId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function dbGetAll(store) {
  return new Promise((resolve, reject) => {
    const tx = DB.transaction(store, 'readonly');
    const req = tx.objectStore(store).getAll();
    req.onsuccess = () => resolve(req.result || []);
    req.onerror = () => reject(req.error);
  });
}

function dbGet(store, key) {
  return new Promise((resolve, reject) => {
    const tx = DB.transaction(store, 'readonly');
    const req = tx.objectStore(store).get(key);
    req.onsuccess = () => resolve(req.result || null);
    req.onerror = () => reject(req.error);
  });
}

function dbPut(store, data) {
  if (!data.id && store !== 'settings') data.id = genId();
  return new Promise((resolve, reject) => {
    const tx = DB.transaction(store, 'readwrite');
    const req = tx.objectStore(store).put(data);
    req.onsuccess = () => resolve(data);
    req.onerror = () => reject(req.error);
  });
}

function dbDelete(store, key) {
  return new Promise((resolve, reject) => {
    const tx = DB.transaction(store, 'readwrite');
    const req = tx.objectStore(store).delete(key);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

function dbGetByIndex(store, indexName, value) {
  return new Promise((resolve, reject) => {
    const tx = DB.transaction(store, 'readonly');
    const idx = tx.objectStore(store).index(indexName);
    const req = idx.getAll(value);
    req.onsuccess = () => resolve(req.result || []);
    req.onerror = () => reject(req.error);
  });
}

function dbClearStore(store) {
  return new Promise((resolve, reject) => {
    const tx = DB.transaction(store, 'readwrite');
    const req = tx.objectStore(store).clear();
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

/** Export the entire database as a JSON object (for backup/export feature). */
async function dbExportAll() {
  const out = {};
  for (const { name } of STORE_DEFS) {
    out[name] = await dbGetAll(name);
  }
  out._exported_at = new Date().toISOString();
  out._version = DB_VERSION;
  return out;
}

/** Import a previously exported JSON object back into the database. */
async function dbImportAll(data) {
  for (const { name } of STORE_DEFS) {
    if (!Array.isArray(data[name])) continue;
    await dbClearStore(name);
    for (const row of data[name]) {
      await dbPut(name, row);
    }
  }
}
