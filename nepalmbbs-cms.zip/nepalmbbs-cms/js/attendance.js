/* ═══════════════════════════════════════════════════
   attendance.js — Attendance sheets + history
═══════════════════════════════════════════════════ */
'use strict';

function initAttendance() {
  const dateEl = document.getElementById('att-date');
  if (dateEl && !dateEl.value) dateEl.value = new Date().toISOString().split('T')[0];
  loadAttHistory();
}

async function loadAttendance() {
  const batch = document.getElementById('att-batch').value;
  const date = document.getElementById('att-date').value;
  const subject = document.getElementById('att-subject').value.trim();

  if (!date) { toast('Please select a date', 'error'); return; }
  if (!subject) { toast('Please enter subject/session name', 'error'); return; }

  const students = await dbGetAll('students');
  const batchStudents = students.filter(s =>
    s.batch === batch && (!CU?.org || s.org === CU.org) &&
    ['Studying', 'Academic', 'Hostel'].includes(s.stage)
  );

  if (!batchStudents.length) { toast('No active students found for this batch', 'warning'); return; }

  document.getElementById('att-tbody').innerHTML = batchStudents.map((s, i) => `
    <tr>
      <td>${i + 1}</td>
      <td><div style="font-size:12px;font-weight:600;">${escapeHtml(s.name)}</div><div style="font-size:10px;color:var(--text-3);">${escapeHtml(s.roll || '')}</div></td>
      <td>
        <select class="form-select" id="att-${s.id}" style="padding:4px 8px;font-size:11px;min-width:64px;">
          <option value="P">✅ P</option><option value="A">❌ A</option><option value="L">📝 L</option>
        </select>
      </td>
      <td><input type="text" class="form-input" id="att-rem-${s.id}" placeholder="Remark" style="padding:4px 8px;font-size:11px;"></td>
    </tr>`).join('');

  const sheet = document.getElementById('attendance-sheet');
  sheet.classList.remove('hidden');
  sheet.dataset.batch = batch;
  sheet.dataset.date = date;
  sheet.dataset.subject = subject;
  sheet.dataset.students = JSON.stringify(batchStudents.map(s => s.id));
}

function markAllPresent() {
  document.querySelectorAll('[id^="att-"]').forEach(el => { if (el.tagName === 'SELECT') el.value = 'P'; });
}

async function saveAttendance() {
  const sheet = document.getElementById('attendance-sheet');
  const studentIds = JSON.parse(sheet.dataset.students || '[]');
  const { batch, date, subject } = sheet.dataset;

  for (const id of studentIds) {
    const record = {
      id: `${date}_${id}_${subject}`.replace(/\s+/g, '_'),
      student_id: id, batch, date, subject,
      status: document.getElementById('att-' + id)?.value || 'P',
      remark: document.getElementById('att-rem-' + id)?.value || '',
      org: CU?.org, marked_by: CU?.id, marked_at: new Date().toISOString(),
    };
    await dbPut('attendance', record);
  }

  // Recalculate and persist each affected student's overall attendance
  // percentage, so the Students/Mentor/Dashboard views that read
  // student.attendance_pct stay accurate instead of a stale manual number.
  for (const id of studentIds) {
    await recalculateStudentAttendance(id);
  }

  toast(`Attendance saved for ${studentIds.length} students`, 'success');
  auditLog('attendance_saved', { batch, date, subject, count: studentIds.length });
  loadAttHistory();
}

/** Recomputes one student's overall attendance % from ALL their saved
 *  attendance records (every subject, every date) and writes it back to
 *  the canonical students store — keeping student.attendance_pct in sync
 *  with reality instead of being a one-time manually-set number. */
async function recalculateStudentAttendance(studentId) {
  const records = await dbGetByIndex('attendance', 'student_id', studentId);
  if (!records.length) return;
  const present = records.filter(r => r.status === 'P').length;
  const pct = Math.round((present / records.length) * 100);

  const student = await dbGet('students', studentId);
  if (student) {
    student.attendance_pct = pct;
    await dbPut('students', student);
  }
}

async function loadAttHistory() {
  const el = document.getElementById('att-history');
  if (!el) return;
  const records = await dbGetAll('attendance');
  const myRecords = CU?.org ? records.filter(r => r.org === CU.org) : records;

  const sessions = {};
  myRecords.forEach(r => {
    const key = `${r.date}_${r.subject}`;
    if (!sessions[key]) sessions[key] = { date: r.date, subject: r.subject, batch: r.batch, total: 0, present: 0 };
    sessions[key].total++;
    if (r.status === 'P') sessions[key].present++;
  });

  const list = Object.values(sessions).sort((a, b) => b.date.localeCompare(a.date)).slice(0, 10);
  if (!list.length) {
    el.innerHTML = '<div class="empty-state"><div class="empty-icon">📅</div><div class="empty-title">No attendance records yet</div></div>';
    return;
  }

  el.innerHTML = list.map(s => {
    const pct = Math.round((s.present / s.total) * 100);
    return `<div class="glass-card glass-card-sm mb-2">
      <div class="flex justify-between items-center">
        <div><div class="text-sm font-semibold">${escapeHtml(s.subject)} · ${escapeHtml(s.batch)}</div><div class="text-xs text-muted">${formatDate(s.date)}</div></div>
        <div style="text-align:right;"><div class="text-sm font-bold" style="color:${pct >= 75 ? 'var(--green-l)' : 'var(--red-l)'}">${pct}%</div><div class="text-xs text-muted">${s.present}/${s.total} present</div></div>
      </div>
      <div class="progress-bar mt-2"><div class="progress-fill" style="width:${pct}%;background:${pct >= 75 ? 'var(--grad-green)' : 'var(--grad-amber)'}"></div></div>
    </div>`;
  }).join('');
}

function shareAttendance() {
  const sheet = document.getElementById('attendance-sheet');
  const text = `Attendance Report\nBatch: ${sheet.dataset.batch}\nDate: ${sheet.dataset.date}\nSubject: ${sheet.dataset.subject}`;
  shareText('Attendance Report', text);
}
