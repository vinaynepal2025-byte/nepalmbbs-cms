/* ═══════════════════════════════════════════════════
   ai.js — Gemini AI integration
   The user supplies their OWN free Gemini API key (Google AI
   Studio gives free-tier keys). We never ship a key in this repo.
   If no key is configured, every AI feature degrades gracefully
   to a clearly-labeled offline template instead of failing.
═══════════════════════════════════════════════════ */
'use strict';

const GEMINI_KEY_STORAGE = 'cms_gemini_key';
const GEMINI_MODEL = 'gemini-1.5-flash'; // free-tier friendly model
const GEMINI_ENDPOINT = (key) =>
  `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${key}`;

function getGeminiKey() {
  return localStorage.getItem(GEMINI_KEY_STORAGE) || '';
}

function setGeminiKey(key) {
  localStorage.setItem(GEMINI_KEY_STORAGE, key);
}

async function callGemini(prompt) {
  const key = getGeminiKey();
  if (!key || !APP_STATE.aiEnabled) return null; // caller falls back to template

  try {
    const res = await fetch(GEMINI_ENDPOINT(key), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] }),
    });
    if (!res.ok) throw new Error('Gemini API error ' + res.status);
    const data = await res.json();
    return data?.candidates?.[0]?.content?.parts?.[0]?.text || null;
  } catch (e) {
    console.warn('Gemini call failed, falling back to template', e);
    return null;
  }
}

function openAISettings() {
  const current = getGeminiKey();
  showModal(`
    <div class="bottom-sheet">
      <div class="sheet-handle"></div>
      <div class="modal-title">✨ Gemini AI Settings</div>
      <div class="divider"></div>
      <div class="text-sm text-muted mb-3">Get a free API key at <strong>aistudio.google.com</strong> (Google AI Studio → "Get API key"). Your key is stored only on this device and is sent directly from your browser to Google — never through our servers.</div>
      <div class="form-field"><label class="form-label">Gemini API Key</label><input type="password" class="form-input" id="gemini-key-input" placeholder="AIza..." value="${current ? '••••••••••••' : ''}"></div>
      <div style="display:flex;gap:10px;margin-top:8px;">
        <button class="btn btn-violet btn-full" onclick="saveGeminiKey()">✅ Save Key</button>
        <button class="btn btn-glass" onclick="closeModal()">Cancel</button>
      </div>
      ${current ? '<button class="btn btn-red btn-sm mt-3" onclick="clearGeminiKey()">Remove saved key</button>' : ''}
    </div>
  `);
}

function saveGeminiKey() {
  const val = document.getElementById('gemini-key-input').value.trim();
  if (val && !val.startsWith('•')) setGeminiKey(val);
  closeModal();
  toast('Gemini AI key saved', 'success');
}

function clearGeminiKey() {
  localStorage.removeItem(GEMINI_KEY_STORAGE);
  closeModal();
  toast('API key removed', 'info');
}

// ── Quick floating assistant ──
function openAIAssist() {
  document.getElementById('ai-float-panel').classList.remove('hidden');
}
function closeAIAssist() {
  document.getElementById('ai-float-panel').classList.add('hidden');
}

async function quickAIQuery() {
  const input = document.getElementById('ai-float-input');
  const q = input.value.trim();
  if (!q) return;
  const out = document.getElementById('ai-float-response');
  out.textContent = 'Thinking...';
  input.value = '';

  const response = await callGemini(q) || offlineAIFallback(q);
  out.textContent = response;
}

// ── Full AI assistant page ──
async function sendAIMessage() {
  const input = document.getElementById('ai-input');
  const msg = input.value.trim();
  if (!msg) return;
  input.value = '';
  appendChatMessage(msg, 'user');

  const thinkingId = appendChatMessage('Thinking...', 'ai');
  const response = await callGemini(msg) || offlineAIFallback(msg);
  updateChatMessage(thinkingId, response);
}

function appendChatMessage(text, who) {
  const id = genId();
  const el = document.getElementById('ai-messages');
  const div = document.createElement('div');
  div.className = `chat-msg ${who}`;
  div.id = 'msg-' + id;
  div.innerHTML = `<div class="chat-msg-bubble">${escapeHtml(text)}</div><div class="chat-msg-time">${who === 'user' ? 'You' : 'Gemini'} · now</div>`;
  el.appendChild(div);
  el.scrollIntoView({ block: 'end' });
  return id;
}

function updateChatMessage(id, text) {
  const el = document.getElementById('msg-' + id);
  if (el) el.querySelector('.chat-msg-bubble').textContent = text;
}

// ── Offline fallback responses (clearly templated, never pretend to be live AI) ──
function offlineAIFallback(query) {
  if (!getGeminiKey()) {
    return `[Offline mode — no Gemini key configured] I can't reach Gemini right now. Add a free API key in Profile → Gemini AI Assistant to get live answers. In the meantime: "${query}" — try checking the Reports section for relevant data.`;
  }
  return `[Offline — could not reach Gemini] Please check your internet connection and try again. Your query was: "${query}"`;
}

// ── Pre-built AI actions ──
async function aiAction(type) {
  showSection('ai');
  const prompts = {
    summary: 'Write a concise weekly summary of medical college student admissions and attendance activity for a CMS dashboard.',
    report: 'Generate a structured monthly admissions report outline for a medical college, covering pipeline stages, conversions, and recommendations.',
    email: 'Draft a polite, professional email to a parent updating them on their child\'s academic progress at a medical college.',
    translate: 'Translate the following text to Hindi: "Your visa application is being processed. Please submit your passport copy at the earliest."',
    followup: 'Write a friendly follow-up message reminder for a prospective MBBS student who inquired two weeks ago but has not responded.',
    risk: 'List the key early-warning signs a medical college mentor should watch for to flag a student as academically at-risk.',
  };
  const prompt = prompts[type] || prompts.summary;
  appendChatMessage(prompt.slice(0, 60) + '...', 'user');
  const thinkingId = appendChatMessage('Thinking...', 'ai');
  const response = await callGemini(prompt) || offlineAIFallback(prompt);
  updateChatMessage(thinkingId, response);
}

async function aiGenerateReport() { showSection('ai'); aiAction('report'); }
async function aiDraftParentEmail() { showSection('ai'); aiAction('email'); }
async function aiAnalyzeAttendance() { showSection('ai'); aiAction('risk'); }
async function aiPredictRisk() { showSection('ai'); aiAction('risk'); }

async function aiStudentSummary(studentId) {
  const s = allStudents.find(st => st.id === studentId);
  if (!s) return;
  closeModal();
  showSection('ai');
  const prompt = `Write a brief, encouraging 3-sentence progress summary for a medical college student named ${s.name}, currently at the "${s.stage}" stage, with ${s.attendance_pct || 0}% attendance and a GPA of ${s.gpa || 'N/A'}.`;
  appendChatMessage(`Summarize ${s.name}'s progress`, 'user');
  const thinkingId = appendChatMessage('Thinking...', 'ai');
  const response = await callGemini(prompt) || offlineAIFallback(prompt);
  updateChatMessage(thinkingId, response);
}

async function aiMentorDraft() {
  const prompt = 'Draft a short, professional mentor session note template covering observations and recommended next steps for a medical student.';
  const out = document.getElementById('mr-obs');
  if (out) out.value = 'Generating with Gemini...';
  const response = await callGemini(prompt) || 'Observations: [Gemini key not configured — add one in Profile → Settings to auto-draft this field]';
  if (out) out.value = response;
}
