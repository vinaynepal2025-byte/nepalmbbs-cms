/* ═══════════════════════════════════════════════════
   expenses.js — Personal Expense Claim Tracker
   (v2 — rebuilt per clarified real-world use case)

   THE ACTUAL USE CASE: one person plays multiple roles at the
   same college (e.g. handles Marketing AND Coordinator work).
   They pay for things out of pocket — travel, food, supplies —
   and need their OWN running record to hand to their employer
   for reimbursement alongside salary. This is NOT a college-wide
   operational ledger; it's each person's personal claim sheet.

   Design consequences of that:
   - Every logged-in user sees ONLY their own entries (filtered by
     user_id), never anyone else's — no role restriction needed,
     since there's nothing to gatekeep when it's already private.
   - Categories are free-text, not a fixed dropdown — the person
     adds whatever wording makes sense to them (e.g. "Auto fare",
     "Printing", "SIM recharge").
   - No approval workflow (Pending/Approved/Paid) — that was
     explicitly declined. This is a record + share/export tool,
     not a workflow system.
   - A polished "Share with Boss" action (WhatsApp / native share /
     CSV) is the actual deliverable the person needs at month-end.
═══════════════════════════════════════════════════ */
'use strict';

// A handful of suggested categories to speed up data entry — these are
// NOT a restriction. The category field itself is free text; clicking a
// chip just fills it in, and the person can type anything else instead.
const EXPENSE_SUGGESTED_CATEGORIES = ['Travel', 'Food', 'Stationery', 'Phone/Internet', 'Printing', 'Other'];
const EXPENSE_CATEGORY_PALETTE = ['violet', 'blue', 'teal', 'amber', 'green', 'rose'];

function expenseCategoryColor(category) {
  // Deterministic color per category name so the same category always
  // renders the same color, without needing a fixed lookup table.
  let hash = 0;
  for (let i = 0; i < (category || '').length; i++) hash = (hash * 31 + category.charCodeAt(i)) >>> 0;
  return EXPENSE_CATEGORY_PALETTE[hash % EXPENSE_CATEGORY_PALETTE.length];
}

let allExpenses = [];

async function loadExpenses() {
  const el = document.getElementById('expense-list');
  if (!el) return;

  // Privacy-critical guard: never query by an undefined user_id, since
  // IndexedDB's index.getAll(undefined) returns EVERY record (no filter)
  // rather than zero — that would leak every user's private expenses to
  // whoever's screen this is. If we don't know who's logged in, show
  // nothing rather than risk showing everything.
  if (!CU?.id) {
    el.innerHTML = '<div class="empty-state"><div class="empty-icon">🔒</div><div class="empty-title">Not signed in</div></div>';
    return;
  }

  el.innerHTML = '<div class="loading-state"><div class="spinner"></div></div>';

  // Personal claim sheet: only MY entries, never anyone else's.
  const mine = await dbGetByIndex('expenses', 'user_id', CU.id);
  allExpenses = mine.sort((a, b) => new Date(b.date) - new Date(a.date));

  renderExpenseStats(allExpenses);
  renderExpenseList(allExpenses);
  renderExpenseCategoryChips(allExpenses);
}

function renderExpenseStats(expenses) {
  const total = expenses.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
  const now = new Date();
  const thisMonth = expenses.filter(e => {
    const d = new Date(e.date);
    return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
  });
  const monthTotal = thisMonth.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);

  renderStatsGrid('expense-stats', [
    { value: formatCurrency(total), label: 'Total (All Time)', icon: '💰', color: 'violet' },
    { value: formatCurrency(monthTotal), label: 'This Month', icon: '📅', color: 'blue' },
    { value: expenses.length, label: 'Total Entries', icon: '🧾', color: 'amber' },
    { value: thisMonth.length, label: 'Entries This Month', icon: '📝', color: 'green' },
  ]);

  const byCategory = {};
  expenses.forEach(e => { byCategory[e.category] = (byCategory[e.category] || 0) + (Number(e.amount) || 0); });
  const maxCat = Math.max(...Object.values(byCategory), 1);
  const catEl = document.getElementById('expense-category-breakdown');
  if (catEl) {
    const categories = Object.keys(byCategory).sort((a, b) => byCategory[b] - byCategory[a]);
    catEl.innerHTML = `
      <div class="form-group-title">📊 By Category</div>
      <div class="flex-col gap-2 mt-2">
        ${categories.map(c => `
          <div>
            <div class="flex justify-between text-sm mb-1">
              <span>${escapeHtml(c)}</span>
              <span class="font-bold">${formatCurrency(byCategory[c])}</span>
            </div>
            <div class="progress-bar"><div class="progress-fill" style="width:${(byCategory[c] / maxCat) * 100}%;background:var(--grad-${expenseCategoryColor(c)})"></div></div>
          </div>`).join('') || '<div class="text-sm text-muted">No expenses recorded yet</div>'}
      </div>`;
  }
}

function renderExpenseCategoryChips(expenses) {
  const el = document.getElementById('expense-filter-chips');
  if (!el) return;
  const categories = [...new Set(expenses.map(e => e.category).filter(Boolean))];
  el.innerHTML = `<div class="chip active" onclick="filterExpenses('all',this)">All</div>` +
    categories.map(c => `<div class="chip" onclick="filterExpenses('${escapeHtml(c).replace(/'/g, "\\'")}',this)">${escapeHtml(c)}</div>`).join('');
}

function renderExpenseList(expenses) {
  const el = document.getElementById('expense-list');
  if (!el) return;
  if (!expenses.length) {
    el.innerHTML = '<div class="empty-state"><div class="empty-icon">🧾</div><div class="empty-title">No expenses recorded</div><div class="empty-sub">Add your first expense — this is your personal claim sheet, only you can see it</div></div>';
    return;
  }
  el.innerHTML = expenses.map(e => `
    <div class="list-item" onclick="openExpenseDetail('${e.id}')">
      <div class="list-avatar" style="background:var(--grad-${expenseCategoryColor(e.category)})">🧾</div>
      <div class="list-info">
        <div class="list-name">${escapeHtml(e.title || e.category)}</div>
        <div class="list-meta">${formatDate(e.date)}</div>
      </div>
      <div style="text-align:right;">
        <div class="font-bold text-sm">${formatCurrency(e.amount)}</div>
        <span class="badge badge-${expenseCategoryColor(e.category)}">${escapeHtml(e.category)}</span>
      </div>
    </div>`).join('');
}

function filterExpenses(category, el) {
  if (el) {
    document.querySelectorAll('#expense-filter-chips .chip').forEach(c => c.classList.remove('active'));
    el.classList.add('active');
  }
  const filtered = category === 'all' ? allExpenses : allExpenses.filter(e => e.category === category);
  renderExpenseList(filtered);
}

function openAddExpense() {
  showModal(`
    <div class="bottom-sheet">
      <div class="sheet-handle"></div>
      <div class="modal-title">🧾 Add Expense</div>
      <div class="text-xs text-muted mb-3">This is your personal record — only visible to you, for submitting to your employer.</div>

      <div class="form-field"><label class="form-label">Title / Description *</label><input type="text" class="form-input" id="ne-exp-title" placeholder="e.g. Auto fare to office, Printing flyers..."></div>

      <div class="form-row">
        <div class="form-field"><label class="form-label">Amount (₹) *</label><input type="number" class="form-input" id="ne-exp-amount" placeholder="0"></div>
        <div class="form-field"><label class="form-label">Date *</label><input type="date" class="form-input" id="ne-exp-date" value="${new Date().toISOString().split('T')[0]}"></div>
      </div>

      <div class="form-field">
        <label class="form-label">Category * <span class="text-xs text-muted" style="text-transform:none;font-weight:400;">(type your own, or tap a suggestion)</span></label>
        <input type="text" class="form-input" id="ne-exp-category" placeholder="e.g. Travel, Stationery, anything...">
        <div class="chip-row mt-2">
          ${EXPENSE_SUGGESTED_CATEGORIES.map(c => `<div class="chip" onclick="document.getElementById('ne-exp-category').value='${c}'">${c}</div>`).join('')}
        </div>
      </div>

      <div class="form-field"><label class="form-label">Notes</label><textarea class="form-input" id="ne-exp-notes" rows="2" placeholder="Optional — receipt number, purpose, etc."></textarea></div>

      <div style="display:flex;gap:10px;margin-top:8px;">
        <button class="btn btn-violet btn-full" onclick="saveNewExpense()">✅ Save Expense</button>
        <button class="btn btn-glass" onclick="closeModal()">Cancel</button>
      </div>
    </div>
  `);
}

async function saveNewExpense() {
  const title = document.getElementById('ne-exp-title').value.trim();
  const amount = parseFloat(document.getElementById('ne-exp-amount').value);
  const date = document.getElementById('ne-exp-date').value;
  const category = document.getElementById('ne-exp-category').value.trim();

  if (!title) { toast('Title is required', 'error'); return; }
  if (!amount || amount <= 0) { toast('Enter a valid amount', 'error'); return; }
  if (!date) { toast('Date is required', 'error'); return; }
  if (!category) { toast('Enter or pick a category', 'error'); return; }

  const expense = {
    id: genId(), title, amount, date, category,
    notes: document.getElementById('ne-exp-notes').value.trim(),
    org: CU?.org,
    user_id: CU?.id,
    added_by_name: CU?.name,
    added_by_role: CU?.role,
    created_at: new Date().toISOString(),
  };

  await dbPut('expenses', expense);
  closeModal();
  toast('Expense recorded', 'success');
  auditLog('expense_added', { title, amount, category });
  loadExpenses();
}

function openExpenseDetail(id) {
  const e = allExpenses.find(x => x.id === id);
  if (!e) return;
  showCenterModal(`
    <div class="modal-box">
      <div class="modal-title">🧾 ${escapeHtml(e.title)}</div>
      <div class="divider"></div>
      <div class="flex justify-between mb-2"><span class="text-sm text-muted">Amount</span><span class="font-bold">${formatCurrency(e.amount)}</span></div>
      <div class="flex justify-between mb-2"><span class="text-sm text-muted">Category</span><span class="badge badge-${expenseCategoryColor(e.category)}">${escapeHtml(e.category)}</span></div>
      <div class="flex justify-between mb-2"><span class="text-sm text-muted">Date</span><span class="text-sm">${formatDate(e.date)}</span></div>
      ${e.notes ? `<div class="modal-body mt-2">${escapeHtml(e.notes)}</div>` : ''}
      <div style="display:flex;gap:8px;margin-top:16px;flex-wrap:wrap;">
        <button class="btn btn-red btn-sm" onclick="deleteExpense('${e.id}')">🗑️ Delete</button>
        <button class="btn btn-glass btn-sm" onclick="closeModal()">Close</button>
      </div>
    </div>
  `);
}

async function deleteExpense(id) {
  if (!confirm('Delete this expense entry?')) return;
  await dbDelete('expenses', id);
  closeModal();
  toast('Expense deleted', 'success');
  auditLog('expense_deleted', { id });
  loadExpenses();
}

// ── Submit to Boss: the actual point of this whole feature ──
function openSubmitToBoss() {
  if (!allExpenses.length) { toast('No expenses to submit yet', 'info'); return; }

  showCenterModal(`
    <div class="modal-box">
      <div class="modal-title">📤 Submit Expense Report</div>
      <div class="modal-body mb-3">Choose how to send your expense report to your employer for reimbursement.</div>
      <div class="flex-col gap-2">
        <button class="btn btn-green btn-sm" onclick="shareExpenseReport('whatsapp')">💬 Send via WhatsApp</button>
        <button class="btn btn-blue btn-sm" onclick="shareExpenseReport('email')">📧 Send via Email</button>
        <button class="btn btn-violet btn-sm" onclick="shareExpenseReport('share')">📤 Share (native)</button>
        <button class="btn btn-glass btn-sm" onclick="exportExpensesCSV()">📥 Download as CSV</button>
      </div>
    </div>
  `);
}

function buildExpenseReportText() {
  const total = allExpenses.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
  const lines = allExpenses.map((e, i) => `${i + 1}. ${formatDate(e.date)} — ${e.title} (${e.category}): ${formatCurrency(e.amount)}`);
  return `*Expense Report — ${CU?.name || ''}*\n${CU?.org || ''}\nGenerated: ${new Date().toLocaleDateString('en-IN')}\n\n${lines.join('\n')}\n\n*Total: ${formatCurrency(total)}*`;
}

function shareExpenseReport(via) {
  const text = buildExpenseReportText();
  closeModal();
  if (via === 'whatsapp') {
    window.open('https://wa.me/?text=' + encodeURIComponent(text), '_blank');
  } else if (via === 'email') {
    window.open('mailto:?subject=' + encodeURIComponent('Expense Report — ' + (CU?.name || '')) + '&body=' + encodeURIComponent(text), '_blank');
  } else {
    shareText('Expense Report', text);
  }
}

function exportExpensesCSV() {
  const cols = ['date', 'title', 'category', 'amount', 'notes'];
  const headers = ['Date', 'Title', 'Category', 'Amount', 'Notes'];
  const csv = [headers.join(','), ...allExpenses.map(e => cols.map(c => `"${String(e[c] || '').replace(/"/g, "'")}"`).join(','))].join('\n');
  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = `My_Expenses_${CU?.name?.replace(/\s+/g, '_') || 'report'}_${new Date().toISOString().split('T')[0]}.csv`;
  a.click();
  URL.revokeObjectURL(url);
  closeModal();
  toast('CSV downloaded', 'success');
}
