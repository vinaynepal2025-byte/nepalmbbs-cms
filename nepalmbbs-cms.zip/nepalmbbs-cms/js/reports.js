/* ═══════════════════════════════════════════════════
   reports.js — Reports, analytics, notifications list
═══════════════════════════════════════════════════ */
'use strict';

// ── NOTIFICATIONS ──
async function loadNotifications() {
  const notifs = await dbGetAll('notifications');
  APP_STATE.notifications = notifs.filter(n => !n.user_id || n.user_id === 'all' || n.user_id === CU?.id)
    .filter(n => !CU?.org || n.org === CU.org);

  const unread = APP_STATE.notifications.filter(n => !n.read);
  document.getElementById('notif-dot')?.classList.toggle('hidden', unread.length === 0);
  renderNotifList(APP_STATE.notifications);
}

function renderNotifList(notifs) {
  const el = document.getElementById('notif-list');
  if (!el) return;
  if (!notifs.length) {
    el.innerHTML = '<div class="empty-state"><div class="empty-icon">🔔</div><div class="empty-title">No notifications</div></div>';
    return;
  }
  const sorted = [...notifs].sort((a, b) => new Date(b.ts) - new Date(a.ts));
  el.innerHTML = sorted.map(n => `
    <div class="notif-item ${n.read ? '' : 'unread'}" onclick="markRead('${n.id}')">
      <div class="notif-icon">${n.icon || '🔔'}</div>
      <div class="notif-content">
        <div class="notif-title">${escapeHtml(n.title)}</div>
        <div class="notif-body">${escapeHtml(n.body)}</div>
        <div class="notif-time">${timeAgo(n.ts)}</div>
      </div>
      ${!n.read ? '<div style="width:8px;height:8px;background:var(--violet);border-radius:50%;flex-shrink:0;margin-top:4px;"></div>' : ''}
    </div>`).join('');
}

function filterNotifs(type, el) {
  if (el) {
    document.querySelectorAll('#sec-notifications .chip').forEach(c => c.classList.remove('active'));
    el.classList.add('active');
  }
  let filtered = APP_STATE.notifications;
  if (type === 'unread') filtered = filtered.filter(n => !n.read);
  else if (type !== 'all') filtered = filtered.filter(n => n.type === type);
  renderNotifList(filtered);
}

async function markRead(id) {
  const n = APP_STATE.notifications.find(x => x.id === id);
  if (n && !n.read) { n.read = true; await dbPut('notifications', n); loadNotifications(); }
}

async function markAllRead() {
  for (const n of APP_STATE.notifications) { n.read = true; await dbPut('notifications', n); }
  toast('All notifications marked as read', 'success');
  loadNotifications();
}

// ── REPORTS ──
async function loadReports() {
  const students = await dbGetAll('students');
  const myStudents = CU?.org ? students.filter(s => s.org === CU.org) : students;
  // Expenses are personal (private claim sheets) — only show MY total here,
  // never org-wide, matching the same privacy rule as the Expenses section.
  // Guard against undefined CU.id, which would otherwise return everyone's
  // expenses from IndexedDB's index.getAll(undefined) behavior.
  const myExpenses = CU?.id ? await dbGetByIndex('expenses', 'user_id', CU.id) : [];
  const allVisitorRecords = await dbGetAll('visitors');
  const myVisitorRecords = CU?.org ? allVisitorRecords.filter(v => v.org === CU.org) : allVisitorRecords;
  renderReportOverview(myStudents, myExpenses, myVisitorRecords);
}

function renderReportOverview(students, expenses = [], visitors = []) {
  const el = document.getElementById('reports-content');
  if (!el) return;

  const stageData = {};
  LIFECYCLE_STAGES.forEach(s => { stageData[s] = students.filter(st => st.stage === s).length; });
  const maxVal = Math.max(...Object.values(stageData), 1);
  const totalExpenses = expenses.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);

  el.innerHTML = `
    <div class="glass-card mb-3">
      <div class="form-group-title">📊 Student Distribution by Stage</div>
      <div class="flex-col gap-2 mt-2">
        ${LIFECYCLE_STAGES.filter(s => stageData[s] > 0).map(s => `
          <div>
            <div class="flex justify-between text-sm mb-1"><span>${s}</span><span class="font-bold">${stageData[s]}</span></div>
            <div class="progress-bar"><div class="progress-fill" style="width:${(stageData[s] / maxVal) * 100}%;background:var(--grad-${STAGE_COLORS[s] || 'violet'})"></div></div>
          </div>`).join('') || '<div class="text-sm text-muted">No students yet</div>'}
      </div>
    </div>

    <div class="stats-grid mb-3">
      <div class="stat-card green"><div class="stat-icon green">📈</div><div class="stat-value">${students.length}</div><div class="stat-label">Total Pipeline</div></div>
      <div class="stat-card blue"><div class="stat-icon blue">🎓</div><div class="stat-value">${students.filter(s => ['Studying','Academic'].includes(s.stage)).length}</div><div class="stat-label">Currently Studying</div></div>
      <div class="stat-card amber"><div class="stat-icon amber">⚠️</div><div class="stat-value">${students.filter(s => s.risk_level === 'high').length}</div><div class="stat-label">At Risk</div></div>
      <div class="stat-card rose"><div class="stat-icon rose">🏆</div><div class="stat-value">${students.filter(s => s.stage === 'Graduated').length}</div><div class="stat-label">Graduated</div></div>
    </div>

    <div class="glass-card mb-3" style="cursor:pointer;" onclick="showSection('visitors')">
      <div class="flex justify-between items-center">
        <div>
          <div class="form-group-title" style="margin-bottom:4px;">👥 Visitors Tracked</div>
          <div class="text-xs text-muted">${visitors.filter(v=>v.status==='Hot lead').length} hot leads · ${visitors.filter(v=>v.status==='Admitted').length} admitted</div>
        </div>
        <div style="font-size:20px;font-weight:800;">${visitors.length}</div>
      </div>
    </div>

    <div class="glass-card mb-3" style="cursor:pointer;" onclick="showSection('expenses')">
      <div class="flex justify-between items-center">
        <div>
          <div class="form-group-title" style="margin-bottom:4px;">🧾 My Expenses (Personal)</div>
          <div class="text-xs text-muted">Tap to view your full claim sheet</div>
        </div>
        <div style="font-size:20px;font-weight:800;">${formatCurrency(totalExpenses)}</div>
      </div>
    </div>

    <div class="glass-card mb-3">
      <div class="form-group-title">📍 Geographic Distribution</div>
      ${[...new Set(students.map(s => s.state).filter(Boolean))].slice(0, 6).map(state => {
        const count = students.filter(s => s.state === state).length;
        const pct = Math.min(100, (count / students.length) * 100);
        return `<div class="flex justify-between items-center" style="padding:8px 0;border-bottom:1px solid var(--border-0);">
          <span class="text-sm">${escapeHtml(state)}</span>
          <div class="flex items-center gap-2"><div style="width:${pct}px;max-width:100px;height:6px;background:var(--grad-violet);border-radius:3px;"></div><span class="text-sm font-bold">${count}</span></div>
        </div>`;
      }).join('') || '<div class="text-sm text-muted">No geographic data yet</div>'}
    </div>

    <div class="flex gap-2" style="flex-wrap:wrap;">
      <button class="btn btn-violet btn-sm" onclick="exportReportJSON()">📄 Export JSON</button>
      <button class="btn btn-glass btn-sm" onclick="aiAction('report')">✨ AI Report</button>
      <button class="btn btn-glass btn-sm" onclick="shareReport()">📤 Share Summary</button>
    </div>
  `;
}

function filterReports(tab, el) {
  if (el) {
    document.querySelectorAll('#sec-reports .chip').forEach(c => c.classList.remove('active'));
    el.classList.add('active');
  }
  loadReports();
}

async function exportReportJSON() {
  const data = await dbExportAll();
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = `nepalmbbs-cms-export-${new Date().toISOString().split('T')[0]}.json`;
  a.click();
  URL.revokeObjectURL(url);
  toast('Export downloaded', 'success');
  auditLog('data_exported');
}

function shareReport() {
  shareText('CMS Report', `NepalMBBS CMS Report — ${CU?.org || ''}\nGenerated: ${new Date().toLocaleString('en-IN')}`);
}
