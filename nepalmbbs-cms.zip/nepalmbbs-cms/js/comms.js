/* ═══════════════════════════════════════════════════
   comms.js — Notices, broadcast, team chat (local stub)
═══════════════════════════════════════════════════ */
'use strict';

async function loadComms() { commsTab('notices', null); }

function commsTab(tab, el) {
  if (el) {
    document.querySelectorAll('#sec-comms .chip').forEach(c => c.classList.remove('active'));
    el.classList.add('active');
  }
  const el2 = document.getElementById('comms-content');
  if (!el2) return;

  if (tab === 'notices') {
    el2.innerHTML = `
      <div class="section-header"><div class="section-title">📢 Notice Board</div><button class="btn btn-violet btn-sm" onclick="openSendNotice()">+ Notice</button></div>
      <div id="notices-list"><div class="loading-state"><div class="spinner"></div></div></div>`;
    renderNotices();
  } else if (tab === 'chat') {
    el2.innerHTML = `
      <div class="section-title mb-3">💬 Team Chat</div>
      <div style="height:300px;overflow-y:auto;background:var(--glass-1);border:1px solid var(--border-1);border-radius:var(--r-xl);padding:12px;margin-bottom:12px;" id="chat-box">
        <div class="empty-state" style="padding:20px;"><div class="empty-icon">💬</div><div class="empty-title">No messages yet</div><div class="empty-sub">Team chat is local-only in offline mode</div></div>
      </div>
      <div class="chat-input-bar"><input type="text" placeholder="Type a message..." id="chat-msg-input"><button class="chat-send-btn" onclick="toast('Team chat requires the optional cloud sync add-on — see docs/09-FUTURE-UPGRADES.md','info')">🚀</button></div>`;
  } else if (tab === 'broadcast') {
    el2.innerHTML = `
      <div class="section-title mb-3">📡 Broadcast Message</div>
      <div class="glass-card"><div class="form-group-title">Send to all staff</div>
        <div class="form-field"><textarea class="form-input" id="bc-msg" rows="3" placeholder="Type your announcement..."></textarea></div>
        <button class="btn btn-violet" onclick="sendBroadcast()">📢 Send Broadcast</button>
      </div>`;
  } else {
    el2.innerHTML = `<div class="empty-state"><div class="empty-icon">💬</div><div class="empty-title">Coming soon</div></div>`;
  }
}

async function renderNotices() {
  const notices = await dbGetAll('notices');
  const myNotices = (CU?.org ? notices.filter(n => n.org === CU.org) : notices).sort((a,b) => new Date(b.ts) - new Date(a.ts));
  const el = document.getElementById('notices-list');
  if (!el) return;
  if (!myNotices.length) {
    el.innerHTML = '<div class="empty-state"><div class="empty-icon">📢</div><div class="empty-title">No notices yet</div></div>';
    return;
  }
  el.innerHTML = myNotices.map(n => `
    <div class="ai-bubble mb-2">
      <div class="ai-text">📢 <strong>${escapeHtml(n.title)}:</strong> ${escapeHtml(n.body)}</div>
      <div class="text-xs text-muted mt-2">${escapeHtml(n.sent_by || 'Admin')} · ${timeAgo(n.ts)}</div>
    </div>`).join('');
}

function openSendNotice() {
  showModal(`
    <div class="bottom-sheet">
      <div class="sheet-handle"></div>
      <div class="modal-title">📢 Send Notice</div>
      <div class="divider"></div>
      <div class="form-field"><label class="form-label">Title *</label><input type="text" class="form-input" id="nn-title" placeholder="Notice title"></div>
      <div class="form-field"><label class="form-label">Message *</label><textarea class="form-input" id="nn-body" rows="3" placeholder="Notice content..."></textarea></div>
      <div class="form-field"><label class="form-label">Priority</label><select class="form-select" id="nn-priority"><option>Normal</option><option>Important</option><option>Urgent</option></select></div>
      <div style="display:flex;gap:10px;margin-top:8px;">
        <button class="btn btn-violet btn-full" onclick="sendNotice()">📢 Publish</button>
        <button class="btn btn-glass" onclick="closeModal()">Cancel</button>
      </div>
    </div>
  `);
}

async function sendNotice() {
  const title = document.getElementById('nn-title').value.trim();
  const body = document.getElementById('nn-body').value.trim();
  if (!title || !body) { toast('Title and message required', 'error'); return; }

  await dbPut('notices', {
    id: genId(), title, body,
    priority: document.getElementById('nn-priority').value,
    org: CU?.org, sent_by: CU?.name, ts: new Date().toISOString(),
  });

  // Also push into notifications so it surfaces in the bell icon
  await dbPut('notifications', {
    id: genId(), type: 'message', title: '📢 ' + title, body,
    icon: '📢', read: false, user_id: 'all', org: CU?.org, ts: new Date().toISOString(),
  });

  closeModal();
  toast('Notice published', 'success');
  auditLog('notice_sent', { title });
  renderNotices();
}

async function sendBroadcast() {
  const msg = document.getElementById('bc-msg').value.trim();
  if (!msg) { toast('Enter a message', 'error'); return; }
  await dbPut('notifications', {
    id: genId(), type: 'system', title: '📡 Broadcast from ' + (CU?.name || 'Admin'), body: msg,
    icon: '📡', read: false, user_id: 'all', org: CU?.org, ts: new Date().toISOString(),
  });
  document.getElementById('bc-msg').value = '';
  toast('Broadcast sent to all staff', 'success');
  auditLog('broadcast_sent', { msg });
}

function openBroadcast() { showSection('comms'); commsTab('broadcast', document.querySelector('#sec-comms .chip')); }
