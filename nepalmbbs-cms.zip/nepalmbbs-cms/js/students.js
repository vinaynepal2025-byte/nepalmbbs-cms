/* ═══════════════════════════════════════════════════
   students.js — Student lifecycle CRUD + detail view
═══════════════════════════════════════════════════ */
'use strict';

let allStudents = [];

async function loadStudents() {
  const el = document.getElementById('student-list-container');
  if (el) el.innerHTML = '<div class="loading-state"><div class="spinner"></div></div>';

  allStudents = await dbGetAll('students');
  if (CU?.org && CU.role !== 'superadmin') {
    allStudents = allStudents.filter(s => s.org === CU.org);
  }
  APP_STATE.students = allStudents;
  renderStudentList(allStudents);
}

function renderStudentList(students) {
  const el = document.getElementById('student-list-container');
  if (!el) return;

  if (!students.length) {
    el.innerHTML = `<div class="empty-state">
      <div class="empty-icon">👨‍🎓</div>
      <div class="empty-title">No students found</div>
      <div class="empty-sub">Add your first student to get started</div>
      <button class="btn btn-violet mt-3" onclick="openAddStudent()">+ Add Student</button>
    </div>`;
    return;
  }

  el.innerHTML = students.map(s => {
    const sc = STAGE_COLORS[s.stage] || 'violet';
    const riskColor = { low: 'green', medium: 'amber', high: 'red' }[s.risk_level] || 'gray';
    return `
      <div class="student-card" onclick="openStudentDetail('${s.id}')">
        <div class="student-card-header">
          <div class="student-avatar" style="background:var(--grad-${sc})">${initials(s.name)}</div>
          <div class="student-info">
            <div class="student-name">${escapeHtml(s.name)}</div>
            <div class="student-id">${escapeHtml(s.roll || 'No Roll')} · ${escapeHtml(s.batch || '')} · ${escapeHtml(s.college || s.org || '')}</div>
          </div>
          <div class="badge badge-${sc}">${s.stage}</div>
        </div>
        <div class="student-meta">
          ${s.attendance_pct > 0 ? `<span class="badge badge-${s.attendance_pct >= 75 ? 'green' : 'red'}">📅 ${s.attendance_pct}%</span>` : ''}
          ${s.gpa > 0 ? `<span class="badge badge-blue">🎓 GPA ${s.gpa}</span>` : ''}
          <span class="badge badge-${riskColor}">⚠️ ${s.risk_level || 'low'} risk</span>
          ${s.city ? `<span class="badge badge-gray">📍 ${escapeHtml(s.city)}</span>` : ''}
        </div>
      </div>`;
  }).join('');
}

function filterStudents(query) {
  if (!query) { renderStudentList(allStudents); return; }
  const q = query.toLowerCase();
  renderStudentList(allStudents.filter(s =>
    (s.name || '').toLowerCase().includes(q) ||
    (s.roll || '').toLowerCase().includes(q) ||
    (s.email || '').toLowerCase().includes(q) ||
    (s.phone || '').includes(q) ||
    (s.city || '').toLowerCase().includes(q) ||
    (s.stage || '').toLowerCase().includes(q)
  ));
}

function filterByStage(stage, el) {
  if (el) {
    document.querySelectorAll('#student-filter-chips .chip').forEach(c => c.classList.remove('active'));
    el.classList.add('active');
  }
  renderStudentList(stage === 'all' ? allStudents : allStudents.filter(s => s.stage === stage));
}

function openStudentDetail(id) {
  const s = allStudents.find(st => st.id === id);
  if (!s) return;
  const sc = STAGE_COLORS[s.stage] || 'violet';

  const lifecycleHTML = LIFECYCLE_STAGES.map(stage => {
    const done = s.lifecycle?.[stage];
    const isActive = s.stage === stage;
    return `<div class="lifecycle-step">
      <div class="lifecycle-dot ${done ? 'done' : (isActive ? 'active' : '')}">${done ? '✓' : (isActive ? '●' : '○')}</div>
      <div class="lifecycle-content">
        <div class="lifecycle-title">${stage}</div>
        ${done ? `<div class="lifecycle-date">${formatDate(done)}</div>` : (isActive ? '<div class="lifecycle-date" style="color:var(--violet-l)">Current stage</div>' : '')}
      </div>
    </div>`;
  }).join('');

  showModal(`
    <div class="bottom-sheet" style="padding-bottom:24px;">
      <div class="sheet-handle"></div>
      <div class="text-center mb-3">
        <div class="student-avatar" style="width:64px;height:64px;font-size:24px;background:var(--grad-${sc});margin:0 auto 10px;">${initials(s.name)}</div>
        <div style="font-size:18px;font-weight:800;">${escapeHtml(s.name)}</div>
        <div class="text-xs text-muted">${escapeHtml(s.roll || '')} · ${escapeHtml(s.batch || '')}</div>
        <div class="badge badge-${sc} mt-1">${s.stage}</div>
      </div>

      <div class="chip-row" id="sd-tabs">
        <div class="chip active" onclick="sdTab('info',this)">📋 Info</div>
        <div class="chip" onclick="sdTab('lifecycle',this)">🗺️ Journey</div>
        <div class="chip" onclick="sdTab('academic',this)">📚 Academic</div>
        <div class="chip" onclick="sdTab('contact',this)">📞 Contact</div>
      </div>

      <div id="sd-info">
        <div class="glass-card mb-3">
          <div class="form-group-title">Student Information</div>
          <div class="grid-2">
            ${[['📍 City', s.city], ['🌍 State', s.state], ['🏳️ National', s.nationality], ['🩸 Blood', s.blood_group],
              ['🏠 Hostel', s.hostel], ['🛂 Visa', s.visa_status], ['💰 Fees', s.fees_paid ? '✅ Paid' : '❌ Pending'], ['⚠️ Risk', s.risk_level || 'low']]
              .map(([k, v]) => `<div><div class="text-xs text-muted">${k}</div><div class="text-sm font-semibold mt-1">${escapeHtml(v || 'N/A')}</div></div>`).join('')}
          </div>
        </div>
      </div>

      <div id="sd-lifecycle" class="hidden">
        <div class="glass-card"><div class="form-group-title">Student Journey</div><div class="lifecycle-track">${lifecycleHTML}</div></div>
      </div>

      <div id="sd-academic" class="hidden">
        <div class="glass-card mb-3">
          <div class="form-group-title">Academic Performance</div>
          <div class="stats-grid">
            <div class="stat-card blue"><div class="stat-icon blue">📅</div><div class="stat-value">${s.attendance_pct || 0}%</div><div class="stat-label">Attendance</div></div>
            <div class="stat-card ${s.gpa >= 7 ? 'green' : s.gpa >= 5 ? 'amber' : 'rose'}"><div class="stat-icon green">📊</div><div class="stat-value">${s.gpa || 'N/A'}</div><div class="stat-label">GPA</div></div>
          </div>
          ${s.attendance_pct > 0 ? `
            <div class="mt-3">
              <div class="flex justify-between text-sm mb-1"><span class="text-muted">Attendance</span><span style="color:${s.attendance_pct >= 75 ? 'var(--green-l)' : 'var(--red-l)'}">${s.attendance_pct}%</span></div>
              <div class="progress-bar"><div class="progress-fill" style="width:${s.attendance_pct}%;background:${s.attendance_pct >= 75 ? 'var(--grad-green)' : 'var(--grad-amber)'}"></div></div>
              ${s.attendance_pct < 75 ? '<div class="text-xs text-red mt-1">⚠️ Below 75% minimum requirement</div>' : ''}
            </div>` : ''}
        </div>
      </div>

      <div id="sd-contact" class="hidden">
        <div class="glass-card">
          <div class="form-group-title">Contact Information</div>
          ${[['📱 Phone', s.phone], ['📧 Email', s.email], ['👤 Guardian', s.guardian_name], ['📞 Guardian Phone', s.guardian_phone]]
            .filter(([,v]) => v).map(([k, v]) => `<div class="settings-item"><div style="flex:1"><div class="text-xs text-muted">${k}</div><div class="text-sm font-semibold">${escapeHtml(v)}</div></div></div>`).join('') || '<div class="text-sm text-muted">No contact info on file</div>'}
        </div>
      </div>

      <div class="flex gap-2 mt-3" style="flex-wrap:wrap;">
        <button class="btn btn-violet btn-sm" onclick="updateStudentStage('${s.id}')">📈 Update Stage</button>
        <button class="btn btn-glass btn-sm" onclick="callNumber('${s.phone || ''}')">📞 Call</button>
        <button class="btn btn-glass btn-sm" onclick="whatsappNumber('${s.phone || ''}','${escapeHtml(s.name)}')">💬 WhatsApp</button>
        <button class="btn btn-glass btn-sm" onclick="aiStudentSummary('${s.id}')">✨ AI Summary</button>
      </div>
    </div>
  `);
}

function sdTab(tab, el) {
  if (el) {
    document.querySelectorAll('#sd-tabs .chip').forEach(c => c.classList.remove('active'));
    el.classList.add('active');
  }
  ['info', 'lifecycle', 'academic', 'contact'].forEach(t => document.getElementById('sd-' + t)?.classList.toggle('hidden', t !== tab));
}

function openAddStudent() {
  showModal(`
    <div class="bottom-sheet">
      <div class="sheet-handle"></div>
      <div class="modal-title">➕ Add New Student</div>
      <div class="divider"></div>

      <div class="form-group">
        <div class="form-group-title">Personal Information</div>
        <div class="form-field"><label class="form-label">Full Name *</label><input type="text" class="form-input" id="ns-name" placeholder="Student full name"></div>
        <div class="form-row">
          <div class="form-field"><label class="form-label">Roll Number</label><input type="text" class="form-input" id="ns-roll" placeholder="MBBS001"></div>
          <div class="form-field"><label class="form-label">Batch Year</label>
            <select class="form-select" id="ns-batch"><option>MBBS 2025</option><option>MBBS 2024</option><option>MBBS 2023</option><option>MBBS 2022</option></select>
          </div>
        </div>
        <div class="form-field"><label class="form-label">Stage in Pipeline *</label>
          <select class="form-select" id="ns-stage">${LIFECYCLE_STAGES.map(s => `<option>${s}</option>`).join('')}</select>
        </div>
      </div>

      <div class="form-group">
        <div class="form-group-title">Contact Details</div>
        <div class="form-row">
          <div class="form-field"><label class="form-label">Phone</label><input type="tel" class="form-input" id="ns-phone" placeholder="+91..."></div>
          <div class="form-field"><label class="form-label">Email</label><input type="email" class="form-input" id="ns-email" placeholder="student@email.com"></div>
        </div>
        <div class="form-row">
          <div class="form-field"><label class="form-label">City</label><input type="text" class="form-input" id="ns-city" placeholder="City"></div>
          <div class="form-field"><label class="form-label">State</label><input type="text" class="form-input" id="ns-state" placeholder="State"></div>
        </div>
      </div>

      <div class="form-group">
        <div class="form-group-title">Guardian Information</div>
        <div class="form-row">
          <div class="form-field"><label class="form-label">Guardian Name</label><input type="text" class="form-input" id="ns-guard-name" placeholder="Parent/Guardian"></div>
          <div class="form-field"><label class="form-label">Guardian Phone</label><input type="tel" class="form-input" id="ns-guard-phone" placeholder="+91..."></div>
        </div>
      </div>

      <div style="display:flex;gap:10px;margin-top:8px;">
        <button class="btn btn-violet btn-full" onclick="saveNewStudent()">✅ Save Student</button>
        <button class="btn btn-glass" onclick="closeModal()">Cancel</button>
      </div>
    </div>
  `);
}

async function saveNewStudent() {
  const name = document.getElementById('ns-name').value.trim();
  if (!name) { toast('Student name is required', 'error'); return; }
  const stage = document.getElementById('ns-stage').value;

  const student = {
    id: genId(), name,
    roll: document.getElementById('ns-roll').value.trim() || ('MBBS' + Date.now().toString().slice(-5)),
    batch: document.getElementById('ns-batch').value,
    stage,
    phone: document.getElementById('ns-phone').value.trim(),
    email: document.getElementById('ns-email').value.trim(),
    city: document.getElementById('ns-city').value.trim(),
    state: document.getElementById('ns-state').value.trim(),
    guardian_name: document.getElementById('ns-guard-name').value.trim(),
    guardian_phone: document.getElementById('ns-guard-phone').value.trim(),
    org: CU?.org, college: CU?.org,
    nationality: 'Indian', fees_paid: false, visa_status: 'Not Applied',
    attendance_pct: 0, gpa: 0, risk_level: 'low',
    created_at: new Date().toISOString(), created_by: CU?.id,
    lifecycle: { [stage]: new Date().toISOString().split('T')[0] },
  };

  await dbPut('students', student);
  allStudents.push(student);
  closeModal();
  toast('Student added successfully', 'success');
  auditLog('student_added', { name, roll: student.roll });
  loadStudents();
}

function updateStudentStage(id) {
  const s = allStudents.find(st => st.id === id);
  if (!s) return;
  const currentIdx = LIFECYCLE_STAGES.indexOf(s.stage);
  showCenterModal(`
    <div class="modal-box">
      <div class="modal-title">📈 Update Stage</div>
      <div class="modal-body mb-3">Current: <strong>${s.stage}</strong></div>
      <div class="flex-col gap-2">
        ${LIFECYCLE_STAGES.map((stage, i) => `<button class="btn ${stage === s.stage ? 'btn-violet' : 'btn-glass'} btn-sm" onclick="setStudentStage('${id}','${stage}')">${i <= currentIdx ? '✅' : '○'} ${stage}</button>`).join('')}
      </div>
    </div>
  `);
}

async function setStudentStage(id, stage) {
  const s = allStudents.find(st => st.id === id);
  if (!s) return;
  s.stage = stage;
  s.lifecycle = s.lifecycle || {};
  s.lifecycle[stage] = new Date().toISOString().split('T')[0];
  await dbPut('students', s);
  closeModal();
  toast(`Stage updated to ${stage}`, 'success');
  auditLog('stage_updated', { student: s.name, stage });
  loadStudents();
}
