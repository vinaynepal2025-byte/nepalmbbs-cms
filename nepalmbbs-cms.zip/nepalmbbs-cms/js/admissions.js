/* ═══════════════════════════════════════════════════
   admissions.js — Admission pipeline view
═══════════════════════════════════════════════════ */
'use strict';

async function loadAdmissions() {
  const students = await dbGetAll('students');
  const myStudents = CU?.org ? students.filter(s => s.org === CU.org) : students;

  const pending = myStudents.filter(s => ['Lead', 'Inquiry'].includes(s.stage));
  const inProcess = myStudents.filter(s => ['Counselling', 'Document', 'Admission', 'Payment'].includes(s.stage));
  const admitted = myStudents.filter(s => ['Visa', 'Travel', 'Arrived', 'Hostel', 'Studying', 'Academic', 'Graduated'].includes(s.stage));

  renderStatsGrid('adm-stats', [
    { value: pending.length, label: 'New Inquiries', icon: '🌱', color: 'violet' },
    { value: inProcess.length, label: 'In Process', icon: '🔄', color: 'blue' },
    { value: admitted.length, label: 'Admitted', icon: '✅', color: 'green' },
    { value: myStudents.filter(s => s.stage === 'Visa').length, label: 'Visa Pending', icon: '🛂', color: 'amber' },
  ]);

  renderAdmissionList(myStudents);
}

function renderAdmissionList(students) {
  const el = document.getElementById('admission-list');
  if (!el) return;
  const sorted = [...students].sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
  if (!sorted.length) {
    el.innerHTML = '<div class="empty-state"><div class="empty-icon">📋</div><div class="empty-title">No applications yet</div></div>';
    return;
  }
  el.innerHTML = sorted.map(s => {
    const sc = STAGE_COLORS[s.stage] || 'violet';
    return `<div class="list-item" onclick="openStudentDetail('${s.id}')">
      <div class="list-avatar" style="background:var(--grad-${sc})">${initials(s.name)}</div>
      <div class="list-info">
        <div class="list-name">${escapeHtml(s.name)}</div>
        <div class="list-meta">${escapeHtml(s.city || '')}${s.state ? ' · ' + escapeHtml(s.state) : ''} · ${escapeHtml(s.batch || '')}</div>
      </div>
      <span class="badge badge-${sc}">${s.stage}</span>
    </div>`;
  }).join('');
}

function filterAdmissions(filter, el) {
  if (el) {
    document.querySelectorAll('#sec-admissions .chip').forEach(c => c.classList.remove('active'));
    el.classList.add('active');
  }
  const stageMap = {
    pending: ['Lead', 'Inquiry'],
    review: ['Counselling', 'Document'],
    approved: ['Admission', 'Payment', 'Visa', 'Travel', 'Arrived', 'Hostel', 'Studying', 'Academic', 'Graduated'],
  };
  dbGetAll('students').then(students => {
    const myStudents = CU?.org ? students.filter(s => s.org === CU.org) : students;
    if (filter === 'all') { renderAdmissionList(myStudents); return; }
    const stages = stageMap[filter] || [];
    renderAdmissionList(myStudents.filter(s => stages.includes(s.stage)));
  });
}

function openNewApplication() { openAddStudent(); }
