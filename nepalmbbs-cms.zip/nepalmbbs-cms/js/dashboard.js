/* ═══════════════════════════════════════════════════
   dashboard.js — Role-aware dashboard widgets
═══════════════════════════════════════════════════ */
'use strict';

async function loadDashboard() {
  const allStudents = await dbGetAll('students');
  const allTasks = await dbGetAll('tasks');
  const allNotifs = await dbGetAll('notifications');
  const allVisitorRecords = await dbGetAll('visitors');

  const org = CU?.org;
  const myStudents = allStudents.filter(s => !org || s.org === org);
  const myTasks = allTasks.filter(t => !org || t.org === org);
  const myVisitors = allVisitorRecords.filter(v => !org || v.org === org);
  const pendingTasks = myTasks.filter(t => t.status !== 'done');
  const highRisk = myStudents.filter(s => s.risk_level === 'high');

  renderStatsGrid('dash-stats', buildDashboardStats(myStudents, myTasks, highRisk, myVisitors));
  renderQuickActions();
  renderPipeline(myStudents);
  renderRecentActivity(myStudents, myTasks);
  renderAIInsights(myStudents, highRisk);
  renderTodayTasks(pendingTasks.slice(0, 4));

  const unread = allNotifs.filter(n => !n.read);
  document.getElementById('notif-dot')?.classList.toggle('hidden', unread.length === 0);
}

function buildDashboardStats(students, tasks, highRisk, visitors = []) {
  const total = students.length;
  const studying = students.filter(s => ['Studying', 'Academic'].includes(s.stage)).length;
  const pending = tasks.filter(t => t.status === 'pending').length;
  const done = tasks.filter(t => t.status === 'done').length;
  const role = CU?.role;

  const base = [];
  if (VISITOR_ALLOWED_ROLES.includes(role)) {
    base.push({ value: visitors.length, label: 'Total Visitors', icon: '👥', color: 'violet', change: visitors.length ? 'tracked' : '', up: true });
  } else {
    base.push({ value: total, label: 'Total Students', icon: '👨‍🎓', color: 'violet', change: total ? 'in pipeline' : '', up: true });
  }
  base.push(
    { value: studying, label: 'Active Students', icon: '📚', color: 'blue', change: `${studying}/${total||0}`, up: true },
    { value: pending, label: 'Pending Tasks', icon: '✅', color: 'amber', change: `${done} completed`, up: false },
    { value: highRisk.length, label: 'At Risk', icon: '⚠️', color: 'rose', change: highRisk.length ? 'needs attention' : 'all clear', up: false },
  );

  if (['superadmin', 'admin'].includes(CU?.role)) {
    base.push(
      { value: students.filter(s => s.stage === 'Visa').length, label: 'Visa Pending', icon: '🛂', color: 'teal' },
      { value: students.filter(s => s.stage === 'Admission').length, label: 'New Admissions', icon: '🎓', color: 'green' },
    );
  }
  return base;
}

function renderQuickActions() {
  const actionSets = {
    superadmin: [
      { icon:'➕', label:'Add Visit', fn:"openAddVisitor()" },
      { icon:'📋', label:'Admissions', fn:"showSection('admissions')" },
      { icon:'📊', label:'Reports', fn:"showSection('reports')" },
      { icon:'✨', label:'AI Report', fn:"aiGenerateReport()" },
      { icon:'👥', label:'Users', fn:"showSection('admin')" },
      { icon:'📅', label:'Attendance', fn:"showSection('attendance')" },
      { icon:'📆', label:'Calendar', fn:"showSection('calendar')" },
      { icon:'💬', label:'Comms', fn:"showSection('comms')" },
      { icon:'🧾', label:'Expenses', fn:"showSection('expenses')" },
    ],
    admission_manager: [
      { icon:'➕', label:'Add Visit', fn:"openAddVisitor()" },
      { icon:'📋', label:'Admissions', fn:"showSection('admissions')" },
      { icon:'👨‍🎓', label:'Students', fn:"showSection('students')" },
      { icon:'✨', label:'AI Draft', fn:"aiAction('email')" },
      { icon:'🧾', label:'Expenses', fn:"showSection('expenses')" },
      { icon:'✅', label:'Tasks', fn:"showSection('tasks')" },
    ],
    marketing: [
      { icon:'➕', label:'Add Visit', fn:"openAddVisitor()" },
      { icon:'🌱', label:'Add Lead', fn:"openAddLead()" },
      { icon:'📣', label:'Campaign', fn:"openAddCampaign()" },
      { icon:'📱', label:'Social', fn:"mktTab('social', null); showSection('marketing')" },
      { icon:'🧾', label:'Expenses', fn:"showSection('expenses')" },
      { icon:'✅', label:'Tasks', fn:"showSection('tasks')" },
    ],
    coordinator: [
      { icon:'🏠', label:'Hostel', fn:"coordTab('hostel', null); showSection('coordinator')" },
      { icon:'📢', label:'Complaints', fn:"coordTab('complaints', null); showSection('coordinator')" },
      { icon:'✈️', label:'Travel', fn:"coordTab('travel', null); showSection('coordinator')" },
      { icon:'🧾', label:'Expenses', fn:"showSection('expenses')" },
      { icon:'📅', label:'Attendance', fn:"showSection('attendance')" },
      { icon:'✅', label:'Tasks', fn:"showSection('tasks')" },
    ],
    mentor: [
      { icon:'📝', label:'Report', fn:"openMentorReport()" },
      { icon:'👨‍🎓', label:'Students', fn:"showSection('students')" },
      { icon:'⚠️', label:'Risk Check', fn:"aiAction('risk')" },
      { icon:'🧾', label:'Expenses', fn:"showSection('expenses')" },
      { icon:'✅', label:'Tasks', fn:"showSection('tasks')" },
    ],
    counsellor: [
      { icon:'➕', label:'Add Visit', fn:"openAddVisitor()" },
      { icon:'📋', label:'Admissions', fn:"showSection('admissions')" },
      { icon:'👨‍🎓', label:'Students', fn:"showSection('students')" },
      { icon:'🧾', label:'Expenses', fn:"showSection('expenses')" },
      { icon:'✅', label:'Tasks', fn:"showSection('tasks')" },
    ],
  };
  const actions = actionSets[CU?.role] || actionSets.superadmin;
  document.getElementById('quick-actions').innerHTML = actions.map(a => `
    <div class="quick-item" onclick="${a.fn}">
      <div class="quick-icon">${a.icon}</div>
      <div class="quick-label">${a.label}</div>
    </div>`).join('');
}

function renderPipeline(students) {
  const el = document.getElementById('pipeline-stages');
  if (!el) return;
  const display = ['Lead', 'Inquiry', 'Counselling', 'Admission', 'Visa', 'Travel', 'Arrived', 'Studying'];
  el.innerHTML = display.map(s => {
    const count = students.filter(st => st.stage === s).length;
    return `<div class="pipeline-stage" onclick="showSection('students')">
      <div class="stage-count">${count}</div>
      <div class="stage-label">${s}</div>
    </div>`;
  }).join('');
}

function renderRecentActivity(students, tasks) {
  const el = document.getElementById('recent-activity');
  if (!el) return;
  const activities = [
    ...students.slice(-3).map(s => ({ icon: '👨‍🎓', text: `${s.name} — Stage: ${s.stage}`, time: s.created_at, color: 'violet' })),
    ...tasks.filter(t => t.status === 'done').slice(-2).map(t => ({ icon: '✅', text: `Completed: ${t.title}`, time: t.created_at, color: 'green' })),
  ].sort((a, b) => new Date(b.time) - new Date(a.time)).slice(0, 5);

  if (!activities.length) {
    el.innerHTML = '<div class="empty-state"><div class="empty-icon">📭</div><div class="empty-title">No activity yet</div></div>';
    return;
  }

  el.innerHTML = `<div class="glass-card"><div class="timeline">${activities.map(a => `
    <div class="timeline-item">
      <div class="timeline-dot ${a.color}"></div>
      <div class="timeline-time">${timeAgo(a.time)}</div>
      <div class="timeline-title">${a.icon} ${escapeHtml(a.text)}</div>
    </div>`).join('')}</div></div>`;
}

function renderAIInsights(students, highRisk) {
  const el = document.getElementById('ai-insights');
  if (!el) return;
  const insights = [];
  if (highRisk.length) insights.push(`⚠️ <strong>${highRisk.length} student${highRisk.length > 1 ? 's' : ''}</strong> at risk due to attendance or academic performance. Mentor follow-up recommended.`);
  const visaPending = students.filter(s => s.stage === 'Visa').length;
  if (visaPending) insights.push(`🛂 <strong>${visaPending} student${visaPending>1?'s':''}</strong> have pending visa applications. Consider following up with the embassy.`);
  const inquiries = students.filter(s => s.stage === 'Inquiry').length;
  if (inquiries) insights.push(`🎯 <strong>${inquiries} inquir${inquiries>1?'ies':'y'}</strong> awaiting a counselling session — scheduling quickly tends to improve conversion.`);
  if (!insights.length) insights.push('📊 Everything looks on track. No urgent items right now.');

  el.innerHTML = insights.map(i => `<div class="ai-bubble"><div class="ai-text">${i}</div></div>`).join('');
}

function renderTodayTasks(tasks) {
  const el = document.getElementById('today-tasks');
  if (!el) return;
  if (!tasks.length) {
    el.innerHTML = '<div class="empty-state"><div class="empty-icon">✅</div><div class="empty-title">All clear!</div><div class="empty-sub">No pending tasks right now</div></div>';
    return;
  }
  el.innerHTML = tasks.map(t => `
    <div class="task-card" onclick="openTaskDetail('${t.id}')">
      <div class="task-check ${t.status === 'done' ? 'done' : ''}" onclick="event.stopPropagation();toggleTask('${t.id}')">${t.status === 'done' ? '✓' : ''}</div>
      <div class="task-info">
        <div class="task-title ${t.status === 'done' ? 'done' : ''}">${escapeHtml(t.title)}</div>
        <div class="task-meta">${t.category || 'General'} · Due ${formatDate(t.due_date)}</div>
      </div>
      <div class="task-priority ${t.priority || 'low'}"></div>
    </div>`).join('');
}
