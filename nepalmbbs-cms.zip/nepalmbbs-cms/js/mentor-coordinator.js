/* ═══════════════════════════════════════════════════
   mentor-coordinator.js — Mentor & Coordinator modules
═══════════════════════════════════════════════════ */
'use strict';

// ── MENTOR ──
async function loadMentor() {
  const students = await dbGetAll('students');
  const myStudents = students.filter(s => (!CU?.org || s.org === CU.org) && ['Studying', 'Academic'].includes(s.stage));

  renderStatsGrid('mentor-stats', [
    { value: myStudents.length, label: 'My Students', icon: '👨‍🎓', color: 'violet' },
    { value: myStudents.filter(s => s.risk_level === 'high').length, label: 'At Risk', icon: '⚠️', color: 'rose' },
    { value: myStudents.filter(s => s.attendance_pct >= 75).length, label: 'Good Standing', icon: '✅', color: 'green' },
    { value: myStudents.filter(s => s.attendance_pct > 0 && s.attendance_pct < 75).length, label: 'Low Attendance', icon: '📅', color: 'amber' },
  ]);

  mentorTab('assigned', null);
}

function mentorTab(tab, el) {
  if (el) {
    document.querySelectorAll('#sec-mentor .chip').forEach(c => c.classList.remove('active'));
    el.classList.add('active');
  }
  const el2 = document.getElementById('mentor-content');
  if (!el2) return;

  if (tab === 'assigned') {
    el2.innerHTML = '<div class="loading-state"><div class="spinner"></div></div>';
    dbGetAll('students').then(students => {
      const myStudents = students.filter(s => (!CU?.org || s.org === CU.org) && ['Studying', 'Academic'].includes(s.stage));
      el2.innerHTML = myStudents.map(s => {
        const rColor = { low: 'green', medium: 'amber', high: 'red' }[s.risk_level] || 'gray';
        return `<div class="student-card" onclick="openStudentDetail('${s.id}')">
          <div class="student-card-header">
            <div class="student-avatar" style="background:var(--grad-violet)">${initials(s.name)}</div>
            <div class="student-info"><div class="student-name">${escapeHtml(s.name)}</div><div class="student-id">${escapeHtml(s.roll||'')} · ${escapeHtml(s.batch||'')}</div></div>
            <span class="badge badge-${rColor}">${s.risk_level || 'low'} risk</span>
          </div>
          <div class="student-meta">
            ${s.attendance_pct > 0 ? `<span class="badge badge-${s.attendance_pct >= 75 ? 'green' : 'red'}">📅 ${s.attendance_pct}%</span>` : ''}
            ${s.gpa > 0 ? `<span class="badge badge-blue">📊 GPA ${s.gpa}</span>` : ''}
          </div>
          <div class="flex gap-2 mt-2">
            <button class="btn btn-glass btn-xs" onclick="event.stopPropagation();openMentorReport('${s.id}')">📝 Report</button>
            <button class="btn btn-glass btn-xs" onclick="event.stopPropagation();whatsappNumber('${s.guardian_phone||''}','${escapeHtml(s.name)}')">💬 Parent</button>
            <button class="btn btn-glass btn-xs" onclick="event.stopPropagation();aiStudentSummary('${s.id}')">✨ AI</button>
          </div>
        </div>`;
      }).join('') || '<div class="empty-state"><div class="empty-icon">🎓</div><div class="empty-title">No students assigned</div></div>';
    });
  } else {
    el2.innerHTML = '<div class="empty-state"><div class="empty-icon">📝</div><div class="empty-title">Coming soon</div></div>';
  }
}

function openMentorReport(studentId) {
  showModal(`
    <div class="bottom-sheet">
      <div class="sheet-handle"></div>
      <div class="modal-title">📝 Mentor Report</div>
      <div class="divider"></div>
      <div class="form-field"><label class="form-label">Session Date</label><input type="date" class="form-input" id="mr-date" value="${new Date().toISOString().split('T')[0]}"></div>
      <div class="form-field"><label class="form-label">Session Type</label><select class="form-select" id="mr-type"><option>Academic Review</option><option>Counselling</option><option>Health Check</option><option>Personal Guidance</option><option>Parent Update</option></select></div>
      <div class="form-field"><label class="form-label">Observations</label><textarea class="form-input" id="mr-obs" rows="3" placeholder="Student performance, attitude, issues..."></textarea></div>
      <div class="form-field"><label class="form-label">Action Items</label><textarea class="form-input" id="mr-action" rows="2" placeholder="Steps to be taken..."></textarea></div>
      <div class="form-field"><label class="form-label">Overall Assessment</label><select class="form-select" id="mr-assess"><option>Excellent</option><option>Good</option><option>Average</option><option>Below Average</option><option>Needs Immediate Attention</option></select></div>
      <div style="display:flex;gap:10px;margin-top:8px;">
        <button class="btn btn-violet btn-full" onclick="saveMentorReport('${studentId || ''}')">✅ Submit Report</button>
        <button class="btn btn-glass" onclick="closeModal()">Cancel</button>
      </div>
    </div>
  `);
}

async function saveMentorReport(studentId) {
  const report = {
    id: genId(), student_id: studentId,
    date: document.getElementById('mr-date').value,
    type: document.getElementById('mr-type').value,
    observations: document.getElementById('mr-obs').value,
    action_items: document.getElementById('mr-action').value,
    assessment: document.getElementById('mr-assess').value,
    mentor_id: CU?.id, mentor_name: CU?.name, org: CU?.org,
    created_at: new Date().toISOString(),
  };
  await dbPut('mentor_reports', report);
  closeModal();
  toast('Mentor report saved', 'success');
  auditLog('mentor_report', { studentId, assessment: report.assessment });
}

// ── COORDINATOR ──
async function loadCoordinator() {
  const students = await dbGetAll('students');
  const myStudents = CU?.org ? students.filter(s => s.org === CU.org) : students;

  renderStatsGrid('coord-stats', [
    { value: myStudents.filter(s => s.stage === 'Arrived').length, label: 'Just Arrived', icon: '✈️', color: 'blue' },
    { value: myStudents.filter(s => s.hostel).length, label: 'In Hostel', icon: '🏠', color: 'teal' },
    { value: myStudents.filter(s => s.risk_level === 'high').length, label: 'Needs Help', icon: '⚠️', color: 'rose' },
    { value: myStudents.filter(s => s.stage === 'Visa').length, label: 'Visa Pending', icon: '🛂', color: 'amber' },
  ]);

  coordTab('students', null);
}

function coordTab(tab, el) {
  if (el) {
    document.querySelectorAll('#sec-coordinator .chip').forEach(c => c.classList.remove('active'));
    el.classList.add('active');
  }
  const el2 = document.getElementById('coordinator-content');
  if (!el2) return;

  const renderers = {
    students: () => {
      el2.innerHTML = '<div class="loading-state"><div class="spinner"></div></div>';
      dbGetAll('students').then(students => {
        const myStudents = CU?.org ? students.filter(s => s.org === CU.org) : students;
        el2.innerHTML = myStudents.map(s => `
          <div class="list-item" onclick="openStudentDetail('${s.id}')">
            <div class="list-avatar" style="background:var(--grad-${STAGE_COLORS[s.stage] || 'violet'})">${initials(s.name)}</div>
            <div class="list-info"><div class="list-name">${escapeHtml(s.name)}</div><div class="list-meta">${escapeHtml(s.hostel || 'No hostel')} · ${s.stage}</div></div>
            <span class="badge badge-${STAGE_COLORS[s.stage] || 'violet'}">${s.stage}</span>
          </div>`).join('') || '<div class="empty-state"><div class="empty-icon">👨‍🎓</div><div class="empty-title">No students</div></div>';
      });
    },
    hostel: () => { loadHostelModule(); },
    health: () => { el2.innerHTML = renderHealthModule(); },
    complaints: () => { el2.innerHTML = renderComplaintsModule(); },
    library: () => { el2.innerHTML = renderLibraryModule(); },
    travel: () => { el2.innerHTML = renderTravelModule(); },
  };
  (renderers[tab] || renderers.students)();
}

// renderHostelModule() removed — replaced by the real, fully-functional
// hostel.js module (loadHostelModule), which uses actual room/allocation
// data instead of hardcoded demo numbers.

function renderHealthModule() {
  return `
    <div class="section-header"><div class="section-title">🏥 Health Records</div></div>
    <div class="glass-card"><div class="empty-state" style="padding:20px;"><div class="empty-icon">🏥</div><div class="empty-title">No health records yet</div></div></div>`;
}

function renderComplaintsModule() {
  return `
    <div class="section-header"><div class="section-title">📢 Complaints</div></div>
    <div class="empty-state"><div class="empty-icon">📢</div><div class="empty-title">No complaints</div><div class="empty-sub">All issues resolved</div></div>`;
}

function renderLibraryModule() {
  return `
    <div class="section-header"><div class="section-title">📚 Library</div></div>
    <div class="stats-grid">
      <div class="stat-card blue"><div class="stat-icon blue">📚</div><div class="stat-value">2.4K</div><div class="stat-label">Books</div></div>
      <div class="stat-card violet"><div class="stat-icon violet">📖</div><div class="stat-value">180</div><div class="stat-label">Issued</div></div>
      <div class="stat-card amber"><div class="stat-icon amber">⏰</div><div class="stat-value">12</div><div class="stat-label">Overdue</div></div>
      <div class="stat-card green"><div class="stat-icon green">👥</div><div class="stat-value">45</div><div class="stat-label">Today Visits</div></div>
    </div>`;
}

function renderTravelModule() {
  return `
    <div class="section-header"><div class="section-title">✈️ Travel Coordination</div></div>
    <div class="empty-state"><div class="empty-icon">✈️</div><div class="empty-title">No travel scheduled</div></div>`;
}
