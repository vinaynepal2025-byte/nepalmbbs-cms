/* ═══════════════════════════════════════════════════
   app.js — Boot sequence, router, theme, service worker
   This is the LAST script loaded; it wires everything together.
═══════════════════════════════════════════════════ */
'use strict';

function startApp() {
  document.getElementById('auth-screen').style.display = 'none';
  document.getElementById('app').style.display = 'flex';
  initHeaderAndProfile();
  renderBottomNav();
  showSection('dashboard');
  registerServiceWorker();
  applyTheme();
}

function initHeaderAndProfile() {
  if (!CU) return;
  const now = new Date();
  const h = now.getHours();
  const greet = h < 12 ? 'Good Morning ☀️' : h < 17 ? 'Good Afternoon 🌤️' : 'Good Evening 🌙';
  const roleInfo = ROLES[CU.role] || ROLES.admin;

  document.getElementById('h-title').textContent = CU.org || 'NepalMBBS CMS';
  document.getElementById('h-sub').textContent =
    `${roleInfo.emoji} ${roleInfo.label} · ${now.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}`;

  const av = document.getElementById('user-avatar');
  av.textContent = initials(CU.name);

  document.getElementById('g-name').textContent = `${greet}, ${CU.name.split(' ')[0]}!`;
  document.getElementById('g-role').textContent = `${roleInfo.label} · ${CU.org || 'NepalMBBS'}`;
  document.getElementById('g-date').textContent =
    now.toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });

  const rb = document.getElementById('role-banner');
  rb.className = `role-banner ${roleInfo.color}`;
  rb.innerHTML = `${roleInfo.emoji} <strong>${roleInfo.label}</strong> · ${CU.org || 'Medical College'}`;

  document.getElementById('prof-avatar').textContent = initials(CU.name);
  document.getElementById('prof-name').textContent = CU.name;
  document.getElementById('prof-role').textContent = roleInfo.label;
  document.getElementById('prof-org').textContent = CU.org || 'NepalMBBS Medical College';

  // Admin Control Panel is only ever visible to real Admin/Super Admin
  // logins — every other role (Marketing, Coordinator, Mentor, etc.)
  // never sees this link, full stop. One login = one role = one dashboard.
  const isRealAdmin = ['superadmin', 'admin'].includes(CU.role);
  document.getElementById('settings-admin-link')?.classList.toggle('hidden', !isRealAdmin);
}

function renderBottomNav() {
  const items = ROLE_NAV[CU?.role] || ROLE_NAV.admin;
  const nav = document.getElementById('bottom-nav');
  nav.innerHTML = items.map(id => {
    const cfg = NAV_CONFIG[id] || { icon: '📄', label: id };
    return `<div class="nav-item" onclick="showSection('${id}')" data-nav="${id}" role="button" tabindex="0">
      <div class="nav-icon">${cfg.icon}</div>
      <div class="nav-label">${cfg.label}</div>
    </div>`;
  }).join('');
}

function showSection(id) {
  document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
  const target = document.getElementById('sec-' + id);
  if (!target) { console.warn('Unknown section', id); return; }
  target.classList.add('active');
  APP_STATE.activeSection = id;
  document.querySelectorAll('.nav-item').forEach(n => n.classList.toggle('active', n.dataset.nav === id));
  onSectionLoad(id);
  document.getElementById('content').scrollTo(0, 0);
  closeModal();
}

function onSectionLoad(id) {
  const loaders = {
    dashboard: loadDashboard,
    students: loadStudents,
    tasks: loadTasks,
    admissions: loadAdmissions,
    visitors: loadVisitors,
    reports: loadReports,
    notifications: loadNotifications,
    attendance: initAttendance,
    marketing: loadMarketing,
    mentor: loadMentor,
    coordinator: loadCoordinator,
    comms: loadComms,
    expenses: loadExpenses,
    calendar: () => { renderCalendar(); loadEvents(); },
    admin: loadAdmin,
  };
  if (loaders[id]) loaders[id]();
}

// ── Theme ──
function applyTheme() {
  document.documentElement.dataset.theme = APP_STATE.theme;
  const toggle = document.getElementById('theme-toggle');
  const label = document.getElementById('theme-label');
  if (toggle) toggle.classList.toggle('on', APP_STATE.theme === 'light');
  if (label) label.textContent = APP_STATE.theme === 'dark' ? 'Dark Mode Active' : 'Light Mode Active';
}

function toggleTheme() {
  APP_STATE.theme = APP_STATE.theme === 'dark' ? 'light' : 'dark';
  localStorage.setItem('cms_theme', APP_STATE.theme);
  applyTheme();
}

function toggleAI() {
  APP_STATE.aiEnabled = !APP_STATE.aiEnabled;
  localStorage.setItem('cms_ai', APP_STATE.aiEnabled);
  document.getElementById('ai-toggle')?.classList.toggle('on', APP_STATE.aiEnabled);
  toast(APP_STATE.aiEnabled ? 'Gemini AI enabled' : 'Gemini AI disabled', 'info');
}

// ── Service worker registration ──
function registerServiceWorker() {
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('./sw.js').catch(err => console.warn('SW registration failed', err));
  }
}

// ── Boot ──
window.addEventListener('DOMContentLoaded', async () => {
  try {
    await initDB();
  } catch (e) {
    console.error('Database init failed', e);
    toast('Could not initialize local database', 'error');
    return;
  }
  if (checkExistingSession()) startApp();

  // PWA install prompt
  let deferredInstallEvent = null;
  window.addEventListener('beforeinstallprompt', e => {
    e.preventDefault();
    deferredInstallEvent = e;
  });
  window.installPWA = () => {
    if (deferredInstallEvent) {
      deferredInstallEvent.prompt();
      deferredInstallEvent.userChoice.then(r => {
        if (r.outcome === 'accepted') toast('App installed!', 'success');
        deferredInstallEvent = null;
      });
    } else {
      toast('Use your browser menu → "Add to Home Screen" to install', 'info');
    }
  };
});

window.addEventListener('online', () => toast('Back online', 'success'));
window.addEventListener('offline', () => toast('You are offline — changes are saved locally', 'warning'));
