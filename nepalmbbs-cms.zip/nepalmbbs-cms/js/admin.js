/* ═══════════════════════════════════════════════════
   admin.js — Admin control panel (Super Admin / Admin only)
═══════════════════════════════════════════════════ */
'use strict';

async function loadAdmin() {
  if (!['superadmin', 'admin'].includes(CU?.role)) {
    document.getElementById('admin-content').innerHTML =
      '<div class="empty-state"><div class="empty-icon">🔒</div><div class="empty-title">Access restricted</div><div class="empty-sub">Only Admin accounts can view this panel</div></div>';
    return;
  }
  adminTab('users', null);
}

function adminTab(tab, el) {
  if (el) {
    document.querySelectorAll('#sec-admin .chip').forEach(c => c.classList.remove('active'));
    el.classList.add('active');
  }
  const el2 = document.getElementById('admin-content');
  if (!el2) return;

  const renderers = { users: renderAdminUsers, orgs: renderAdminOrgs, audit: renderAdminAudit, security: renderAdminSecurity, system: renderAdminSystem, broadcast: renderAdminBroadcast };
  (renderers[tab] || renderAdminUsers)(el2);
}

async function renderAdminUsers(el) {
  el.innerHTML = '<div class="loading-state"><div class="spinner"></div></div>';
  const users = await dbGetAll('users');
  const myUsers = CU?.org ? users.filter(u => u.org === CU.org) : users;

  el.innerHTML = `
    <div class="section-header"><div class="section-title">👥 Staff & Roles</div><button class="btn btn-violet btn-sm" onclick="openAddStaff()">+ Add Staff</button></div>
    ${myUsers.map(u => {
      const roleInfo = ROLES[u.role] || { label: u.role, color: 'violet', emoji: '👤' };
      return `<div class="list-item">
        <div class="list-avatar" style="background:var(--grad-${roleInfo.color})">${initials(u.name)}</div>
        <div class="list-info"><div class="list-name">${escapeHtml(u.name)}</div><div class="list-meta">${escapeHtml(u.email || u.phone || '')}</div></div>
        <span class="badge badge-${roleInfo.color}">${roleInfo.emoji} ${roleInfo.label}</span>
      </div>`;
    }).join('') || '<div class="empty-state"><div class="empty-icon">👥</div><div class="empty-title">No staff yet</div></div>'}
  `;
}

function openAddStaff() {
  showModal(`
    <div class="bottom-sheet">
      <div class="sheet-handle"></div>
      <div class="modal-title">➕ Add Staff Member</div>
      <div class="divider"></div>
      <div class="form-field"><label class="form-label">Full Name *</label><input type="text" class="form-input" id="as-name" placeholder="Staff name"></div>
      <div class="form-row">
        <div class="form-field"><label class="form-label">Email *</label><input type="email" class="form-input" id="as-email" placeholder="staff@email.com"></div>
        <div class="form-field"><label class="form-label">Phone</label><input type="tel" class="form-input" id="as-phone" placeholder="+91..."></div>
      </div>
      <div class="form-field"><label class="form-label">Role *</label>
        <select class="form-select" id="as-role">
          <option value="admission_manager">📋 Admission Manager</option>
          <option value="marketing">📣 Marketing Team</option>
          <option value="coordinator">🤝 Coordinator</option>
          <option value="mentor">🎓 Mentor</option>
          <option value="counsellor">🎯 Counsellor</option>
          <option value="admin">⚙️ Admin (full access)</option>
        </select>
      </div>
      <div class="form-field"><label class="form-label">Temporary Password *</label><input type="password" class="form-input" id="as-pw" placeholder="Min 8 characters"></div>
      <div style="display:flex;gap:10px;margin-top:8px;">
        <button class="btn btn-violet btn-full" onclick="saveNewStaff()">✅ Create Account</button>
        <button class="btn btn-glass" onclick="closeModal()">Cancel</button>
      </div>
    </div>
  `);
}

async function saveNewStaff() {
  const name = document.getElementById('as-name').value.trim();
  const email = document.getElementById('as-email').value.trim();
  const pw = document.getElementById('as-pw').value;
  if (!name || !email || !pw) { toast('Name, email and password are required', 'error'); return; }
  if (pw.length < 8) { toast('Password must be at least 8 characters', 'error'); return; }

  const existing = await dbGetAll('users');
  if (existing.some(u => u.email === email)) { toast('A user with this email already exists', 'error'); return; }

  await dbPut('users', {
    id: genId(), name, email,
    phone: document.getElementById('as-phone').value.trim(),
    role: document.getElementById('as-role').value,
    org: CU?.org,
    password_hash: await hashPassword(pw),
    created_at: new Date().toISOString(), is_active: true,
  });
  closeModal();
  toast('Staff account created', 'success');
  auditLog('staff_created', { name, role: document.getElementById('as-role').value });
  adminTab('users', document.querySelector('#sec-admin .chip'));
}

function renderAdminOrgs(el) {
  el.innerHTML = `
    <div class="section-header"><div class="section-title">🏥 Organization</div></div>
    <div class="glass-card">
      <div class="form-group-title">Current Organization</div>
      <div class="text-sm font-semibold mb-2">${escapeHtml(CU?.org || 'N/A')}</div>
      <div class="text-xs text-muted">This CMS instance is single-tenant: one organization per deployment, configured at first setup. To run a second college, deploy a second copy of this app (see docs/04-DEPLOYMENT-GITHUB.md) or upgrade to the multi-tenant cloud backend described in docs/09-FUTURE-UPGRADES.md.</div>
    </div>`;
}

async function renderAdminAudit(el) {
  el.innerHTML = '<div class="loading-state"><div class="spinner"></div></div>';
  const logs = await dbGetAll('audit_log');
  const myLogs = (CU?.org ? logs.filter(l => l.org === CU.org) : logs).sort((a, b) => new Date(b.ts) - new Date(a.ts)).slice(0, 50);

  el.innerHTML = `
    <div class="section-header"><div class="section-title">📋 Audit Log</div></div>
    ${myLogs.map(l => `
      <div class="list-item" style="cursor:default;">
        <div class="list-avatar" style="background:var(--grad-violet);font-size:12px;">${initials(l.user_name || '?')}</div>
        <div class="list-info"><div class="list-name">${escapeHtml(l.action)}</div><div class="list-meta">${escapeHtml(l.user_name || 'Unknown')} · ${timeAgo(l.ts)}</div></div>
      </div>`).join('') || '<div class="empty-state"><div class="empty-icon">📋</div><div class="empty-title">No activity recorded yet</div></div>'}
  `;
}

function renderAdminSecurity(el) {
  el.innerHTML = `
    <div class="section-header"><div class="section-title">🔐 Security</div></div>
    <div class="glass-card mb-3">
      <div class="form-group-title">Session</div>
      <div class="text-sm text-muted">Sessions expire automatically after 30 days of inactivity. Passwords are hashed locally with SHA-256 before storage.</div>
    </div>
    <div class="glass-card">
      <div class="form-group-title">Honest Limitations</div>
      <div class="text-sm text-muted">This is an offline, client-only app — there is no server enforcing access control, so a technically skilled user with physical device access could inspect local storage. For sensitive multi-user deployments, see docs/06-SECURITY.md for the recommended upgrade path (server-side auth via a free-tier backend).</div>
    </div>`;
}

function renderAdminSystem(el) {
  el.innerHTML = `
    <div class="section-header"><div class="section-title">⚙️ System</div></div>
    <div class="settings-item" onclick="exportReportJSON()">
      <div class="settings-icon" style="background:rgba(59,130,246,0.15);">💾</div>
      <div class="settings-info"><div class="settings-title">Export Full Backup</div><div class="settings-sub">Download all data as JSON</div></div>
    </div>
    <div class="settings-item" onclick="document.getElementById('import-file-input').click()">
      <div class="settings-icon" style="background:rgba(16,185,129,0.15);">📥</div>
      <div class="settings-info"><div class="settings-title">Import Backup</div><div class="settings-sub">Restore from a JSON export</div></div>
    </div>
    <input type="file" id="import-file-input" accept=".json" class="hidden" onchange="handleImportFile(event)">
    <div class="settings-item" onclick="confirmReseedDemoData()">
      <div class="settings-icon" style="background:rgba(139,92,246,0.15);">🌱</div>
      <div class="settings-info"><div class="settings-title">Load Demo Data</div><div class="settings-sub">Add sample students, expenses & hostel rooms (safe — adds, does not delete)</div></div>
    </div>
    <div class="settings-item" onclick="confirmResetData()">
      <div class="settings-icon" style="background:rgba(239,68,68,0.15);">🗑️</div>
      <div class="settings-info"><div class="settings-title">Reset All Data</div><div class="settings-sub text-red">Permanently delete everything</div></div>
    </div>
    <div class="text-xs text-muted mt-3">App version 3.1.0 · Offline-first PWA</div>`;
}

function confirmReseedDemoData() {
  showCenterModal(`
    <div class="modal-box">
      <div class="modal-title">🌱 Load Demo Data?</div>
      <div class="modal-body mb-3">This adds sample students, tasks, expenses, hostel rooms and events to help you explore the app. It does NOT delete anything you've already added — safe to run even on an account you've been using.</div>
      <div class="flex gap-2">
        <button class="btn btn-violet btn-sm" onclick="doReseedDemoData()">Yes, add demo data</button>
        <button class="btn btn-glass btn-sm" onclick="closeModal()">Cancel</button>
      </div>
    </div>
  `);
}

async function doReseedDemoData() {
  await seedSampleData(CU.org, CU.id, CU.name);
  closeModal();
  toast('Demo data added — refresh any section to see it', 'success');
  auditLog('demo_data_reseeded');
  loadDashboard();
}

function renderAdminBroadcast(el) {
  el.innerHTML = `
    <div class="section-title mb-3">📢 Broadcast to All Staff</div>
    <div class="glass-card">
      <div class="form-field"><textarea class="form-input" id="admin-bc-msg" rows="3" placeholder="Type your announcement..."></textarea></div>
      <button class="btn btn-violet" onclick="sendAdminBroadcast()">📢 Send to Everyone</button>
    </div>`;
}

async function sendAdminBroadcast() {
  const msg = document.getElementById('admin-bc-msg').value.trim();
  if (!msg) { toast('Enter a message', 'error'); return; }
  await dbPut('notifications', {
    id: genId(), type: 'system', title: '📢 Admin Broadcast', body: msg,
    icon: '📢', read: false, user_id: 'all', org: CU?.org, ts: new Date().toISOString(),
  });
  document.getElementById('admin-bc-msg').value = '';
  toast('Broadcast sent', 'success');
  auditLog('admin_broadcast', { msg });
}

async function handleImportFile(event) {
  const file = event.target.files[0];
  if (!file) return;
  try {
    const text = await file.text();
    const data = JSON.parse(text);
    if (!confirm('This will REPLACE all current data with the backup file. Continue?')) return;
    await dbImportAll(data);
    toast('Backup restored — reloading...', 'success');
    setTimeout(() => location.reload(), 1200);
  } catch (e) {
    toast('Invalid backup file', 'error');
  }
}

function confirmResetData() {
  showCenterModal(`
    <div class="modal-box">
      <div class="modal-title">⚠️ Reset All Data?</div>
      <div class="modal-body mb-3">This permanently deletes every student, task, attendance record and setting on this device. This cannot be undone. Consider exporting a backup first.</div>
      <div class="flex gap-2">
        <button class="btn btn-red btn-sm" onclick="doResetAllData()">Yes, delete everything</button>
        <button class="btn btn-glass btn-sm" onclick="closeModal()">Cancel</button>
      </div>
    </div>
  `);
}

async function doResetAllData() {
  indexedDB.deleteDatabase(DB_NAME);
  localStorage.removeItem('cms_session');
  toast('Data wiped — reloading...', 'success');
  setTimeout(() => location.reload(), 1000);
}
