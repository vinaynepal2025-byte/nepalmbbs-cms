/* ═══════════════════════════════════════════════════
   marketing.js — Leads, campaigns, social, design tools
═══════════════════════════════════════════════════ */
'use strict';

async function loadMarketing() {
  const leads = await dbGetAll('leads');
  const campaigns = await dbGetAll('campaigns');
  const myLeads = CU?.org ? leads.filter(l => l.org === CU.org) : leads;

  renderStatsGrid('mkt-stats', [
    { value: myLeads.length, label: 'Total Leads', icon: '🌱', color: 'violet' },
    { value: myLeads.filter(l => l.status === 'qualified').length, label: 'Qualified', icon: '⭐', color: 'green' },
    { value: myLeads.filter(l => l.status === 'new').length, label: 'New', icon: '🆕', color: 'blue' },
    { value: campaigns.filter(c => (!CU?.org || c.org === CU.org)).length, label: 'Campaigns', icon: '📣', color: 'amber' },
  ]);

  mktTab('leads', null);
}

function mktTab(tab, el) {
  if (el) {
    document.querySelectorAll('#sec-marketing .chip').forEach(c => c.classList.remove('active'));
    el.classList.add('active');
  }
  const el2 = document.getElementById('marketing-content');
  if (!el2) return;

  if (tab === 'leads') {
    el2.innerHTML = `
      <div class="section-header"><div class="section-title">🌱 Lead Management</div><button class="btn btn-violet btn-sm" onclick="openAddLead()">+ Add Lead</button></div>
      <div id="leads-list"><div class="loading-state"><div class="spinner"></div></div></div>`;
    dbGetAll('leads').then(leads => {
      const myLeads = (CU?.org ? leads.filter(l => l.org === CU.org) : leads).sort((a,b) => new Date(b.created_at) - new Date(a.created_at));
      const list = document.getElementById('leads-list');
      if (!myLeads.length) {
        list.innerHTML = '<div class="empty-state"><div class="empty-icon">🌱</div><div class="empty-title">No leads yet</div><div class="empty-sub">Add leads from your marketing campaigns</div></div>';
        return;
      }
      list.innerHTML = myLeads.map(l => `
        <div class="list-item">
          <div class="list-avatar" style="background:var(--grad-violet)">${initials(l.name)}</div>
          <div class="list-info"><div class="list-name">${escapeHtml(l.name)}</div><div class="list-meta">${escapeHtml(l.source||'')} · ${escapeHtml(l.city||'')}</div></div>
          <span class="badge badge-${l.status === 'qualified' ? 'green' : 'blue'}">${l.status}</span>
        </div>`).join('');
    });
  } else if (tab === 'campaigns') {
    el2.innerHTML = `
      <div class="section-header"><div class="section-title">📣 Campaigns</div><button class="btn btn-violet btn-sm" onclick="openAddCampaign()">+ New</button></div>
      <div class="glass-card mb-3">
        <div class="form-group-title">Platform Performance</div>
        ${['Facebook', 'Instagram', 'YouTube', 'Google Ads', 'WhatsApp', 'Referral'].map(p =>
          `<div class="flex justify-between items-center" style="padding:8px 0;border-bottom:1px solid var(--border-0);"><span class="text-sm">${p}</span><span class="badge badge-violet">Track leads here</span></div>`).join('')}
      </div>`;
  } else if (tab === 'social') {
    el2.innerHTML = `
      <div class="section-header"><div class="section-title">📱 Social Media</div></div>
      <div class="grid-2">
        ${[
          { name: 'Facebook', icon: '📘', url: 'https://facebook.com' },
          { name: 'Instagram', icon: '📸', url: 'https://instagram.com' },
          { name: 'YouTube', icon: '▶️', url: 'https://youtube.com' },
          { name: 'WhatsApp', icon: '💬', url: 'https://web.whatsapp.com' },
          { name: 'LinkedIn', icon: '💼', url: 'https://linkedin.com' },
          { name: 'Twitter / X', icon: '🐦', url: 'https://x.com' },
        ].map(s => `<div class="glass-card text-center" style="cursor:pointer;" onclick="openExternalLink('${s.url}')"><div style="font-size:28px;margin-bottom:6px;">${s.icon}</div><div class="text-sm font-semibold">${s.name}</div></div>`).join('')}
      </div>`;
  } else if (tab === 'analytics') {
    el2.innerHTML = `
      <div class="section-header"><div class="section-title">📊 Marketing Analytics</div></div>
      <div class="glass-card"><div class="empty-state" style="padding:24px;"><div class="empty-icon">📊</div><div class="empty-title">Analytics build as leads grow</div><div class="empty-sub">Add leads & campaigns to see trends here</div></div></div>`;
  } else if (tab === 'canva') {
    el2.innerHTML = `
      <div class="section-header"><div class="section-title">🎨 Design Studio</div></div>
      <div class="glass-card text-center" style="padding:24px;">
        <div style="font-size:48px;margin-bottom:12px;">🎨</div>
        <div style="font-size:15px;font-weight:700;margin-bottom:6px;">Open Canva</div>
        <div style="font-size:12px;color:var(--text-3);margin-bottom:16px;">Create posters, social posts & brochures</div>
        <button class="btn btn-violet" onclick="openExternalLink('https://canva.com')">Open Canva</button>
      </div>`;
  }
}

function openAddLead() {
  showModal(`
    <div class="bottom-sheet">
      <div class="sheet-handle"></div>
      <div class="modal-title">🌱 Add New Lead</div>
      <div class="divider"></div>
      <div class="form-field"><label class="form-label">Name *</label><input type="text" class="form-input" id="nl-name" placeholder="Lead name"></div>
      <div class="form-row">
        <div class="form-field"><label class="form-label">Phone</label><input type="tel" class="form-input" id="nl-phone" placeholder="+91..."></div>
        <div class="form-field"><label class="form-label">Email</label><input type="email" class="form-input" id="nl-email" placeholder="email@..."></div>
      </div>
      <div class="form-field"><label class="form-label">Source</label>
        <select class="form-select" id="nl-source"><option>Facebook</option><option>Instagram</option><option>YouTube</option><option>Google</option><option>Referral</option><option>Walk-in</option><option>WhatsApp</option></select>
      </div>
      <div class="form-field"><label class="form-label">City</label><input type="text" class="form-input" id="nl-city" placeholder="City/State"></div>
      <div class="form-field"><label class="form-label">Notes</label><textarea class="form-input" id="nl-notes" rows="2" placeholder="Requirements, queries..."></textarea></div>
      <div style="display:flex;gap:10px;margin-top:8px;">
        <button class="btn btn-violet btn-full" onclick="saveNewLead()">✅ Save Lead</button>
        <button class="btn btn-glass" onclick="closeModal()">Cancel</button>
      </div>
    </div>
  `);
}

async function saveNewLead() {
  const name = document.getElementById('nl-name').value.trim();
  if (!name) { toast('Name is required', 'error'); return; }
  const lead = {
    id: genId(), name,
    phone: document.getElementById('nl-phone').value.trim(),
    email: document.getElementById('nl-email').value.trim(),
    source: document.getElementById('nl-source').value,
    city: document.getElementById('nl-city').value.trim(),
    notes: document.getElementById('nl-notes').value.trim(),
    status: 'new', org: CU?.org, assigned_to: CU?.id,
    created_at: new Date().toISOString(),
  };
  await dbPut('leads', lead);
  closeModal();
  toast('Lead added', 'success');
  auditLog('lead_added', { name });

  // Also seed it into the student pipeline at "Lead" stage — single source of truth
  await dbPut('students', {
    id: genId(), name, phone: lead.phone, email: lead.email, city: lead.city,
    stage: 'Lead', batch: 'MBBS 2025', org: CU?.org, college: CU?.org,
    fees_paid: false, visa_status: 'Not Applied', attendance_pct: 0, gpa: 0, risk_level: 'low',
    lifecycle: { Lead: new Date().toISOString().split('T')[0] },
    created_at: new Date().toISOString(),
  });
  loadMarketing();
}

function openAddCampaign() {
  showModal(`
    <div class="bottom-sheet">
      <div class="sheet-handle"></div>
      <div class="modal-title">📣 New Campaign</div>
      <div class="divider"></div>
      <div class="form-field"><label class="form-label">Campaign Name *</label><input type="text" class="form-input" id="nc-name" placeholder="e.g. MBBS 2025 Facebook Campaign"></div>
      <div class="form-row">
        <div class="form-field"><label class="form-label">Platform</label><select class="form-select" id="nc-platform"><option>Facebook</option><option>Instagram</option><option>YouTube</option><option>Google Ads</option><option>WhatsApp</option></select></div>
        <div class="form-field"><label class="form-label">Budget (₹)</label><input type="number" class="form-input" id="nc-budget" placeholder="0"></div>
      </div>
      <div class="form-row">
        <div class="form-field"><label class="form-label">Start Date</label><input type="date" class="form-input" id="nc-start"></div>
        <div class="form-field"><label class="form-label">End Date</label><input type="date" class="form-input" id="nc-end"></div>
      </div>
      <div style="display:flex;gap:10px;margin-top:8px;">
        <button class="btn btn-violet btn-full" onclick="saveNewCampaign()">✅ Save</button>
        <button class="btn btn-glass" onclick="closeModal()">Cancel</button>
      </div>
    </div>
  `);
}

async function saveNewCampaign() {
  const name = document.getElementById('nc-name').value.trim();
  if (!name) { toast('Campaign name is required', 'error'); return; }
  await dbPut('campaigns', {
    id: genId(), name,
    platform: document.getElementById('nc-platform').value,
    budget: parseFloat(document.getElementById('nc-budget').value) || 0,
    start: document.getElementById('nc-start').value,
    end: document.getElementById('nc-end').value,
    status: 'active', org: CU?.org, created_at: new Date().toISOString(),
  });
  closeModal();
  toast('Campaign created', 'success');
  loadMarketing();
}
