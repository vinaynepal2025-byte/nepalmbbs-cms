/* ═══════════════════════════════════════════════════
   tasks.js — Task manager
═══════════════════════════════════════════════════ */
'use strict';

let allTasks = [];

async function loadTasks() {
  allTasks = await dbGetAll('tasks');
  if (CU?.org) allTasks = allTasks.filter(t => t.org === CU.org);

  const pending = allTasks.filter(t => t.status === 'pending').length;
  const inprog = allTasks.filter(t => t.status === 'inprogress').length;
  const done = allTasks.filter(t => t.status === 'done').length;
  const high = allTasks.filter(t => t.priority === 'high' && t.status !== 'done').length;

  renderStatsGrid('task-stats-grid', [
    { value: pending, label: 'Pending', icon: '⏳', color: 'amber' },
    { value: inprog, label: 'In Progress', icon: '🔄', color: 'blue' },
    { value: done, label: 'Completed', icon: '✅', color: 'green' },
    { value: high, label: 'High Priority', icon: '🔴', color: 'rose' },
  ]);

  renderTaskList(allTasks);
}

function renderTaskList(tasks) {
  const el = document.getElementById('task-list');
  if (!el) return;
  if (!tasks.length) {
    el.innerHTML = '<div class="empty-state"><div class="empty-icon">✅</div><div class="empty-title">No tasks</div><div class="empty-sub">Add a new task to get started</div></div>';
    return;
  }
  const order = { high: 0, medium: 1, low: 2 };
  const sorted = [...tasks].sort((a, b) => (order[a.priority] ?? 1) - (order[b.priority] ?? 1));

  el.innerHTML = sorted.map(t => {
    const overdue = t.status !== 'done' && t.due_date && new Date(t.due_date) < new Date();
    return `
      <div class="task-card" onclick="openTaskDetail('${t.id}')">
        <div class="task-check ${t.status === 'done' ? 'done' : ''}" onclick="event.stopPropagation();toggleTask('${t.id}')">${t.status === 'done' ? '✓' : ''}</div>
        <div class="task-info">
          <div class="task-title ${t.status === 'done' ? 'done' : ''}">${escapeHtml(t.title)}</div>
          <div class="task-meta">
            <span class="badge badge-${t.priority === 'high' ? 'red' : t.priority === 'medium' ? 'amber' : 'green'}">${t.priority || 'low'}</span>
            ${t.due_date ? `<span style="color:${overdue ? 'var(--red-l)' : 'var(--text-3)'}">📅 ${overdue ? 'Overdue: ' : ''}${formatDate(t.due_date)}</span>` : ''}
            ${t.category ? `<span>${escapeHtml(t.category)}</span>` : ''}
          </div>
        </div>
        <div style="font-size:18px;">${t.status === 'done' ? '✅' : t.status === 'inprogress' ? '🔄' : '⏳'}</div>
      </div>`;
  }).join('');
}

function filterTasks(filter, el) {
  if (el) {
    document.querySelectorAll('#sec-tasks .chip').forEach(c => c.classList.remove('active'));
    el.classList.add('active');
  }
  let filtered = allTasks;
  if (filter === 'pending') filtered = allTasks.filter(t => t.status === 'pending');
  else if (filter === 'inprogress') filtered = allTasks.filter(t => t.status === 'inprogress');
  else if (filter === 'done') filtered = allTasks.filter(t => t.status === 'done');
  else if (filter === 'high') filtered = allTasks.filter(t => t.priority === 'high' && t.status !== 'done');
  renderTaskList(filtered);
}

async function toggleTask(id) {
  const t = allTasks.find(task => task.id === id);
  if (!t) return;
  t.status = t.status === 'done' ? 'pending' : 'done';
  t.completed_at = t.status === 'done' ? new Date().toISOString() : null;
  await dbPut('tasks', t);
  toast(t.status === 'done' ? 'Task completed' : 'Task reopened', t.status === 'done' ? 'success' : 'info');
  auditLog('task_toggle', { id, status: t.status });
  loadTasks();
}

function openAddTask() {
  showModal(`
    <div class="bottom-sheet">
      <div class="sheet-handle"></div>
      <div class="modal-title">➕ New Task</div>
      <div class="divider"></div>
      <div class="form-field"><label class="form-label">Task Title *</label><input type="text" class="form-input" id="nt-title" placeholder="Enter task description"></div>
      <div class="form-field"><label class="form-label">Description</label><textarea class="form-input" id="nt-desc" rows="2" placeholder="Additional details..."></textarea></div>
      <div class="form-row">
        <div class="form-field"><label class="form-label">Priority</label>
          <select class="form-select" id="nt-priority"><option value="high">🔴 High</option><option value="medium" selected>🟡 Medium</option><option value="low">🟢 Low</option></select>
        </div>
        <div class="form-field"><label class="form-label">Due Date</label><input type="date" class="form-input" id="nt-due"></div>
      </div>
      <div class="form-field"><label class="form-label">Category</label>
        <select class="form-select" id="nt-cat"><option>General</option><option>Follow-up</option><option>Counselling</option><option>Document</option><option>Report</option><option>Marketing</option><option>Hostel</option><option>Academic</option></select>
      </div>
      <div style="display:flex;gap:10px;margin-top:8px;">
        <button class="btn btn-violet btn-full" onclick="saveNewTask()">✅ Add Task</button>
        <button class="btn btn-glass" onclick="closeModal()">Cancel</button>
      </div>
    </div>
  `);
  const tomorrow = new Date(); tomorrow.setDate(tomorrow.getDate() + 1);
  document.getElementById('nt-due').value = tomorrow.toISOString().split('T')[0];
}

async function saveNewTask() {
  const title = document.getElementById('nt-title').value.trim();
  if (!title) { toast('Task title is required', 'error'); return; }
  const task = {
    id: genId(), title,
    description: document.getElementById('nt-desc').value.trim(),
    priority: document.getElementById('nt-priority').value,
    due_date: document.getElementById('nt-due').value,
    category: document.getElementById('nt-cat').value,
    status: 'pending', assigned_to: CU?.id, org: CU?.org,
    created_at: new Date().toISOString(), created_by: CU?.id,
  };
  await dbPut('tasks', task);
  allTasks.push(task);
  closeModal();
  toast('Task added', 'success');
  auditLog('task_created', { title });
  loadTasks();
}

function openTaskDetail(id) {
  const t = allTasks.find(task => task.id === id);
  if (!t) return;
  showCenterModal(`
    <div class="modal-box">
      <div class="modal-title">${escapeHtml(t.title)}</div>
      <div class="divider"></div>
      <div class="flex gap-2 mb-3">
        <span class="badge badge-${t.priority === 'high' ? 'red' : t.priority === 'medium' ? 'amber' : 'green'}">${t.priority} priority</span>
        <span class="badge badge-${t.status === 'done' ? 'green' : t.status === 'inprogress' ? 'blue' : 'amber'}">${t.status}</span>
      </div>
      ${t.description ? `<div class="modal-body mb-3">${escapeHtml(t.description)}</div>` : ''}
      <div class="text-sm text-muted">📅 Due: ${formatDate(t.due_date)}</div>
      <div class="text-sm text-muted mt-1">🏷️ Category: ${escapeHtml(t.category || 'General')}</div>
      <div style="display:flex;gap:8px;margin-top:16px;">
        <button class="btn btn-${t.status === 'done' ? 'amber' : 'green'} btn-sm" onclick="toggleTask('${t.id}');closeModal()">${t.status === 'done' ? '↩️ Reopen' : '✅ Complete'}</button>
        <button class="btn btn-glass btn-sm" onclick="closeModal()">Close</button>
      </div>
    </div>
  `);
}
