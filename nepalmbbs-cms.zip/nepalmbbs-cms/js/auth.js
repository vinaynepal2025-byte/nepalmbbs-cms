/* ═══════════════════════════════════════════════════
   auth.js — Login, first-time setup, sessions, password hashing
   NOTE: This is a CLIENT-ONLY offline app. Passwords are hashed
   locally before storage, but there is no server to enforce
   security — see docs/06-SECURITY.md for honest limitations and
   the upgrade path (server-side auth) if you outgrow offline mode.
═══════════════════════════════════════════════════ */
'use strict';

function switchAuthTab(tab, el) {
  document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
  el.classList.add('active');
  document.getElementById('auth-login').classList.toggle('hidden', tab !== 'login');
  document.getElementById('auth-setup').classList.toggle('hidden', tab !== 'setup');
}

// Simple, deterministic local hash (NOT cryptographically strong — adequate
// only for a local single-device app; see docs/06-SECURITY.md).
async function hashPassword(pw) {
  const enc = new TextEncoder().encode(pw + '::nepalmbbs::salt');
  const buf = await crypto.subtle.digest('SHA-256', enc);
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
}

async function doLogin() {
  const id = document.getElementById('li-id').value.trim();
  const pw = document.getElementById('li-pw').value;
  const orgSel = document.getElementById('li-org').value;
  const customOrg = document.getElementById('li-custom-org').value.trim();

  if (!id || !pw) { toast('Please enter email/phone and password', 'error'); return; }
  if (!orgSel) { toast('Please select your organization', 'error'); return; }

  const finalOrg = orgSel === '__custom__' ? customOrg : orgSel;
  if (orgSel === '__custom__' && !customOrg) { toast('Enter your organization name', 'error'); return; }

  const allUsers = await dbGetAll('users');
  if (!allUsers.length) { toast('No account found. Please run First Setup.', 'warning'); return; }

  const hash = await hashPassword(pw);
  const user = allUsers.find(u =>
    (u.email === id || u.phone === id) && u.password_hash === hash && u.is_active !== false
  );

  if (!user) { toast('Invalid credentials', 'error'); return; }

  const sessionUser = { ...user, org: user.org || finalOrg, loginTime: Date.now() };
  delete sessionUser.password_hash;
  localStorage.setItem('cms_session', JSON.stringify(sessionUser));
  CU = sessionUser;
  auditLog('login', { method: 'local' });
  startApp();
}

async function doSetup() {
  const name = document.getElementById('su-name').value.trim();
  const email = document.getElementById('su-email').value.trim();
  const phone = document.getElementById('su-phone').value.trim();
  const org = document.getElementById('su-org').value;
  const pw = document.getElementById('su-pw').value;
  const pw2 = document.getElementById('su-pw2').value;

  if (!name || !email || !pw) { toast('Fill all required fields', 'error'); return; }
  if (pw !== pw2) { toast('Passwords do not match', 'error'); return; }
  if (pw.length < 8) { toast('Password must be at least 8 characters', 'error'); return; }

  const existing = await dbGetAll('users');
  if (existing.some(u => u.role === 'superadmin' && u.org === org)) {
    toast('A Super Admin already exists for this organization', 'error');
    return;
  }

  const newUser = {
    id: genId(), name, email, phone, org,
    role: 'superadmin',
    password_hash: await hashPassword(pw),
    created_at: new Date().toISOString(),
    is_active: true,
  };
  await dbPut('users', newUser);
  await seedSampleData(org, newUser.id, newUser.name);

  toast('✅ Admin account created — please sign in', 'success');
  document.getElementById('li-id').value = email;
  document.getElementById('li-org').value = org;
  document.querySelector('.auth-tab').click();
}

function checkExistingSession() {
  const s = localStorage.getItem('cms_session');
  if (!s) return false;
  try {
    const u = JSON.parse(s);
    if (u.loginTime && Date.now() - u.loginTime > 30 * 24 * 60 * 60 * 1000) {
      localStorage.removeItem('cms_session');
      return false;
    }
    CU = u;
    return true;
  } catch (e) {
    localStorage.removeItem('cms_session');
    return false;
  }
}

function doLogout() {
  if (!confirm('Sign out of NepalMBBS CMS?')) return;
  auditLog('logout');
  localStorage.removeItem('cms_session');
  CU = null;
  location.reload();
}

document.addEventListener('DOMContentLoaded', () => {
  const orgSel = document.getElementById('li-org');
  if (orgSel) {
    orgSel.addEventListener('change', function () {
      document.getElementById('custom-org-wrap').classList.toggle('hidden', this.value !== '__custom__');
    });
  }
});
