/* ═══════════════════════════════════════════════════
   seed.js — Demo data so the app isn't empty on first run.
   Safe to delete all of this from the Admin panel any time.
═══════════════════════════════════════════════════ */
'use strict';

async function seedSampleData(org, userId = null, userName = 'Demo Data') {
  const now = new Date();
  const iso = (d) => d.toISOString().split('T')[0];

  const students = [
    { name:'Arjun Sharma', roll:'MBBS001', batch:'MBBS 2024', stage:'Studying', category:'FOREIGNER', phone:'+918001234567', email:'arjun@email.com', guardian_name:'Rajesh Sharma', guardian_phone:'+919001234567', dob:'2000-03-15', city:'Mumbai', state:'Maharashtra', nationality:'Indian', blood_group:'O+', fees_paid:true, visa_status:'Approved', hostel:'Block A Room 102', attendance_pct:87, gpa:7.8, risk_level:'low', lifecycle:{ Lead:'2023-06-01', Inquiry:'2023-06-15', Counselling:'2023-07-01', Admission:'2023-09-01', Arrived:'2024-01-05', Studying:'2024-01-10' } },
    { name:'Priya Patel', roll:'MBBS002', batch:'MBBS 2024', stage:'Visa', category:'FOREIGNER', phone:'+918002345678', email:'priya@email.com', guardian_name:'Suresh Patel', guardian_phone:'+919002345678', dob:'2001-07-22', city:'Ahmedabad', state:'Gujarat', nationality:'Indian', blood_group:'A+', fees_paid:false, visa_status:'Pending', attendance_pct:0, gpa:0, risk_level:'medium', lifecycle:{ Lead:'2024-01-10', Inquiry:'2024-01-20', Counselling:'2024-02-05', Admission:'2024-03-15', Payment:'2024-04-01' } },
    { name:'Rohit Kumar', roll:'MBBS003', batch:'MBBS 2023', stage:'Academic', category:'FOREIGNER', phone:'+917003456789', email:'rohit@email.com', guardian_name:'Vikram Kumar', guardian_phone:'+919003456789', dob:'2000-11-10', city:'Delhi', state:'Delhi', nationality:'Indian', blood_group:'B+', fees_paid:true, visa_status:'Approved', hostel:'Block B Room 205', attendance_pct:72, gpa:6.5, risk_level:'high', lifecycle:{ Lead:'2022-08-01', Inquiry:'2022-08-20', Counselling:'2022-09-10', Admission:'2022-11-01', Arrived:'2023-01-08', Studying:'2023-01-15', Academic:'2024-06-01' } },
    { name:'Sneha Reddy', roll:'MBBS004', batch:'MBBS 2025', stage:'Counselling', category:'FOREIGNER', phone:'+918004567890', email:'sneha@email.com', guardian_name:'Krishna Reddy', guardian_phone:'+919004567890', dob:'2002-05-18', city:'Hyderabad', state:'Telangana', nationality:'Indian', blood_group:'AB+', fees_paid:false, visa_status:'Not Applied', attendance_pct:0, gpa:0, risk_level:'low', lifecycle:{ Lead:'2024-09-15', Inquiry:'2024-10-01', Counselling:'2024-10-20' } },
    { name:'Amit Singh', roll:'MBBS005', batch:'MBBS 2022', stage:'Graduated', category:'FOREIGNER', phone:'+919005678901', email:'amit@email.com', guardian_name:'Mohan Singh', guardian_phone:'+919005678900', dob:'1999-12-01', city:'Lucknow', state:'Uttar Pradesh', nationality:'Indian', blood_group:'O-', fees_paid:true, visa_status:'Expired', attendance_pct:91, gpa:8.2, risk_level:'low', lifecycle:{ Graduated:'2024-05-30' } },
  ];

  for (const s of students) {
    await dbPut('students', { ...s, id: genId(), org, college: org, created_at: now.toISOString() });
  }

  const tasks = [
    { title:'Follow up with Priya Patel — visa documents', description:'Call and confirm required documents', priority:'high', status:'pending', category:'Follow-up', due_date: iso(new Date(Date.now()+86400000)) },
    { title:'Prepare monthly admission report', description:'Include all admission statistics and pipeline data', priority:'medium', status:'pending', category:'Report', due_date: iso(new Date(Date.now()+3*86400000)) },
    { title:'Schedule counselling session — Sneha Reddy', description:'Initial counselling for MBBS 2025 batch', priority:'high', status:'inprogress', category:'Counselling', due_date: iso(now) },
    { title:'Update hostel records for new arrivals', description:'Room allocation for January batch', priority:'low', status:'done', category:'Hostel', due_date: iso(new Date(Date.now()-86400000)) },
  ];
  for (const t of tasks) {
    await dbPut('tasks', { ...t, id: genId(), org, assigned_to: null, created_at: now.toISOString() });
  }

  const notifs = [
    { type:'alert', title:'High Attendance Risk', body:'Rohit Kumar attendance below 75% — immediate action required', icon:'⚠️', read:false, user_id:'all' },
    { type:'task', title:'New Task Assigned', body:'Prepare monthly report — due in 3 days', icon:'✅', read:false, user_id:'all' },
    { type:'system', title:'Welcome to NepalMBBS CMS', body:'Your Central Monitoring System is ready to use.', icon:'🚀', read:true, user_id:'all' },
  ];
  for (const n of notifs) {
    await dbPut('notifications', { ...n, id: genId(), org, ts: now.toISOString() });
  }

  const events = [
    { title:'MBBS 2025 Orientation', date: iso(new Date(now.getFullYear(), now.getMonth(), now.getDate()+5)), time:'09:00', type:'academic', description:'Welcome session for new batch' },
    { title:'Admission Deadline', date: iso(new Date(now.getFullYear(), now.getMonth(), now.getDate()+10)), time:'17:00', type:'admission', description:'Last date for document submission' },
    { title:'Parent-Teacher Meeting', date: iso(new Date(now.getFullYear(), now.getMonth(), now.getDate()+15)), time:'10:00', type:'communication', description:'Quarterly parent meeting' },
    { title:'Internal Exam — Anatomy', date: iso(new Date(now.getFullYear(), now.getMonth(), now.getDate()+20)), time:'08:00', type:'exam', description:'MBBS 1st Year Internal Assessment' },
  ];
  for (const e of events) {
    await dbPut('events', { ...e, id: genId(), org, created_at: now.toISOString() });
  }

  const expenses = [
    { title:'Auto fare to college and back', amount:180, category:'Travel', date: iso(new Date(now.getFullYear(), now.getMonth(), 3)) },
    { title:'Lunch during campus visit day', amount:250, category:'Food', date: iso(new Date(now.getFullYear(), now.getMonth(), 5)) },
    { title:'Printing brochures for visitors', amount:600, category:'Printing', date: iso(new Date(now.getFullYear(), now.getMonth(), 8)) },
    { title:'Mobile recharge for work calls', amount:399, category:'Phone/Internet', date: iso(new Date(now.getFullYear(), now.getMonth(), 12)) },
    { title:'Notebook and pens for office', amount:150, category:'Stationery', date: iso(new Date(now.getFullYear(), now.getMonth(), 15)) },
  ];
  for (const e of expenses) {
    await dbPut('expenses', {
      ...e, id: genId(), org, user_id: userId,
      added_by_name: userName, added_by_role: null,
      notes: '', created_at: now.toISOString(),
    });
  }

  const rooms = [
    { block: 'Block A', room_number: '101', capacity: 2, status: 'available' },
    { block: 'Block A', room_number: '102', capacity: 2, status: 'available' },
    { block: 'Block A', room_number: '103', capacity: 3, status: 'available' },
    { block: 'Block B', room_number: '201', capacity: 2, status: 'available' },
    { block: 'Block B', room_number: '202', capacity: 2, status: 'maintenance' },
    { block: 'Block B', room_number: '205', capacity: 2, status: 'available' },
  ];
  const roomIds = [];
  for (const r of rooms) {
    const saved = { ...r, id: genId(), org, created_by: null, created_at: now.toISOString() };
    await dbPut('hostel_rooms', saved);
    roomIds.push(saved);
  }

  const visitors = [
    { name:'Karan Mehta', type:'Student', phone:'+919811112222', email:'karan@email.com', city:'Jaipur', state:'Rajasthan', college_interest: org, nepal_visit:'First time', visit_types:['Campus','Hostel'], reference_type:'Consultant', reference_name:'Global Edu Consultants', neet_score:'480', admission_plan:'This year', documents:['10th Marksheet','12th Marksheet','NEET Scorecard'], major_queries:'Asked about hostel fees and recognition status', concerns:'', status:'Hot lead', follow_up_date: iso(new Date(Date.now()+2*86400000)), notes:'Very interested, visiting again next week', visit_date: iso(new Date(now.getFullYear(), now.getMonth(), 14)) },
    { name:'Meera Joshi (Parent)', type:'Parent', phone:'+919822223333', email:'meera@email.com', city:'Pune', state:'Maharashtra', college_interest: org, nepal_visit:'', visit_types:['Video Call'], reference_type:'Online', reference_name:'', neet_score:'410', admission_plan:'Next year', documents:[], major_queries:'Fee structure and bond details', concerns:'Worried about degree recognition in India', status:'Follow-up', follow_up_date: iso(new Date(Date.now()+5*86400000)), notes:'', visit_date: iso(new Date(now.getFullYear(), now.getMonth(), 11)) },
    { name:'Aditya Rao', type:'Student', phone:'+919833334444', email:'aditya@email.com', city:'Bangalore', state:'Karnataka', college_interest: org, nepal_visit:'Return visit', visit_types:['Campus','Faculty Meeting','Fee Discussion'], reference_type:'Alumni', reference_name:'Dr. Amit Singh (alumnus)', neet_score:'510', admission_plan:'This year', documents:['10th Marksheet','12th Marksheet','NEET Scorecard','Passport','Photos'], major_queries:'', concerns:'', status:'Admitted', follow_up_date:'', notes:'Admission confirmed, payment done', visit_date: iso(new Date(now.getFullYear(), now.getMonth(), 2)) },
    { name:'Riya Kapoor', type:'Both', phone:'+919844445555', email:'riya@email.com', city:'Chandigarh', state:'Punjab', college_interest: org, nepal_visit:'First time', visit_types:['Campus'], reference_type:'Direct', reference_name:'', neet_score:'350', admission_plan:'Just exploring', documents:[], major_queries:'General queries about MBBS abroad', concerns:'', status:'New', follow_up_date:'', notes:'Walk-in visit', visit_date: iso(now) },
  ];
  for (const v of visitors) {
    await dbPut('visitors', { ...v, id: genId(), org, added_by: null, added_by_name: 'Demo Data', created_at: now.toISOString() });
  }
}
