/* ═══════════════════════════════════════════════════
   visitors.js — Visitor / Lead intake tracking
   Matches the original reference file's "Visitors" module:
   campus & virtual visit records, full intake form, AI Q&A,
   WhatsApp/call quick actions, CSV export.

   Roles: Admission Manager, Marketing, Counsellor, Admin all
   manage visitors (it's the front door of the whole lifecycle).
   Saving a visitor ALSO creates the canonical `students` record
   at the "Lead" stage — same single-source-of-truth pattern used
   throughout this app (see 01-ARCHITECTURE.md).
═══════════════════════════════════════════════════ */
'use strict';

const VISITOR_ALLOWED_ROLES = ['superadmin', 'admin', 'admission_manager', 'marketing', 'counsellor'];
const VISITOR_STATUS_COLORS = {
  'New': 'violet', 'Interested': 'teal', 'Hot lead': 'amber',
  'Follow-up': 'amber', 'Admitted': 'green', 'Not interested': 'red',
};

function canManageVisitors() {
  return VISITOR_ALLOWED_ROLES.includes(CU?.role);
}

let allVisitors = [];
let visitorStageFilter = '';

async function loadVisitors() {
  const el = document.getElementById('visitor-list');
  if (!el) return;
  el.innerHTML = '<div class="loading-state"><div class="spinner"></div></div>';

  allVisitors = await dbGetAll('visitors');
  if (CU?.org) allVisitors = allVisitors.filter(v => v.org === CU.org);
  allVisitors.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));

  renderVisitorStats();
  renderVisitorList(allVisitors);

  const fab = document.getElementById('visitor-fab');
  if (fab) fab.classList.toggle('hidden', !canManageVisitors());
}

function renderVisitorStats() {
  const total = allVisitors.length;
  const hot = allVisitors.filter(v => v.status === 'Hot lead').length;
  const admitted = allVisitors.filter(v => v.status === 'Admitted').length;
  const followups = allVisitors.filter(v => v.follow_up_date && new Date(v.follow_up_date) >= new Date(new Date().toDateString())).length;

  renderStatsGrid('visitor-stats', [
    { value: total, label: 'Total Visitors', icon: '👥', color: 'violet' },
    { value: hot, label: 'Hot Leads', icon: '🔥', color: 'amber' },
    { value: admitted, label: 'Admitted', icon: '✅', color: 'green' },
    { value: followups, label: 'Pending Follow-ups', icon: '⏰', color: 'rose' },
  ]);
}

function renderVisitorList(visitors) {
  const el = document.getElementById('visitor-list');
  if (!el) return;
  if (!visitors.length) {
    el.innerHTML = '<div class="empty-state"><div class="empty-icon">👥</div><div class="empty-title">No visitors yet</div><div class="empty-sub">Add your first visit record</div></div>';
    return;
  }
  el.innerHTML = visitors.map(v => {
    const sc = VISITOR_STATUS_COLORS[v.status] || 'violet';
    return `
      <div class="list-item" onclick="openVisitorDetail('${v.id}')">
        <div class="list-avatar" style="background:var(--grad-${sc})">${initials(v.name)}</div>
        <div class="list-info">
          <div class="list-name">${escapeHtml(v.name)}</div>
          <div class="list-meta">${escapeHtml(v.city || '')}${v.reference_name ? ' · ' + escapeHtml(v.reference_name) : ''} ${v.college_interest ? '· 🏫 ' + escapeHtml(v.college_interest) : ''}</div>
        </div>
        <div style="text-align:right;">
          <div class="text-xs text-muted">${v.visit_date ? formatDate(v.visit_date) : ''}</div>
          <span class="badge badge-${sc}">${v.status}</span>
        </div>
      </div>`;
  }).join('');
}

function filterVisitors(query) {
  if (!query) { renderVisitorList(applyVisitorStageFilter(allVisitors)); return; }
  const q = query.toLowerCase();
  const filtered = allVisitors.filter(v =>
    (v.name || '').toLowerCase().includes(q) ||
    (v.city || '').toLowerCase().includes(q) ||
    (v.reference_name || '').toLowerCase().includes(q) ||
    (v.phone || '').includes(q)
  );
  renderVisitorList(applyVisitorStageFilter(filtered));
}

function applyVisitorStageFilter(list) {
  if (!visitorStageFilter) return list;
  return list.filter(v => v.status === visitorStageFilter);
}

function filterVisitorsByStatus(status, el) {
  if (el) {
    document.querySelectorAll('#visitor-filter-chips .chip').forEach(c => c.classList.remove('active'));
    el.classList.add('active');
  }
  visitorStageFilter = status;
  renderVisitorList(applyVisitorStageFilter(allVisitors));
}

// ── Add Visitor (full intake form, matching the original reference) ──
function openAddVisitor() {
  if (!canManageVisitors()) { toast('Your role cannot add visitor records', 'warning'); return; }
  showModal(`
    <div class="bottom-sheet">
      <div class="sheet-handle"></div>
      <div class="modal-title">➕ Add Visit</div>
      <div class="divider"></div>

      <div class="form-group">
        <div class="form-group-title">Basic Information</div>
        <div class="form-field"><label class="form-label">Name *</label><input type="text" class="form-input" id="nv-name" placeholder="Full name"></div>
        <div class="form-row">
          <div class="form-field"><label class="form-label">Type</label>
            <select class="form-select" id="nv-type"><option>Student</option><option>Parent</option><option>Consultant</option><option>Agent</option><option>Both</option></select>
          </div>
          <div class="form-field"><label class="form-label">Visit Date</label><input type="date" class="form-input" id="nv-date" value="${new Date().toISOString().split('T')[0]}"></div>
        </div>
        <div class="form-row">
          <div class="form-field"><label class="form-label">Contact</label><input type="tel" class="form-input" id="nv-phone" placeholder="+91 XXXXX"></div>
          <div class="form-field"><label class="form-label">Email</label><input type="email" class="form-input" id="nv-email" placeholder="email@..."></div>
        </div>
        <div class="form-row">
          <div class="form-field"><label class="form-label">City</label><input type="text" class="form-input" id="nv-city" placeholder="Delhi, Patna..."></div>
          <div class="form-field"><label class="form-label">State</label><input type="text" class="form-input" id="nv-state" placeholder="UP, Bihar..."></div>
        </div>
      </div>

      <div class="form-group">
        <div class="form-group-title">Visit Details</div>
        <div class="form-field"><label class="form-label">College Interested In</label><input type="text" class="form-input" id="nv-college" placeholder="CMC Nepal, KIST..."></div>
        <div class="form-field"><label class="form-label">Nepal Visit</label>
          <select class="form-select" id="nv-nepal-visit"><option value="">— Select —</option><option>First time</option><option>Return visit</option></select>
        </div>
        <div class="form-field"><label class="form-label">Visit Type (select all that apply)</label>
          <div class="chip-row" id="nv-visit-types" style="flex-wrap:wrap;">
            ${['Campus','Hospital','Hostel','Faculty Meeting','Fee Discussion','Video Call'].map(t => `<div class="chip" data-val="${t}" onclick="this.classList.toggle('active')">${t}</div>`).join('')}
          </div>
        </div>
      </div>

      <div class="form-group">
        <div class="form-group-title">Reference & Academic</div>
        <div class="form-row">
          <div class="form-field"><label class="form-label">Reference</label>
            <select class="form-select" id="nv-ref-type"><option>Direct</option><option>Consultant</option><option>Agent</option><option>Online</option><option>Alumni</option></select>
          </div>
          <div class="form-field"><label class="form-label">Reference Name</label><input type="text" class="form-input" id="nv-ref-name" placeholder="Name"></div>
        </div>
        <div class="form-row">
          <div class="form-field"><label class="form-label">NEET Score</label><input type="text" class="form-input" id="nv-neet" placeholder="e.g. 520"></div>
          <div class="form-field"><label class="form-label">Admission Plan</label>
            <select class="form-select" id="nv-plan"><option>This year</option><option>Next year</option><option>Just exploring</option></select>
          </div>
        </div>
        <div class="form-field"><label class="form-label">Documents Submitted</label>
          <div class="chip-row" id="nv-docs" style="flex-wrap:wrap;">
            ${['10th Marksheet','12th Marksheet','NEET Scorecard','Passport','Photos','Aadhar','Category Certificate'].map(d => `<div class="chip" data-val="${d}" onclick="this.classList.toggle('active')">${d}</div>`).join('')}
          </div>
        </div>
      </div>

      <div class="form-group">
        <div class="form-group-title">Notes & Status</div>
        <div class="form-field"><label class="form-label">Major Queries</label><textarea class="form-input" id="nv-queries" rows="2" placeholder="Fee, hostel, bond, recognition, ranking..."></textarea></div>
        <div class="form-field"><label class="form-label">Concerns</label><textarea class="form-input" id="nv-concerns" rows="2" placeholder="Any concerns raised..."></textarea></div>
        <div class="form-row">
          <div class="form-field"><label class="form-label">Status</label>
            <select class="form-select" id="nv-status"><option>New</option><option>Interested</option><option>Hot lead</option><option>Follow-up</option><option>Admitted</option><option>Not interested</option></select>
          </div>
          <div class="form-field"><label class="form-label">Follow-up Date</label><input type="date" class="form-input" id="nv-followup"></div>
        </div>
        <div class="form-field"><label class="form-label">Other Notes</label><input type="text" class="form-input" id="nv-notes" placeholder="Any other notes..."></div>
      </div>

      <div style="display:flex;gap:10px;margin-top:8px;">
        <button class="btn btn-violet btn-full" onclick="saveNewVisitor()">💾 Save Visit</button>
        <button class="btn btn-glass" onclick="closeModal()">Cancel</button>
      </div>
    </div>
  `);
}

async function saveNewVisitor() {
  const name = document.getElementById('nv-name').value.trim();
  if (!name) { toast('Name is required', 'error'); return; }

  const visitTypes = [...document.querySelectorAll('#nv-visit-types .chip.active')].map(c => c.dataset.val);
  const docs = [...document.querySelectorAll('#nv-docs .chip.active')].map(c => c.dataset.val);

  const visitor = {
    id: genId(), name,
    type: document.getElementById('nv-type').value,
    visit_date: document.getElementById('nv-date').value,
    phone: document.getElementById('nv-phone').value.trim(),
    email: document.getElementById('nv-email').value.trim(),
    city: document.getElementById('nv-city').value.trim(),
    state: document.getElementById('nv-state').value.trim(),
    college_interest: document.getElementById('nv-college').value.trim(),
    nepal_visit: document.getElementById('nv-nepal-visit').value,
    visit_types: visitTypes,
    reference_type: document.getElementById('nv-ref-type').value,
    reference_name: document.getElementById('nv-ref-name').value.trim(),
    neet_score: document.getElementById('nv-neet').value.trim(),
    admission_plan: document.getElementById('nv-plan').value,
    documents: docs,
    major_queries: document.getElementById('nv-queries').value.trim(),
    concerns: document.getElementById('nv-concerns').value.trim(),
    status: document.getElementById('nv-status').value,
    follow_up_date: document.getElementById('nv-followup').value,
    notes: document.getElementById('nv-notes').value.trim(),
    org: CU?.org, added_by: CU?.id, added_by_name: CU?.name,
    created_at: new Date().toISOString(),
  };

  await dbPut('visitors', visitor);
  closeModal();
  toast('Visit saved', 'success');
  auditLog('visitor_added', { name, status: visitor.status });

  // Single source of truth: also create/update the canonical student
  // record at the Lead stage, same pattern as Marketing leads.
  await dbPut('students', {
    id: genId(), name, phone: visitor.phone, email: visitor.email,
    city: visitor.city, state: visitor.state, stage: 'Lead',
    batch: 'MBBS 2025', org: CU?.org, college: visitor.college_interest || CU?.org,
    fees_paid: false, visa_status: 'Not Applied', attendance_pct: 0, gpa: 0,
    risk_level: 'low', lifecycle: { Lead: new Date().toISOString().split('T')[0] },
    created_at: new Date().toISOString(),
  });

  loadVisitors();
}

function openVisitorDetail(id) {
  const v = allVisitors.find(x => x.id === id);
  if (!v) return;
  const sc = VISITOR_STATUS_COLORS[v.status] || 'violet';

  showModal(`
    <div class="bottom-sheet">
      <div class="sheet-handle"></div>
      <div class="text-center mb-3">
        <div class="student-avatar" style="width:60px;height:60px;font-size:22px;background:var(--grad-${sc});margin:0 auto 10px;">${initials(v.name)}</div>
        <div style="font-size:17px;font-weight:800;">${escapeHtml(v.name)}</div>
        <div class="badge badge-${sc} mt-1">${v.status}</div>
      </div>

      <div class="glass-card mb-3">
        <div class="form-group-title">Contact & Visit</div>
        <div class="grid-2">
          ${[['📞 Phone', v.phone], ['📧 Email', v.email], ['📍 City', v.city], ['🌍 State', v.state],
            ['🏫 College', v.college_interest], ['📅 Visit Date', formatDate(v.visit_date)],
            ['🔗 Reference', v.reference_type], ['👤 Ref Name', v.reference_name]]
            .map(([k, val]) => `<div><div class="text-xs text-muted">${k}</div><div class="text-sm font-semibold mt-1">${escapeHtml(val || 'N/A')}</div></div>`).join('')}
        </div>
      </div>

      <div class="glass-card mb-3">
        <div class="form-group-title">Academic</div>
        <div class="grid-2">
          <div><div class="text-xs text-muted">🎯 NEET Score</div><div class="text-sm font-semibold mt-1">${escapeHtml(v.neet_score || 'N/A')}</div></div>
          <div><div class="text-xs text-muted">📋 Plan</div><div class="text-sm font-semibold mt-1">${escapeHtml(v.admission_plan || 'N/A')}</div></div>
        </div>
        ${v.documents?.length ? `<div class="mt-2"><div class="text-xs text-muted mb-1">📄 Documents</div>${v.documents.map(d => `<span class="badge badge-teal" style="margin:2px;">${escapeHtml(d)}</span>`).join('')}</div>` : ''}
        ${v.visit_types?.length ? `<div class="mt-2"><div class="text-xs text-muted mb-1">🏫 Visit Type</div>${v.visit_types.map(t => `<span class="badge badge-blue" style="margin:2px;">${escapeHtml(t)}</span>`).join('')}</div>` : ''}
      </div>

      ${v.major_queries || v.concerns ? `
        <div class="glass-card mb-3">
          ${v.major_queries ? `<div class="form-group-title">Major Queries</div><div class="text-sm text-muted mb-2">${escapeHtml(v.major_queries)}</div>` : ''}
          ${v.concerns ? `<div class="form-group-title">Concerns</div><div class="text-sm text-muted">${escapeHtml(v.concerns)}</div>` : ''}
        </div>` : ''}

      ${v.follow_up_date ? `<div class="ai-bubble mb-3"><div class="ai-text">⏰ Follow-up scheduled for <strong>${formatDate(v.follow_up_date)}</strong></div></div>` : ''}

      <div class="flex gap-2" style="flex-wrap:wrap;">
        <button class="btn btn-glass btn-sm" onclick="callNumber('${v.phone || ''}')">📞 Call</button>
        <button class="btn btn-glass btn-sm" onclick="whatsappNumber('${v.phone || ''}','${escapeHtml(v.name)}')">💬 WhatsApp</button>
        ${canManageVisitors() ? `<button class="btn btn-violet btn-sm" onclick="updateVisitorStatus('${v.id}')">📈 Update Status</button>` : ''}
        ${canManageVisitors() ? `<button class="btn btn-red btn-sm" onclick="deleteVisitor('${v.id}')">🗑️ Delete</button>` : ''}
      </div>
    </div>
  `);
}

function updateVisitorStatus(id) {
  const v = allVisitors.find(x => x.id === id);
  if (!v) return;
  const statuses = ['New', 'Interested', 'Hot lead', 'Follow-up', 'Admitted', 'Not interested'];
  showCenterModal(`
    <div class="modal-box">
      <div class="modal-title">📈 Update Status</div>
      <div class="modal-body mb-3">Current: <strong>${v.status}</strong></div>
      <div class="flex-col gap-2">
        ${statuses.map(s => `<button class="btn ${s === v.status ? 'btn-violet' : 'btn-glass'} btn-sm" onclick="setVisitorStatus('${id}','${s}')">${s}</button>`).join('')}
      </div>
    </div>
  `);
}

async function setVisitorStatus(id, status) {
  const v = allVisitors.find(x => x.id === id);
  if (!v) return;
  v.status = status;
  await dbPut('visitors', v);
  closeModal();
  toast(`Status updated to ${status}`, 'success');
  auditLog('visitor_status_updated', { name: v.name, status });
  loadVisitors();
}

async function deleteVisitor(id) {
  if (!confirm('Delete this visitor record?')) return;
  await dbDelete('visitors', id);
  closeModal();
  toast('Visitor deleted', 'success');
  auditLog('visitor_deleted', { id });
  loadVisitors();
}

function exportVisitorsCSV() {
  const cols = ['name','type','phone','email','city','state','college_interest','neet_score','admission_plan','reference_type','reference_name','status','visit_date','follow_up_date'];
  const headers = ['Name','Type','Phone','Email','City','State','College Interest','NEET','Plan','Ref Type','Ref Name','Status','Visit Date','Follow-up'];
  const csv = [headers.join(','), ...allVisitors.map(v => cols.map(c => `"${String(v[c] || '').replace(/"/g, "'")}"`).join(','))].join('\n');
  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = `Visitors_${new Date().toISOString().split('T')[0]}.csv`;
  a.click();
  URL.revokeObjectURL(url);
  toast('CSV downloaded', 'success');
}
