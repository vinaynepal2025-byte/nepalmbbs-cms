/* ═══════════════════════════════════════════════════
   calendar.js — Month calendar + events
═══════════════════════════════════════════════════ */
'use strict';

function renderCalendar() {
  const date = APP_STATE.calendarDate;
  const year = date.getFullYear();
  const month = date.getMonth();
  const labels = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];

  const labelEl = document.getElementById('cal-day-labels');
  if (!labelEl) return;
  labelEl.innerHTML = labels.map(l => `<div class="cal-day-label">${l}</div>`).join('');

  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const today = new Date();

  document.getElementById('cal-month-label').textContent = date.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' });

  let html = '';
  for (let i = 0; i < firstDay; i++) {
    const prevDay = new Date(year, month, -firstDay + i + 1);
    html += `<div class="cal-day other-month">${prevDay.getDate()}</div>`;
  }
  for (let d = 1; d <= daysInMonth; d++) {
    const isToday = today.getFullYear() === year && today.getMonth() === month && today.getDate() === d;
    html += `<div class="cal-day ${isToday ? 'today' : ''}" onclick="calDayClick(${year},${month},${d})">${d}</div>`;
  }
  document.getElementById('cal-grid').innerHTML = html;
}

function calNav(dir) {
  APP_STATE.calendarDate = new Date(APP_STATE.calendarDate.getFullYear(), APP_STATE.calendarDate.getMonth() + dir, 1);
  renderCalendar();
}

function calDayClick(y, m, d) {
  openAddEvent(new Date(y, m, d).toISOString().split('T')[0]);
}

async function loadEvents() {
  const el = document.getElementById('events-list');
  if (!el) return;
  const events = await dbGetAll('events');
  const myEvents = CU?.org ? events.filter(e => e.org === CU.org) : events;
  const future = myEvents.filter(e => new Date(e.date) >= new Date(new Date().toDateString()))
    .sort((a, b) => a.date.localeCompare(b.date)).slice(0, 8);

  if (!future.length) {
    el.innerHTML = '<div class="empty-state"><div class="empty-icon">📅</div><div class="empty-title">No upcoming events</div></div>';
    return;
  }

  const colorMap = { academic: 'violet', admission: 'red', communication: 'green', exam: 'amber', hostel: 'blue', general: 'teal' };
  el.innerHTML = future.map(e => `
    <div class="list-item">
      <div class="list-avatar" style="background:var(--grad-${colorMap[e.type] || 'violet'})">${(e.title || '?')[0]}</div>
      <div class="list-info">
        <div class="list-name">${escapeHtml(e.title)}</div>
        <div class="list-meta">${formatDate(e.date)} ${e.time ? '· ' + e.time : ''}</div>
        ${e.description ? `<div class="text-xs text-muted mt-1">${escapeHtml(e.description)}</div>` : ''}
      </div>
      <span class="badge badge-${colorMap[e.type] || 'violet'}">${e.type || 'event'}</span>
    </div>`).join('');
}

function openAddEvent(date = '') {
  showModal(`
    <div class="bottom-sheet">
      <div class="sheet-handle"></div>
      <div class="modal-title">📅 Add Event</div>
      <div class="divider"></div>
      <div class="form-field"><label class="form-label">Event Title *</label><input type="text" class="form-input" id="ne-title" placeholder="Event name"></div>
      <div class="form-row">
        <div class="form-field"><label class="form-label">Date *</label><input type="date" class="form-input" id="ne-date" value="${date}"></div>
        <div class="form-field"><label class="form-label">Time</label><input type="time" class="form-input" id="ne-time"></div>
      </div>
      <div class="form-field"><label class="form-label">Type</label>
        <select class="form-select" id="ne-type"><option value="general">General</option><option value="academic">Academic</option><option value="admission">Admission</option><option value="communication">Communication</option><option value="exam">Examination</option><option value="hostel">Hostel</option></select>
      </div>
      <div class="form-field"><label class="form-label">Description</label><textarea class="form-input" id="ne-desc" rows="2" placeholder="Event details..."></textarea></div>
      <div style="display:flex;gap:10px;margin-top:8px;">
        <button class="btn btn-violet btn-full" onclick="saveEvent()">✅ Save Event</button>
        <button class="btn btn-glass" onclick="closeModal()">Cancel</button>
      </div>
    </div>
  `);
}

async function saveEvent() {
  const title = document.getElementById('ne-title').value.trim();
  const date = document.getElementById('ne-date').value;
  if (!title || !date) { toast('Title and date are required', 'error'); return; }

  await dbPut('events', {
    id: genId(), title, date,
    time: document.getElementById('ne-time').value,
    type: document.getElementById('ne-type').value,
    description: document.getElementById('ne-desc').value.trim(),
    org: CU?.org, created_by: CU?.id, created_at: new Date().toISOString(),
  });
  closeModal();
  toast('Event added', 'success');
  loadEvents();
  renderCalendar();
}
