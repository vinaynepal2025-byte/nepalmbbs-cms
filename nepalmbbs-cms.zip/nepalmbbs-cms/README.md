# NepalMBBS CMS — Central Monitoring System

A production-grade, offline-first Progressive Web App (PWA) for managing the
complete student lifecycle of a medical college: leads → admission → visa →
travel → hostel → academics → graduation — with role-based dashboards for
Admin, Admission Managers, Marketing, Coordinators and Mentors.

This README is the entry point. Read `docs/00-START-HERE.md` next for the
exact GitHub upload sequence and deployment steps.

## What this is (honest scope)

This is a **single-tenant, installable, offline-capable PWA** built with
vanilla HTML/CSS/JS and IndexedDB for local storage, designed to run great as
a static site on GitHub Pages / Netlify / Vercel under a subdomain of
`nepalmbbs.in`. It is NOT a native Android/iOS binary and does not access
bank/UPI systems (per your instruction, those are explicitly excluded).

It **does** include:
- Full liquid-glass UI matching your reference screenshots
- Role-based dashboards (Super Admin, Admin, Admission Manager, Marketing,
  Coordinator, Mentor)
- Complete student lifecycle tracking (Lead → Graduation)
- Tasks, calendar, attendance, notifications, reports, documents
- Local-first data via IndexedDB (works fully offline, data lives on device)
- Optional Gemini AI assist (you supply your own free API key — see
  `docs/05-GEMINI-SETUP.md`)
- Installable as a Home Screen app (PWA manifest + service worker)
- Device feature hooks: camera/gallery upload, click-to-call, WhatsApp deep
  links, native Share, Google Drive picker stub

It does **not** include a multi-tenant cloud backend, push notification
server, or payment gateway — those require paid infrastructure or a backend
team and are flagged as **Phase 2 / Future Upgrade** in
`docs/09-FUTURE-UPGRADES.md`, with a free-tier path (Supabase) documented so
you can add them later without rebuilding the front end.

## Folder structure

```
nepalmbbs-cms/
├── index.html              ← App shell (loads everything else)
├── manifest.json            ← PWA install manifest
├── sw.js                    ← Service worker (offline cache)
├── css/
│   └── styles.css           ← Full liquid-glass design system
├── js/
│   ├── db.js                ← IndexedDB wrapper (the "database")
│   ├── auth.js               ← Login / first-time setup / sessions
│   ├── state.js              ← App state, roles, nav config, constants
│   ├── ui-core.js            ← Toasts, modals, nav rendering, router
│   ├── dashboard.js           ← Dashboard widgets per role
│   ├── students.js            ← Student lifecycle CRUD + detail sheet
│   ├── tasks.js               ← Task manager
│   ├── attendance.js          ← Attendance sheets + history
│   ├── admissions.js          ← Admission pipeline view
│   ├── marketing.js           ← Leads, campaigns, social links
│   ├── mentor-coordinator.js  ← Mentor & coordinator modules
│   ├── comms.js               ← Notices, chat stub, broadcast
│   ├── calendar.js            ← Calendar + events
│   ├── reports.js             ← Reports & analytics
│   ├── admin.js               ← Admin control panel, audit log
│   ├── ai.js                  ← Gemini AI integration layer
│   ├── device.js              ← Camera/Drive/Share/Call device hooks
│   └── app.js                 ← Boot sequence, wires everything together
├── assets/
│   └── icons/                 ← App icons (SVG, generated)
└── docs/
    ├── 00-START-HERE.md
    ├── 01-ARCHITECTURE.md
    ├── 02-DATABASE-SCHEMA.md
    ├── 03-ROLE-PERMISSIONS.md
    ├── 04-DEPLOYMENT-GITHUB.md
    ├── 05-GEMINI-SETUP.md
    ├── 06-SECURITY.md
    ├── 07-TESTING-CHECKLIST.md
    ├── 08-MAINTENANCE.md
    └── 09-FUTURE-UPGRADES.md
```

## Quick start (local preview)

You cannot just double-click `index.html` because service workers and
IndexedDB need a real origin. Run a tiny local server:

```bash
cd nepalmbbs-cms
python3 -m http.server 8080
# open http://localhost:8080
```

First run → choose **First Setup** tab → create your Super Admin account →
sign in.

## Deployment

See `docs/04-DEPLOYMENT-GITHUB.md` for the exact GitHub → Pages → custom
subdomain (`cms.nepalmbbs.in`) steps, including the DNS record to add.
